<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">suppliers</a></li>
			<li class="breadcrumb-item">details</li>
			<li class="breadcrumb-item active">refund histories</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>
<!-- Basic Tables start -->
<section id="basic-datatable">
	<div class="row">
	  <div class="col-12">
		<div class="card widget-todo">
            <div class="card-header border-bottom d-flex justify-content-between align-items-center" style="padding:0 !important;background:#f0f0f0;margin-bottom:0;">
              <ul class="details-tab-ul">
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID); ?>">Details</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PURCHASE-INVOICE'); ?>">Purchase Invoices</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a active" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=REFUND-HISTORY'); ?>">Refund History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=TRANSACTION-HISTORY'); ?>">Transaction History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PAYMENT-HISTORY'); ?>">Payment History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CHEQUES'); ?>">Cheques</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=FUND-TRANSFER'); ?>">Fund Transfers</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CR-NOTE'); ?>">CR Note</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=LEDGER'); ?>">LEDGER</a></li>
			  </ul>
            </div>
            <div class="card-body px-0 py-1" style="padding:15px !important;">
				<section id="basic-datatable">
					<div class="row">
					  <div class="col-12">
						<div class="card">
						  <div style="margin-bottom: 30px;">
							<a href="<?php echo base_url('purchase/purchaserefund/exportexcel'); ?>" style="right:150px" class="btn btn-custom btn-info shadow mr-1 btn-add-new"><i class="bx bxs-report font-medium-1"></i> GENERATE EXCEL REPORT</a>
							<a href="<?php echo base_url('purchase/purchaserefund/add'); ?>" class="btn btn-custom btn-info shadow btn-add-new"><i class="bx bxs-plus-square font-medium-1"></i> ADD NEW REFUND</a>
						  </div>
						  <div class="card-content">
							<!-- Table with no outer spacing -->
							<div class="card-body card-dashboard body-content-padding-zero">
								<div class="row header-padding-right-left">
									<div class="col-md-1">
										<?php 
											$limits = array(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 400, 500);
										?>
										<fieldset class="form-group">
											<label>Show Items</label>
											<select id="limit" class="custom-select">
												<?php 
													foreach($limits as $limit):
												?>
												<option value="<?php echo $limit; ?>"><?php echo $limit; ?></option>
												<?php endforeach; ?>
											</select>
										</fieldset>
									</div>
									<div class="col-md-1">
										<fieldset class="form-group">
											<label>Short By</label>
											<select id="shortBy" class="custom-select">
												<option value="NEWEST">Newest</option>
												<option value="OLDEST">Oldest</option>
												<option value="AZ">A-Z</option>
												<option value="ZA">Z-A</option>
											</select>
										</fieldset>
									</div>
									<div class="col-md-2">
										<fieldset class="form-group position-relative has-icon-left">
											<label>From Date</label>
											<input type="text" class="form-control pickadate-months-year" id="fromDate" placeholder="Select Date">
											<div class="form-control-position dpicker-icon-position">
												<i class='bx bx-calendar'></i>
											</div>
										</fieldset>
									</div>
									<div class="col-md-2">
										<fieldset class="form-group position-relative has-icon-left">
											<label>To Date</label>
											<input type="text" class="form-control pickadate-months-year" id="toDate" placeholder="Select Date">
											<div class="form-control-position dpicker-icon-position">
												<i class='bx bx-calendar'></i>
											</div>
										</fieldset>
									</div>
									<div class="col-md-1">
										<fieldset class="form-group">
											<label>Month</label>
											<select id="month" class="custom-select">
												<option value="" selected="selected">All</option>
												<?php 
													$months = array(
																'01' => 'January',
																'02' => 'February',
																'03' => 'March',
																'04' => 'April',
																'05' => 'May',
																'06' => 'June',
																'07' => 'July',
																'08' => 'August',
																'09' => 'September',
																'10' => 'October',
																'11' => 'November',
																'12' => 'December',
															);
													foreach($months as $key => $month):
												?>
													<option value="<?php echo $key; ?>"><?php echo $month; ?></option>
												<?php endforeach; ?>
											</select>
										</fieldset>
									</div>
									<div class="col-md-1">
										<label>Year</label>
										<select id="year" class="custom-select">
											<option value="" selected="selected">All</option>
											<?php 
												$starting_year = 2020;
												$current_year = date("Y")+1;
												for($x=$starting_year; $x < $current_year; $x++):
											?>
											<option value="<?php echo $x; ?>"><?php echo $x; ?></option>
											<?php endfor; ?>
										</select>
									</div>
									<div class="col-md-3">
										<fieldset class="form-group set-position-relative">
											<label>Search</label>
											<input type="text" name="keywords" id="keywords" class="form-control" placeholder="Search ....">
										</fieldset>
									</div>
									<div class="search-input-bx" style="width: 60px;">
										<span style="width: 75px;text-transform: uppercase;display: inline-block;background: #1B75BC;color: #FFF;border-radius: 2px;text-align: center;font-size: 12px;padding: 9px 5px;margin-top: 21px;cursor:pointer;" onclick="searchFilter()">Search</span>
									</div>
								</div>
								<div class="table-responsive">
								  <table class="table table-striped">
									<thead>
										<tr>
											<th style="width: 5%;">SL. NO</th>
											<th class="text-center" style="width: 10%;color:#7a2c1b">VOUCHER NUMBER</th>
											<th class="text-center" style="width: 9%;color:#413596">INVOICE NUMBER</th>
											<th class="text-center" style="width: 10%;">REFUND DATE</th>
											<th class="text-center" style="width: 8%;">REFUND AMOUNT</th>
											<th class="text-center" style="width: 9%;">REFUND CHARGE</th>
											<th class="text-center" style="width: 9%;">REFUND NET TOTAL</th>
											<th style="width: 8%;">CREATED DATE</th>
											<th style="width: 7%;">CREATED BY</th>
											<th class="text-center" style="width: 5%;">STATUS</th>
											<th style="width: 8%;">ACTION</th>
										</tr>
									</thead>
									<tbody>
									  <?php
										if(is_array($items) && count($items) !== 0):
										$sl_no = 1;
										foreach($items as $item):
									  ?>
									  <tr class="product-list-row-<?php echo $item['refund_id']; ?>">
										<td><?php echo $sl_no; ?></td>
										<td class="text-center" style="color:#7a2c1b"><?php echo $item['refund_voucher_number']; ?></td>
										<td class="text-center" style="color:#a7131a"><?php echo $item['invoice_number']; ?></td>
										<td class="text-center"><?php echo date("d F, Y", strtotime($item['refund_date'])); ?></td>
										
										<td class="text-center" style=""><?php echo number_format($item['refund_amount_total'], 2, '.', ','); ?></td>
										<td class="text-center" style=""><?php echo number_format($item['refund_charge_total'], 2, '.', ','); ?></td>
										<td class="text-center" style=""><?php echo number_format($item['refund_net_total'], 2, '.', ','); ?></td>
										
										
										<td><?php echo date("d F, Y", strtotime($item['refund_created_date'])).' '.date("g:i A", strtotime($item['refund_created_date'])); ?></td>
										<td><?php echo $item['admin_full_name']; ?></td>
										<td class="text-center">
											<?php if($item['refund_is_active'] == 'YES'): ?>
											<span class="status-active-item">Active</span>
											<?php else: ?>
											<span class="status-inactive-item">Inactive</span>
											<?php endif; ?>
										</td>
										<td>
											<a class="list-action-btn" href="<?php echo base_url('purchase/purchaserefund/view/'.$item['refund_formatted_id']); ?>" style="color:#348456" title="View Details"><i class="bx bxs-detail"></i></a>
											<a class="list-action-btn" href="<?php echo base_url('purchase/purchaserefund/edit/'.$item['refund_formatted_id']); ?>" style="color:#1f1e87" title="Edit"><i class="bx bx-edit"></i></a>
											<span class="list-action-btn click-to-delete" data-id="<?php echo $item['refund_id']; ?>" data-invoice="<?php echo $item['refund_id']; ?>" style="color:#ce0a0a" title="Delete"><i class="bx bxs-x-circle"></i></span>
										</td>
									  </tr>
									  <?php $sl_no++; endforeach; ?>
									  <?php else: ?>
									  <tr>
										<td colspan="13" class="text-center">NO VOUCHER FOUND!</td>
									  </tr>
									  <?php endif; ?>
									</tbody>
								  </table>
								  <div class="content-footer">
									<?php echo $this->ajax_pagination->create_links(); ?>
								  </div>
								</div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				</section>
            </div>
          </div>
	  </div>
	</div>
</section>
<!-- Basic Tables end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		
		$(document).on('click', '.click-to-delete', function(){
			var id = $(this).attr('data-id');
			if(confirm('Are you sure?', true))
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/delete",
					data : {id:id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
				
				$('.list-row-'+id).remove();
			}
		})
	});
</script>

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url('backend/app-assets/vendors/js/ui/jquery.sticky.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.html5.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.print.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/vfs_fonts.js'); ?>"></script>
<!-- END: Page Vendor JS-->
	
<!-- BEGIN: Page JS-->
<script src="<?php echo base_url('backend/app-assets/js/scripts/datatables/datatable.min.js'); ?>"></script>
<!-- END: Page JS-->
	
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>