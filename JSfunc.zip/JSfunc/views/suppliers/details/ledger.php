<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">suppliers</a></li>
			<li class="breadcrumb-item">details</li>
			<li class="breadcrumb-item active">ledger</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>
<!-- Basic Tables start -->
<section id="basic-datatable">
	<div class="row">
	  <div class="col-12">
		<div class="card widget-todo">
            <div class="card-header border-bottom d-flex justify-content-between align-items-center" style="padding:0 !important;background:#f0f0f0;margin-bottom:0;">
              <ul class="details-tab-ul">
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID); ?>">Details</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PURCHASE-INVOICE'); ?>">Purchase Invoices</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=REFUND-HISTORY'); ?>">Refund History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=TRANSACTION-HISTORY'); ?>">Transaction History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PAYMENT-HISTORY'); ?>">Payment History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CHEQUES'); ?>">Cheques</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=FUND-TRANSFER'); ?>">Fund Transfers</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CR-NOTE'); ?>">CR Note</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a active" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=LEDGER'); ?>">LEDGER</a></li>
			  </ul>
            </div>
            <div class="card-body px-0 py-1" style="padding:0px !important;">
				<section id="basic-datatable">
					<div class="row">
					  <div class="col-12">
						<div class="card" style="margin-bottom:0 !important;">
						  <div class="card-content">
							<!-- Table with no outer spacing -->
							<div class="card-body card-dashboard body-content-padding-zero">
								<div class="row header-padding-right-left" style="margin-top: 20px;">
									<div class="col-md-1">
										<fieldset class="form-group">
											<label>Short By</label>
											<select id="shortBy" class="custom-select">
												<option value="NEWEST">Newest</option>
												<option value="OLDEST">Oldest</option>
											</select>
										</fieldset>
									</div>
									<div class="col-md-4">
										<div style="padding-top: 26px;">
											<button class="btn btn-custom btn-primary shadow" onclick="documentPrint()"><i class="bx bx-printer"></i> <span>print</span> </button>
											<a href="<?php echo base_url('purchase/purchaserefund/exportexcel'); ?>" class="btn btn-custom btn-info shadow"><i class="bx bxs-report font-medium-1"></i> GENERATE EXCEL REPORT</a>
										</div>
									</div>
									<div class="col-md-2">
										<fieldset class="form-group position-relative has-icon-left">
											<label>From Date</label>
											<input type="text" class="form-control pickadate-months-year" id="fromDate" placeholder="Select Date">
											<div class="form-control-position dpicker-icon-position">
												<i class='bx bx-calendar'></i>
											</div>
										</fieldset>
									</div>
									<div class="col-md-2">
										<fieldset class="form-group position-relative has-icon-left">
											<label>To Date</label>
											<input type="text" class="form-control pickadate-months-year" id="toDate" placeholder="Select Date">
											<div class="form-control-position dpicker-icon-position">
												<i class='bx bx-calendar'></i>
											</div>
										</fieldset>
									</div>
									<div class="col-md-1">
										<fieldset class="form-group">
											<label>Month</label>
											<select id="month" class="custom-select">
												<option value="" selected="selected">All</option>
												<?php 
													$months = array(
																'01' => 'January',
																'02' => 'February',
																'03' => 'March',
																'04' => 'April',
																'05' => 'May',
																'06' => 'June',
																'07' => 'July',
																'08' => 'August',
																'09' => 'September',
																'10' => 'October',
																'11' => 'November',
																'12' => 'December',
															);
													foreach($months as $key => $month):
												?>
													<option value="<?php echo $key; ?>"><?php echo $month; ?></option>
												<?php endforeach; ?>
											</select>
										</fieldset>
									</div>
									<div class="col-md-1">
										<label>Year</label>
										<select id="year" class="custom-select">
											<option value="" selected="selected">All</option>
											<?php 
												$starting_year = 2020;
												$current_year = date("Y")+1;
												for($x=$starting_year; $x < $current_year; $x++):
											?>
											<option value="<?php echo $x; ?>"><?php echo $x; ?></option>
											<?php endfor; ?>
										</select>
									</div>
									<div class="search-input-bx" style="width: 60px;">
										<span style="width: 75px;text-transform: uppercase;display: inline-block;background: #1B75BC;color: #FFF;border-radius: 2px;text-align: center;font-size: 12px;padding: 9px 5px;margin-top: 21px;cursor:pointer;" onclick="searchFilter()">Search</span>
									</div>
								</div>
								<div class="table-responsive ledger-content">
								  <table class="table table-striped">
									<thead>
										<tr>
											<th style="width: 5%;">SL. NO</th>
											<th class="text-center" style="color:#026868">DATE & TIME</th>
											<th class="text-center" style="">PARTICULARS</th>
											<th class="text-center" style="color:#E00">DEBIT AMOUNT</th>
											<th class="text-center" style="color:#0A0">CREDIT AMOUNT</th>
											<th class="text-right" style="">LAST BALANCE</th>
											<th class="text-right" style="">PRESENT BALANCE</th>
											<th class="text-center" style="">LEDGER BY</th>
										</tr>
									</thead>
									<tbody>
									<?php 
										$items = $this->Suppliers_model->get_ledgers($supplier_info['supplier_id']);
										if(is_array($items) && count($items) !== 0):
											foreach($items as $item):
											$ledger_status = array(
																'CREATE' => array('inherit', date("l, d F, Y", strtotime($item['ledger_created_date'])).' ('.date("g:i A", strtotime($item['ledger_created_date'])).')', by($item['ledger_created_by']), 'inherit'),
																'UPDATE' => array('rgba(0,110,0,0.1)', date("l, d F, Y", strtotime($item['ledger_updated_date'])).' ('.date("g:i A", strtotime($item['ledger_updated_date'])).')', by($item['ledger_updated_by']), 'inherit'),
																'DELETE' => array('rgba(110,0,0,0.1)', date("l, d F, Y", strtotime($item['ledger_deleted_date'])).' ('.date("g:i A", strtotime($item['ledger_deleted_date'])).')', by($item['ledger_deleted_by']), '#a00')
															);
									?>
									<tr style="background:<?php echo $ledger_status[$item['ledger_status']][0]; ?>;">
										<td><?php echo $item['ledger_id']; ?></td>
										<td class="text-center" style="color:#026868;font-size: 12px !important;"><?php echo $ledger_status[$item['ledger_status']][1]; ?></td>
										<td class="text-center" style="color:<?php echo $ledger_status[$item['ledger_status']][3]; ?>;font-size:12px !important"><p style="margin:0;line-height: 14px;"><?php echo $item['ledger_particulars']; ?></p></td>
										<td class="text-center" style="color:#E00;font-size: 12px !important;"><?php echo number_format(floatval($item['ledger_debit_amount']), 0, '.', ','); ?></td>
										<td class="text-center" style="color:#0A0;font-size: 12px !important;"><?php echo number_format(floatval($item['ledger_credit_amount']), 0, '.', ','); ?></td>
										<td class="text-right" style="font-size: 12px !important;">
											<?php 
												if($item['ledger_last_balance_type'] == 'DUE')
												{
													echo '<strong style="color:#E00">'.$item['ledger_last_balance_type'].'</strong> : '.number_format(floatval($item['ledger_last_balance']), 0, '.', ',');
												}elseif ($item['ledger_last_balance_type'] == 'ADVANCE') {
													echo '<strong style="color:#0A0">'.$item['ledger_last_balance_type'].'</strong> : '.number_format(floatval($item['ledger_last_balance']), 0, '.', ',');
												}elseif ($item['ledger_last_balance_type'] == 'BALANCE') {
													echo '<strong style="color:#333">'.$item['ledger_last_balance_type'].'</strong> : '.number_format(floatval($item['ledger_last_balance']), 0, '.', ',');
												}else{
													echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 0, '.', ',');
												}
											?>
										</td>
										<td class="text-right" style="font-size: 12px !important;">
											<?php 
												if($item['ledger_balance_type'] == 'DUE')
												{
													echo '<strong style="color:#E00">'.$item['ledger_balance_type'].'</strong> : '.number_format(floatval($item['ledger_balance']), 0, '.', ',');
												}elseif ($item['ledger_balance_type'] == 'ADVANCE') {
													echo '<strong style="color:#0A0">'.$item['ledger_balance_type'].'</strong> : '.number_format(floatval($item['ledger_balance']), 0, '.', ',');
												}elseif ($item['ledger_balance_type'] == 'BALANCE') {
													echo '<strong style="color:#333">'.$item['ledger_balance_type'].'</strong> : '.number_format(floatval($item['ledger_balance']), 0, '.', ',');
												}else{
													echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 0, '.', ',');
												}
											?>
										</td>
										<td class="text-center" style="font-size: 12px !important;"><?php echo $ledger_status[$item['ledger_status']][2]; ?></td>
									</tr>
									<?php
											endforeach;
										else:
									?>
									  <tr>
										<td colspan="8" class="text-center">NO LEDGER FOUND!</td>
									  </tr>
									<?php endif; ?>
									</tbody>
								  </table>
								</div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				</section>
            </div>
          </div>
	  </div>
	</div>
</section>
<!-- Basic Tables end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		
		$(document).on('click', '.click-to-delete', function(){
			var id = $(this).attr('data-id');
			if(confirm('Are you sure?', true))
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/delete",
					data : {id:id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
				
				$('.list-row-'+id).remove();
			}
		})
	});
</script>

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url('backend/app-assets/vendors/js/ui/jquery.sticky.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.html5.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.print.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/vfs_fonts.js'); ?>"></script>
<!-- END: Page Vendor JS-->
	
<!-- BEGIN: Page JS-->
<script src="<?php echo base_url('backend/app-assets/js/scripts/datatables/datatable.min.js'); ?>"></script>
<!-- END: Page JS-->
	
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>