<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">suppliers</a></li>
			<li class="breadcrumb-item active">details</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>
<!-- Basic Tables start -->
<section id="basic-datatable">
	<div class="row">
	  <div class="col-12">
		<div class="card widget-todo">
            <div class="card-header border-bottom d-flex justify-content-between align-items-center" style="padding:0 !important;background:#f0f0f0;margin-bottom:0;">
              <ul class="details-tab-ul">
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a active" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID); ?>">Details</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PURCHASE-INVOICE'); ?>">Purchase Invoices</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=REFUND-HISTORY'); ?>">Refund History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=TRANSACTION-HISTORY'); ?>">Transaction History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PAYMENT-HISTORY'); ?>">Payment History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CHEQUES'); ?>">Cheques</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=FUND-TRANSFER'); ?>">Fund Transfers</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CR-NOTE'); ?>">CR Note</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=LEDGER'); ?>">LEDGER</a></li>
			  </ul>
            </div>
            <div class="card-body px-0 py-1" style="padding:15px !important;">
				<div class="row">
					<div class="col-6">
						<h4 class="card-title">General Information</h4>
						<table class="table table-bordered table-striped">
							<tbody>
								<tr>
									<td class="text-right" style="width:50%">SUPPLIER / COMPANY LOGO</td>
									<td class="text-left">
										<?php $logo_url = $this->Suppliers_model->get_company_logo_url($supplier_info['supplier_id']); ?>
										<img src="<?php echo $logo_url; ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" />
									</td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">NAME OF SUPPLIER / COMPANY</td>
									<td class="text-left"><?php echo $supplier_info['supplier_name']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">LOCATION</td>
									<td class="text-left"><?php echo $supplier_info['city_name'].', '.$supplier_info['state_name'].', '.$supplier_info['country_name']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">ADDRESS </td>
									<td class="text-left"><?php echo $supplier_info['supplier_address']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">TELEPHONE NUMBER</td>
									<td class="text-left"><?php echo $supplier_info['supplier_telephone_number']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">E-MAIL ADDRESS</td>
									<td class="text-left"><?php echo $supplier_info['supplier_email_address']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">FAX NUMBER</td>
									<td class="text-left"><?php echo $supplier_info['supplier_fax_number']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">DATE COMPANY WAS ESTABLISHED</td>
									<td class="text-left"><?php echo date("d F, Y", strtotime($supplier_info['supplier_company_established_date'])); ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">WEBSITE ADDRESS</td>
									<td class="text-left"><a target="__blank" href="<?php echo $supplier_info['supplier_website_address']; ?>"><?php echo $supplier_info['supplier_website_address']; ?></a></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">TYPE OF BUSINESS</td>
									<td class="text-left"><?php echo $supplier_info['supplier_type_of_business']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">SERVICE AREA</td>
									<td class="text-left"><?php echo $supplier_info['supplier_service_area']; ?></td>
								</tr>
								<tr>
									<td class="text-right" style="width:50%">LEGAL STRUCTURE</td>
									<td class="text-left"><?php echo $supplier_info['supplier_company_legal_structure']; ?></td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-6">
						<h4 class="card-title">Balance</h4>
						<table class="table table-bordered table-striped">
							<tbody>
								<?php 
									$balance_info = get_the_supplier_balance($supplier_info['supplier_id']); 
									if($balance_info['balance_type'] == 'DUE'):
								?>
									<tr>
										<td class="text-right" style="width: 20%;"><strong style="color:#E00"><?php echo $balance_info['balance_type']; ?></strong></td>
										<td class="text-left"><strong>BDT <?php echo number_format(floatval($balance_info['balance_amount']), 0, '.', ','); ?> /-</strong></td>
									</tr>
								<?php elseif($balance_info['balance_type'] == 'ADVANCE'): ?>
									<tr>
										<td class="text-right" style="width: 20%;"><strong style="color:#0A0"><?php echo $balance_info['balance_type']; ?></strong></td>
										<td class="text-left"><strong>BDT <?php echo number_format(floatval($balance_info['balance_amount']), 0, '.', ','); ?> /-</strong></td>
									</tr>
								<?php elseif($balance_info['balance_type'] == 'BALANCE'): ?>
									<tr>
										<td class="text-right" style="width: 20%;"><strong style="color:#333"><?php echo $balance_info['balance_type']; ?></strong></td>
										<td class="text-left"><strong>BDT <?php echo number_format(floatval($balance_info['balance_amount']), 0, '.', ','); ?> /-</strong></td>
									</tr>
								<?php else: ?>
									<tr>
										<td class="text-right" style="width: 20%;"><strong style="color:#333"><?php echo $balance_info['balance_type']; ?></strong></td>
										<td class="text-left"><strong>BDT <?php echo number_format(floatval($balance_info['balance_amount']), 0, '.', ','); ?> /-</strong></td>
									</tr>
								<?php endif; ?>
							</tbody>
						</table>

						<h4 class="card-title" style="margin-top:30px;">Opening Balance</h4>
						<table class="table table-bordered table-striped">
							<tbody>
								<?php if($supplier_info['opbalance_type'] == 'CREDIT'): ?>
								<tr>
									<td class="text-right" style="width: 20%;"><strong style="color:#0A0">ADVANCE</strong></td>
									<td class="text-left"><strong>BDT <?php echo number_format($supplier_info['opbalance_amount'], 0, '.', ','); ?> /-</strong></td>
								</tr>
								<?php elseif($supplier_info['opbalance_type'] == 'DEBIT'): ?>
								<tr>
									<td class="text-right" style="width: 20%;"><strong style="color:#A00">DUE</strong></td>
									<td class="text-left"><strong>BDT <?php echo number_format($supplier_info['opbalance_amount'], 0, '.', ','); ?> /-</strong></td>
								</tr>
								<?php else: ?>
								<tr>
									<td class="text-center"><strong style="color:#999;font-size: 14px;font-weight: normal;">N/A</strong></td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
						
						<h4 class="card-title" style="margin-top:30px;">Banking Information</h4>
						<table class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>SL.</th>
									<th>BANK NAME</th>
									<th>BRANCH NAME</th>
									<th>A/C NAME</th>
									<th>A/C NUMBER</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$banks = $this->Suppliers_model->get_supplier_banks($supplier_info['supplier_id']);
								?>
								<?php if(is_array($banks) && count($banks) !== 0): ?>
								<?php 
									$row_number2 = 1;
									foreach($banks as $bank): 
								?>
								<tr>
									<td class="text-center"><?php echo ($row_number2 < 10)? '0'.$row_number2 : $row_number2 ; ?></td>
									<td><?php echo $bank['spmethod_bank_name']; ?></td>
									<td><?php echo $bank['spmethod_branch_name']; ?></td>
									<td><?php echo $bank['spmethod_account_name']; ?></td>
									<td><?php echo $bank['spmethod_account_number']; ?></td>
								</tr>
								<?php 
									$row_number2++;
									endforeach; 
								?>
								<?php else: ?>
								<tr><td class="text-center" colspan="5">NO INFORMATION ADDED</td></tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<div class="col-12" style="margin-top:20px;">
						<h4 class="card-title">Contact Information</h4>
						<table class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>SL.</th>
									<th>NAME OF CONTACT PERSON</th>
									<th>DESIGNATION</th>
									<th>EMAIL ADDRESS</th>
									<th>TELEPHONE NUMBER</th>
									<th>MOBILE NUMBER</th>
									<th>WHATSAPP NUMBER</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$contacts = $this->Suppliers_model->get_supplier_contacts($supplier_info['supplier_id']);
								?>
								<?php if(is_array($contacts) && count($contacts) !== 0): ?>
								<?php 
									$row_number = 1;
									foreach($contacts as $contact): 
								?>
								<tr>
									<td class="text-center"><?php echo ($row_number < 10)? '0'.$row_number : $row_number ; ?></td>
									<td><?php echo $contact['contact_full_name']; ?></td>
									<td><?php echo $contact['contact_designation']; ?></td>
									<td><?php echo $contact['contact_email_address']; ?></td>
									<td><?php echo $contact['contact_telephone_number']; ?></td>
									<td><?php echo $contact['contact_mobile_number']; ?></td>
									<td><?php echo $contact['contact_whatsapp_number']; ?></td>
								</tr>
								<?php 
									$row_number++;
									endforeach; 
								?>
								<?php else: ?>
								<tr><td class="text-center" colspan="7">NO INFORMATION ADDED</td></tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
            </div>
          </div>
	  </div>
	</div>
</section>
<!-- Basic Tables end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		
		$(document).on('click', '.click-to-delete', function(){
			var id = $(this).attr('data-id');
			if(confirm('Are you sure?', true))
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/delete",
					data : {id:id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
				
				$('.list-row-'+id).remove();
			}
		})
	});
</script>

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url('backend/app-assets/vendors/js/ui/jquery.sticky.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.html5.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.print.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/vfs_fonts.js'); ?>"></script>
<!-- END: Page Vendor JS-->
	
<!-- BEGIN: Page JS-->
<script src="<?php echo base_url('backend/app-assets/js/scripts/datatables/datatable.min.js'); ?>"></script>
<!-- END: Page JS-->
	
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>