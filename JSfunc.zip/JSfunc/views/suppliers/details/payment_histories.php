<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">suppliers</a></li>
			<li class="breadcrumb-item">details</li>
			<li class="breadcrumb-item active">payment histories</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>
<!-- Basic Tables start -->
<section id="basic-datatable">
	<div class="row">
	  <div class="col-12">
		<div class="card widget-todo">
            <div class="card-header border-bottom d-flex justify-content-between align-items-center" style="padding:0 !important;background:#f0f0f0;margin-bottom:0;">
              <ul class="details-tab-ul">
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID); ?>">Details</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PURCHASE-INVOICE'); ?>">Purchase Invoices</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=REFUND-HISTORY'); ?>">Refund History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=TRANSACTION-HISTORY'); ?>">Transaction History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a active" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=PAYMENT-HISTORY'); ?>">Payment History</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CHEQUES'); ?>">Cheques</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=FUND-TRANSFER'); ?>">Fund Transfers</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=CR-NOTE'); ?>">CR Note</a></li>
				<li class="details-tab-ul-li"><a class="details-tab-ul-li-a" href="<?php echo base_url('purchase/suppliers/view/'.$supplier_ID.'?TAB=LEDGER'); ?>">LEDGER</a></li>
			  </ul>
            </div>
            <div class="card-body px-0 py-1" style="padding:15px !important;">
				<section id="basic-datatable">
					<div class="row">
					  <div class="col-12">
						<div class="card">
						  <div style="margin-bottom: 30px;">
							<a href="<?php echo base_url('purchase/purchaserefund/exportexcel'); ?>" style="right:0px" class="btn btn-custom btn-info shadow btn-add-new"><i class="bx bxs-report font-medium-1"></i> GENERATE EXCEL REPORT</a>
						  </div>
						  <div class="card-content">
							<!-- Table with no outer spacing -->
							<div class="card-body card-dashboard body-content-padding-zero">
								<div class="row header-padding-right-left">
									<div class="col-md-1">
										<?php 
											$limits = array(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 400, 500);
										?>
										<fieldset class="form-group">
											<label>Show Items</label>
											<select id="limit" class="custom-select">
												<?php 
													foreach($limits as $limit):
												?>
												<option value="<?php echo $limit; ?>"><?php echo $limit; ?></option>
												<?php endforeach; ?>
											</select>
										</fieldset>
									</div>
									<div class="col-md-1">
										<fieldset class="form-group">
											<label>Short By</label>
											<select id="shortBy" class="custom-select">
												<option value="NEWEST">Newest</option>
												<option value="OLDEST">Oldest</option>
												<option value="AZ">A-Z</option>
												<option value="ZA">Z-A</option>
											</select>
										</fieldset>
									</div>
									<div class="col-md-2">
										<fieldset class="form-group position-relative has-icon-left">
											<label>From Date</label>
											<input type="text" class="form-control pickadate-months-year" id="fromDate" placeholder="Select Date">
											<div class="form-control-position dpicker-icon-position">
												<i class='bx bx-calendar'></i>
											</div>
										</fieldset>
									</div>
									<div class="col-md-2">
										<fieldset class="form-group position-relative has-icon-left">
											<label>To Date</label>
											<input type="text" class="form-control pickadate-months-year" id="toDate" placeholder="Select Date">
											<div class="form-control-position dpicker-icon-position">
												<i class='bx bx-calendar'></i>
											</div>
										</fieldset>
									</div>
									<div class="col-md-1">
										<fieldset class="form-group">
											<label>Month</label>
											<select id="month" class="custom-select">
												<option value="" selected="selected">All</option>
												<?php 
													$months = array(
																'01' => 'January',
																'02' => 'February',
																'03' => 'March',
																'04' => 'April',
																'05' => 'May',
																'06' => 'June',
																'07' => 'July',
																'08' => 'August',
																'09' => 'September',
																'10' => 'October',
																'11' => 'November',
																'12' => 'December',
															);
													foreach($months as $key => $month):
												?>
													<option value="<?php echo $key; ?>"><?php echo $month; ?></option>
												<?php endforeach; ?>
											</select>
										</fieldset>
									</div>
									<div class="col-md-1">
										<label>Year</label>
										<select id="year" class="custom-select">
											<option value="" selected="selected">All</option>
											<?php 
												$starting_year = 2020;
												$current_year = date("Y")+1;
												for($x=$starting_year; $x < $current_year; $x++):
											?>
											<option value="<?php echo $x; ?>"><?php echo $x; ?></option>
											<?php endfor; ?>
										</select>
									</div>
									<div class="col-md-3">
										<fieldset class="form-group set-position-relative">
											<label>Search</label>
											<input type="text" name="keywords" id="keywords" class="form-control" placeholder="Search ....">
										</fieldset>
									</div>
									<div class="search-input-bx" style="width: 60px;">
										<span style="width: 75px;text-transform: uppercase;display: inline-block;background: #1B75BC;color: #FFF;border-radius: 2px;text-align: center;font-size: 12px;padding: 9px 5px;margin-top: 21px;cursor:pointer;" onclick="searchFilter()">Search</span>
									</div>
								</div>
								<div class="table-responsive">
								  <table class="table table-striped">
									<thead>
									  <tr>
										<th style="width: 5%;">SL. NO</th>
										<th class="text-center" style="color:#a00">RECEIPT NUMBER</th>
										<th class="text-center" style="color:#00a">PAYMENT METHOD</th>
										<th class="text-center" style="color:#0a0">AMOUNT</th>
										<th class="text-center">PAYMENT DATE</th>
										<th class="text-center">PAYMENT ADDED BY</th>
										<th class="text-center">CREATED DATE & TIME</th>
										<th class="text-center">STATUS</th>
										<th>ACTION</th>
									  </tr>
									</thead>
									<tbody>
									  <?php 
										$sl_no = 1;
										if(is_array($items) && count($items) !== 0):
										foreach($items as $item):
										$photo_url = $this->Suppliers_model->get_company_logo_url($item['payment_supplier_id']);
									  ?>
									  <tr class="list-row-<?php echo $item['payment_id']; ?>">
										<td><?php echo $sl_no; ?></td>
										<td class="text-center" style="color:#a00"><?php echo $item['payment_receipt_number']; ?></td>
										<td class="text-center" style="color:#00a"><?php echo str_replace('_', ' ', $item['payment_method']); ?></td>
										<td class="text-center" style="color:#0a0"><?php echo number_format($item['payment_amount'], 0, '.', ','); ?></td>
										<td class="text-center"><?php echo date("d F, Y", strtotime($item['payment_date'])); ?></td>
										<td class="text-center"><?php echo $item['admin_full_name']; ?></td>
										<td class="text-center"><?php echo date("d F, Y", strtotime($item['payment_create_date'])).' '.date("g:i A", strtotime($item['payment_create_date'])); ?></td>
										<td class="text-center">
											<?php if($item['payment_status'] == 'PAID'): ?>
											<span class="status-active-item">PAID</span>
											<?php else: ?>
											<span class="status-inactive-item">PENDING</span>
											<?php endif; ?>
										</td>
										<td>
											<a class="list-action-btn" href="<?php echo base_url('purchase/payments/vouchar/'.$item['payment_formatted_id']); ?>" style="color:#348456" title="View Details"><i class="bx bxs-receipt"></i></a>
											<a class="list-action-btn" href="<?php echo base_url('purchase/payments/edit/'.$item['payment_formatted_id']); ?>" style="color:#1f1e87" title="Edit"><i class="bx bx-edit"></i></a>
											<span class="list-action-btn click-to-delete" data-id="<?php echo $item['payment_id']; ?>" style="color:#ce0a0a" title="Delete"><i class="bx bxs-x-circle"></i></span>
										</td>
									  </tr>
									  <?php $sl_no++; endforeach; ?>
									  <?php else: ?>
									  <tr><td colspan="10" class="text-center">NO PAYMENT DATA FOUND !</td></tr>
									  <?php endif; ?>
									</tbody>
								  </table>
								  <div class="content-footer">
									<?php echo $this->ajax_pagination->create_links(); ?>
								  </div>
								</div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				</section>
            </div>
          </div>
	  </div>
	</div>
</section>
<!-- Basic Tables end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		
		$(document).on('click', '.click-to-delete', function(){
			var id = $(this).attr('data-id');
			if(confirm('Are you sure?', true))
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/delete",
					data : {id:id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
				
				$('.list-row-'+id).remove();
			}
		})
	});
</script>

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url('backend/app-assets/vendors/js/ui/jquery.sticky.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.html5.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.print.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/vfs_fonts.js'); ?>"></script>
<!-- END: Page Vendor JS-->
	
<!-- BEGIN: Page JS-->
<script src="<?php echo base_url('backend/app-assets/js/scripts/datatables/datatable.min.js'); ?>"></script>
<!-- END: Page JS-->
	
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>