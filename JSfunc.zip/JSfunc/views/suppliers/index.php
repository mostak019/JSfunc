<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">suppliers</a></li>
			<li class="breadcrumb-item active">view all suppliers
			</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>
<!-- Basic Tables start -->
<section id="basic-datatable">
	<div class="row">
	  <div class="col-12">
		<div class="card">
		  <div class="card-header">
			<h4 class="card-title">All Suppliers</h4>
			<a href="<?php echo base_url('purchase/suppliers/exportcsv'); ?>" style="right:397px" class="btn btn-custom btn-info shadow mr-1 btn-add-new"><i class="bx bxs-report font-medium-1"></i> GENERATE CSV REPORT</a>
			<a href="<?php echo base_url('purchase/suppliers/exportexcel'); ?>" style="right:190px" class="btn btn-custom btn-info shadow mr-1 btn-add-new"><i class="bx bxs-report font-medium-1"></i> GENERATE EXCEL REPORT</a>
			<a href="<?php echo base_url('purchase/suppliers/add'); ?>" class="btn btn-custom btn-primary shadow mr-1 btn-add-new"><i class="bx bxs-plus-square font-medium-1"></i> ADD NEW SUPPLIER</a>
		  </div>
		  <div class="card-content">
			<!-- Table with no outer spacing -->
			<div class="card-body card-dashboard body-content-padding-zero">
				<div class="row header-padding-right-left">
					<div class="col-md-1">
						<?php 
							$limits = array(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 400, 500);
						?>
						<fieldset class="form-group">
							<label>Show Items</label>
							<select id="limit" class="custom-select">
								<?php 
									foreach($limits as $limit):
								?>
								<option value="<?php echo $limit; ?>"><?php echo $limit; ?></option>
								<?php endforeach; ?>
							</select>
						</fieldset>
					</div>
					<div class="col-md-1">
						<fieldset class="form-group">
							<label>Short By</label>
							<select id="shortBy" class="custom-select">
								<option value="DESC">Newest</option>
								<option value="ASC">Oldest</option>
								<option value="AZ">A-Z</option>
								<option value="ZA">Z-A</option>
							</select>
						</fieldset>
					</div>
					<div class="col-md-2">
						<fieldset class="form-group position-relative has-icon-left">
							<label>From Date</label>
							<input type="text" class="form-control pickadate-months-year" id="fromDate" placeholder="Select Date">
							<div class="form-control-position dpicker-icon-position">
								<i class='bx bx-calendar'></i>
							</div>
						</fieldset>
					</div>
					<div class="col-md-2">
						<fieldset class="form-group position-relative has-icon-left">
							<label>To Date</label>
							<input type="text" class="form-control pickadate-months-year" id="toDate" placeholder="Select Date">
							<div class="form-control-position dpicker-icon-position">
								<i class='bx bx-calendar'></i>
							</div>
						</fieldset>
					</div>
					<div class="col-md-1">
						<fieldset class="form-group">
							<label>Month</label>
							<select id="month" class="custom-select">
								<option value="" selected="selected">All</option>
								<?php 
									$months = array(
												'01' => 'January',
												'02' => 'February',
												'03' => 'March',
												'04' => 'April',
												'05' => 'May',
												'06' => 'June',
												'07' => 'July',
												'08' => 'August',
												'09' => 'September',
												'10' => 'October',
												'11' => 'November',
												'12' => 'December',
											);
									foreach($months as $key => $month):
								?>
									<option value="<?php echo $key; ?>"><?php echo $month; ?></option>
								<?php endforeach; ?>
							</select>
						</fieldset>
					</div>
					<div class="col-md-1">
						<label>Year</label>
						<select id="year" class="custom-select">
							<option value="" selected="selected">All</option>
							<?php 
								$starting_year = 2020;
								$current_year = date("Y")+1;
								for($x=$starting_year; $x < $current_year; $x++):
							?>
							<option value="<?php echo $x; ?>"><?php echo $x; ?></option>
							<?php endfor; ?>
						</select>
					</div>
					<div class="col-md-3">
						<fieldset class="form-group set-position-relative">
							<label>Search</label>
							<input type="text" name="keywords" id="keywords" class="form-control" placeholder="Search ....">
						</fieldset>
					</div>
					<div class="search-input-bx" style="width: 60px;">
						<span style="width: 75px;text-transform: uppercase;display: inline-block;background: #1B75BC;color: #FFF;border-radius: 2px;text-align: center;font-size: 12px;padding: 9px 5px;margin-top: 21px;cursor:pointer;" onclick="searchFilter()">Search</span>
					</div>
				</div>
				<div class="table-responsive">
				  <table class="table table-striped">
					<thead>
					  <tr>
						<th style="width: 5%;">SL. NO</th>
						<th>SUPPLIER NAME</th>
						<th class="text-center">LOGO</th>
						<th>SUMMERY</th>
						<th>TYPE OF BUSINESS</th>
						<th class="text-center">BALANCE</th>
						<th>REGISTER DATE</th>
						<th>REGISTERED BY</th>
						<th class="text-center">STATUS</th>
						<th class="text-center">PAYMENT</th>
						<th>ACTION</th>
					  </tr>
					</thead>
					<tbody>
					  <?php 
						$sl_no = 1;
						if(is_array($items) && count($items) !== 0):
						foreach($items as $item):
						$logo_url = $this->Suppliers_model->get_company_logo_url($item['supplier_id']);
					  ?>
					  <tr class="list-row-<?php echo $item['supplier_id']; ?>">
						<td><?php echo $sl_no; ?></td>
						<td><?php echo $item['supplier_name']; ?></td>
						<td class="text-center"><img src="<?php echo $logo_url; ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
						<td>
							<div>
								<?php if($item['supplier_address']): ?>
								<strong>Address :</strong> <?php echo $item['supplier_address']; ?><br />
								<?php endif; ?>
								
								<?php if($item['supplier_telephone_number']): ?>
								<strong>Telephone :</strong> <?php echo $item['supplier_telephone_number']; ?><br />
								<?php endif; ?>
								
								<?php if($item['supplier_email_address']): ?>
								<strong>Email :</strong> <?php echo $item['supplier_email_address']; ?><br />
								<?php endif; ?>
								
								<?php if($item['supplier_website_address']): ?>
								<strong>Website :</strong> <?php echo $item['supplier_website_address']; ?><br />
								<?php endif; ?>
							</div>
						</td>
						
						<td><?php echo $item['supplier_type_of_business']; ?></td>
						<td class="text-center">
							<?php 
								$balance_info = get_the_supplier_balance($item['supplier_id']); 
								if($balance_info['balance_type'] == 'DUE')
								{
									echo '<strong style="color:#E00">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
								}elseif ($balance_info['balance_type'] == 'ADVANCE') {
									echo '<strong style="color:#0A0">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
								}elseif ($balance_info['balance_type'] == 'BALANCE') {
									echo '<strong style="color:#333">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
								}else{
									echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 2, '.', ',');
								}
							?>
						</td>
						<td><?php echo show_date_time($item['supplier_created_date']); ?></td>
						<td><?php echo $item['admin_full_name']; ?></td>
						<td class="text-center">
							<?php if($item['supplier_is_active'] == 'YES'): ?>
							<span class="status-active-item">Active</span>
							<?php else: ?>
							<span class="status-inactive-item">Inactive</span>
							<?php endif; ?>
						</td>
						<td class="text-center"><a href="<?php echo base_url('purchase/payments/add?ref='.$item['supplier_formatted_id']); ?>" style="padding: 3px 8px;font-size: 11px;border-radius: 4px;line-height: 20px;" class="btn btn-dark btn-sm"><i class="bx bx-money"></i> ADD PAYMENT</a></td>
						<td>
							<a class="list-action-btn" href="<?php echo base_url('purchase/suppliers/view/'.$item['supplier_formatted_id']); ?>" style="color:#348456" title="View Details"><i class="bx bxs-detail"></i></a>
							<a class="list-action-btn" href="<?php echo base_url('purchase/suppliers/edit/'.$item['supplier_formatted_id']); ?>" style="color:#1f1e87" title="Edit"><i class="bx bx-edit"></i></a>
							<span class="list-action-btn click-to-delete" data-id="<?php echo $item['supplier_id']; ?>" style="color:#ce0a0a" title="Delete"><i class="bx bxs-x-circle"></i></span>
						</td>
					  </tr>
					  <?php $sl_no++; endforeach; ?>
					  <?php else: ?>
					  <tr><td colspan="11" class="text-center">NO SUPPLIER DATA FOUND!</td></tr>
					  <?php endif; ?>
					</tbody>
				  </table>
				  <div class="content-footer">
					<?php echo $this->ajax_pagination->create_links(); ?>
				  </div>
				</div>
			</div>
		  </div>
		</div>
	  </div>
	</div>
</section>
<!-- Basic Tables end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		
		$(document).on('click', '.click-to-delete', function(){
			var id = $(this).attr('data-id');
			if(confirm('Are you sure?', true))
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/delete",
					data : {id:id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
				
				$('.list-row-'+id).remove();
			}
		})
	});
</script>
<script type="text/javascript">
	function searchFilter(page_num) {
		$('#proccessTime').show();
		page_num = page_num?page_num:0;
		var keywords = $('#keywords').val();
		var from_date = $('#fromDate').val();
		var to_date = $('#toDate').val();
		var month = $('#month').val();
		var year = $('#year').val();
		var limit = $('#limit').val();
		var sortby = $('#shortBy').val();
		$.ajax({
			type: 'POST',
			url: '<?php echo base_url(); ?>apiv1/drugs/'+page_num,
			data:'page='+page_num+'&keywords='+keywords+'&from_date='+from_date+'&to_date='+to_date+'&year='+year+'&month='+month+'&limit='+limit+'&sortby='+sortby,
			dataType:'json',
			beforeSend: function () {
				
			},
			success: function (data) {
				if(data.status == 'ok')
				{
					$('#postList').html(data.content);
					$('#proccessTime').hide();
				}else
				{
					return false;
				}
			}
		});
	}
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click', '#fromDate', function(){
			$("#month").val('');
			$("#year").val('');
		});
		$(document).on('click', '#toDate', function(){
			$("#month").val('');
			$("#year").val('');
		});
		$(document).on('change', '#month', function(){
			$("#fromDate").val('');
			$("#toDate").val('');
		});
		$(document).on('change', '#year', function(){
			$("#fromDate").val('');
			$("#toDate").val('');
		});
	});
</script>


<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo base_url('backend/app-assets/vendors/js/ui/jquery.sticky.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.html5.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.print.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('backend/app-assets/vendors/js/tables/datatable/vfs_fonts.js'); ?>"></script>
<!-- END: Page Vendor JS-->
	
<!-- BEGIN: Page JS-->
<script src="<?php echo base_url('backend/app-assets/js/scripts/datatables/datatable.min.js'); ?>"></script>
<!-- END: Page JS-->
	
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>