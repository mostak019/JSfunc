<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">Suppliers</a></li>
			<li class="breadcrumb-item active">create
			</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<!-- Basic Inputs start -->
<section id="basic-input" class="set-position-relative">
  <div id="createProgressLoader"><span>.....PLEASE WAIT.....</span></div>
  <?php  
		$attr = array('id' => 'createForm', 'class' => '', 'enctype' => 'multipart/form-data');
		echo form_open('', $attr);
  ?>
  <div class="row">
    <div class="col-md-9 card-scroll-container">
		<div id="alert"></div>
        <div class="card" id="generalInformation">
            <div class="card-header">
                <h4 class="card-title">General Information</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <fieldset class="form-group">
                                <label>NAME OF SUPPLIER / COMPANY <span class="mendatory">*</span></label>
                                <input type="text" name="name" class="form-control" placeholder="Enter name of supplier / company">
                            </fieldset>
							<fieldset class="form-group">
                                <label>STATE <span class="mendatory">*</span></label>
                                <select name="state_id" class="form-control" id="onChangeState">
									<option value="">Select State</option>
									<?php 
										$states = $this->Suppliers_model->get_states_by_country(18);
										foreach($states as $state):
									?>
									<option value="<?php echo $state['state_id']; ?>"><?php echo $state['state_name']; ?></option>
									<?php endforeach; ?>
								</select>
                            </fieldset>
							<fieldset class="form-group">
                                <label>ADDRESS <span class="mendatory">*</span></label>
                                <input type="text" name="address" class="form-control" placeholder="Enter address">
                            </fieldset>
							<fieldset class="form-group">
                                <label>E-MAIL ADDRESS <span class="mendatory">*</span></label>
                                <input type="text" name="email_address" class="form-control" placeholder="Enter e-mail address">
                            </fieldset>
							
							<fieldset class="form-group position-relative has-icon-left">
								<label>DATE COMPANY WAS ESTABLISHED</label>
								<input type="text" name="company_established_date" class="form-control pickadate-months-year" placeholder="Enter established date">
								<div class="form-control-position dpicker-icon-position">
									<i class='bx bx-calendar'></i>
								</div>
							</fieldset>
							
							<fieldset class="form-group">
                                <label>TYPE OF BUSINESS</label>
								<ul class="list-unstyled mb-0">
								<?php 
									$type_of_business = array(
														'Retailer',
														'Contractor',
														'Distribution / Dealer',
														'Manufacturer',
														'Wholesaler',
														'Other',
													);
									foreach($type_of_business as $key => $value):
								?>
								  <li class="d-inline-block mr-2 mb-1">
									<fieldset>
									  <div class="radio radio-primary">
										  <input type="radio" name="type_of_business" id="colorRadioTypeOfBusiness<?php echo $key; ?>" value="<?php echo $value; ?>" />
										  <label for="colorRadioTypeOfBusiness<?php echo $key; ?>"><?php echo $value; ?></label>
									  </div>
									</fieldset>
								  </li>
								<?php endforeach; ?>
								</ul>
                            </fieldset>
							<fieldset class="form-group">
                                <label>LEGAL STRUCTURE</label>
								<ul class="list-unstyled mb-0">
								<?php 
									$legal_structure = array(
														'Corporation',
														'Partnership',
														'Sole Propietorship',
														'Joint Venture',
														'Other',
													);
									foreach($legal_structure as $key => $value):
								?>
								  <li class="d-inline-block mr-2 mb-1">
									<fieldset>
									  <div class="radio radio-primary">
										  <input type="radio" name="company_legal_structure" id="colorRadioLegalStructure<?php echo $key; ?>" value="<?php echo $value; ?>" />
										  <label for="colorRadioLegalStructure<?php echo $key; ?>"><?php echo $value; ?></label>
									  </div>
									</fieldset>
								  </li>
								<?php endforeach; ?>
								</ul>
                            </fieldset>
                        </div>
                        <div class="col-md-6">
							<fieldset class="form-group">
                                <label>COUNTRY <span class="mendatory">*</span></label>
                                <select name="country_id" class="form-control" id="onChangeCountry">
									<option value="">Select Country</option>
									<?php 
										$countries = $this->Suppliers_model->get_all_countries();
										foreach($countries as $country):
									?>
									<option value="<?php echo $country['country_id']; ?>" <?php echo ($country['country_id'] == 18)? 'selected' : null; ?>><?php echo $country['country_name']; ?></option>
									<?php endforeach; ?>
								</select>
                            </fieldset>
							<fieldset class="form-group">
                                <label>CITY <span class="mendatory">*</span></label>
                                <select name="city_id" class="form-control" id="onChangeCityContent" disabled>
									<option value="">Select City</option>
								</select>
                            </fieldset>
							<fieldset class="form-group">
                                <label>TELEPHONE NUMBER</label>
                                <input type="text" name="telephone_number" class="form-control" placeholder="Enter telephone number">
                            </fieldset>
							<fieldset class="form-group">
                                <label>FAX NUMBER</label>
                                <input type="text" name="fax_number" class="form-control" placeholder="Enter fax number">
                            </fieldset>
							<fieldset class="form-group">
                                <label>WEBSITE ADDRESS</label>
                                <input type="text" name="website_address" class="form-control" placeholder="Enter website address">
                            </fieldset>
							<fieldset class="form-group">
                                <label>SERVICE AREA</label>
                                <ul class="list-unstyled mb-0">
								<?php 
									$service_area = array(
														'Local',
														'Regional',
														'National',
														'International',
													);
									foreach($service_area as $key => $value):
								?>
								  <li class="d-inline-block mr-2 mb-1">
									<fieldset>
									  <div class="radio radio-primary">
										  <input type="radio" name="service_area" id="colorRadio<?php echo $key; ?>" value="<?php echo $value; ?>" />
										  <label for="colorRadio<?php echo $key; ?>"><?php echo $value; ?></label>
									  </div>
									</fieldset>
								  </li>
								<?php endforeach; ?>
								</ul>
                            </fieldset>
							<fieldset class="form-group">
                                <label style="width:100%">COMPANY LOGO (If any)</label>
								<div style="margin-bottom:5px;"><img id="photoPreview" src="<?php echo base_url('backend/tools/no-image.png'); ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></div>
                                <input type="file" id="onchangeFile" name="logo" />
                            </fieldset>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="card set-position-relative" id="contactInformation">
			<span class="btn btn-primary add-more-contact-person" data-repeater-create="" type="button" style="position: absolute;right: 5px;top: 5px;padding: 2px 10px;font-size: 13px;"><i class="bx bxs-add-to-queue"></i> ADD MORE</span>
            <div class="card-header">
                <h4 class="card-title">Contact Information</h4>
            </div>
            <div class="card-content">
                <div class="card-body" id="multipleContactDetails">
					
					<div class="supplier-contact-person-details-row">
						<div class="row"><strong>CONTACT PERSON : 01</strong></div>
						<div class="row supplier-contact-person-details">
							<div class="col-md-6">
								<fieldset class="form-group">
									<label>NAME OF CONTACT PERSON</label>
									<input type="text" name="contact_full_name_1" class="form-control" placeholder="Enter contact person name" required />
								</fieldset>
								<fieldset class="form-group">
									<label>EMAIL ADDRESS</label>
									<input type="text" name="contact_email_address_1" class="form-control" placeholder="Enter email address" />
								</fieldset>
								<fieldset class="form-group">
									<label>MOBILE NUMBER</label>
									<input type="text" name="contact_mobile_number_1" class="form-control" placeholder="Enter mobile number" required />
								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="form-group">
									<label>DESIGNATION</label>
									<input type="text" name="contact_designation_1" class="form-control" placeholder="Enter designation" required />
								</fieldset>
								<fieldset class="form-group">
									<label>TELEPHONE NUMBER</label>
									<input type="text" name="contact_telephone_number_1" class="form-control" placeholder="Enter telephone number">
								</fieldset>
								<fieldset class="form-group">
									<label>WHATSAPP NUMBER</label>
									<input type="text" name="contact_whatsapp_number_1" class="form-control" placeholder="Enter whatsapp number">
								</fieldset>
							</div>
						</div>
						<input type="hidden" name="contact_details[]" value="1" />
					</div>
					
                </div>
            </div>
        </div>
		<div class="card set-position-relative" id="bankingInformation">
			<span class="btn btn-primary add-more-bank-account" data-repeater-create="" type="button" style="position: absolute;right: 5px;top: 5px;padding: 2px 10px;font-size: 13px;"><i class="bx bxs-add-to-queue"></i> ADD MORE</span>
            <div class="card-header">
                <h4 class="card-title">Banking Information</h4>
            </div>
            <div class="card-content">
                <div class="card-body" id="multipleBankAccounts">
					
					<div class="supplier-contact-person-details-row">
						<div class="row"><strong>BANK ACCOUNT : 01</strong></div>
						<div class="row supplier-contact-person-details">
							<div class="col-md-6">
								<fieldset class="form-group">
									<label>BANK NAME</label>
									<input type="text" name="bank_name_1" class="form-control" placeholder="Enter bank name" required />
								</fieldset>
								<fieldset class="form-group">
									<label>A/C NAME</label>
									<input type="text" name="account_name_1" class="form-control" placeholder="Enter account name" required />
								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="form-group">
									<label>BRANCH NAME</label>
									<input type="text" name="branch_name_1" class="form-control" placeholder="Enter branch name" />
								</fieldset>
								<fieldset class="form-group">
									<label>A/C NUMBER</label>
									<input type="text" name="account_number_1" class="form-control" placeholder="Enter account number" required />
								</fieldset>
							</div>
						</div>
						<input type="hidden" name="bank_details[]" value="1" />
					</div>
                </div>
            </div>
        </div>
		<div class="card" id="openingBalance">
            <div class="card-header">
                <h4 class="card-title">Opening Balance</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
					<div class="supplier-contact-person-details-row">
						<div class="row">
							<div class="col-md-6">
								<?php 
									$opbalance_types = array('NA' => 'N/A', 'DEBIT' => 'DUE', 'CREDIT' => 'ADVANCE');
								?>
								<fieldset class="form-group">
									<label>Opening Balance Type</label>
									<select name="opbalance_type" id="onchangeOpeningBalance" class="form-control" required>
										<option value="">Select Opening Balance Type</option>
										<?php foreach($opbalance_types as $key => $value): ?>
										<option value="<?php echo $key; ?>"><?php echo $value; ?></option>
										<?php endforeach; ?>
									</select>
								</fieldset>
								<div id="openingBalanceAmount"></div>
							</div>
							<div class="col-md-6"></div>
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
	<div class="col-md-3">
		<div class="sticky-sidebar" style="width: 350px;">
		  <div class="text-right">
			<a href="<?php echo base_url('purchase/suppliers'); ?>" class="btn btn-custom btn-dark shadow mb-1"><i class="bx bx-left-arrow font-medium-1"></i> BACK TO ALL SUPPLIERS</a>
		  </div>
		  <div class="card">
			<div class="card-content">
			  <div class="card-body">
				  <div class="form-body">
					<div class="row">
					  <div class="col-12">
						<ul id="stickyNavSection">
							<li class="active"><a href="#generalInformation">General Information</a></li>
							<li><a href="#contactInformation">Contact Information</a></li>
							<li><a href="#bankingInformation">Banking Information</a></li>
							<li><a href="#openingBalance">Opening Balance</a></li>
						</ul>
					  </div>
					  <div class="col-12">
						<fieldset class="form-group">
							<label for="disabledInput">Status</label>
							<ul class="list-unstyled mb-0">
							  <li class="d-inline-block mr-2 mb-1">
								<fieldset>
								  <div class="radio radio-shadow">
									  <input type="radio" id="radioshadow1" name="is_active" value="YES" checked />
									  <label for="radioshadow1">Active</label>
								  </div>
								</fieldset>
							  </li>
							  <li class="d-inline-block mr-2 mb-1">
								<fieldset>
								  <div class="radio radio-shadow">
									  <input type="radio" id="radioshadow2" name="is_active" value="NO" />
									  <label for="radioshadow2">Inactive</label>
								  </div>
								</fieldset>
							  </li>
							</ul>
						</fieldset>
					  </div>
					  <div class="justify-content-end justify-content-custom" style="border-top: 1px solid rgba(0,0,0,0.08);padding-top: 15px;width: 100%;text-align: center;">
						<button type="submit" class="btn btn-custom-form btn-primary"><i class="bx bxs-send"></i> Save</button>
						<button type="submit" class="btn btn-custom-form btn-primary"><i class="bx bxs-send"></i> Save & Exit</button>
						<button type="reset" class="btn btn-custom-form btn-light-secondary" style="margin-right:0px;"><i class="bx bx-reset"></i> Reset</button>
					  </div>
					  
					</div>
				  </div>
			  </div>
			</div>
		  </div>
		</div>
    </div>
  </div>
  <?php echo form_close(); ?>
</section>
<!-- Basic Inputs end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#createForm").validate({
			rules:{
				name:{
					required: true,
				},
				address:{
					required: true,
				},
				email_address:{
					required: true,
					email:true,
				},
				country_id:{
					required: true,
				},
				state_id:{
					required: true,
				},
				city_id:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#createProgressLoader').show();
				// your function if, validate is success
				var getFrmData = new FormData(document.getElementById('createForm'));
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/create",
					data : getFrmData,
					dataType : "json",
					cache: false,
					contentType: false,
					processData: false,
					success : function (data) {
						if(data.status == "ok")
						{
							document.getElementById("createForm").reset();
							$("#alert").html(data.alert);
							$('#createProgressLoader').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							 window.setTimeout(function(){
								window.location.href = baseUrl + "purchase/suppliers/view/"+data.formatted_id;
							}, 2000);
							return false;
						}else if(data.status == "error")
						{
							$('#createProgressLoader').hide();
							$("#alert").html(data.alert);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		var rowNumber = 2;
		$(document).on('click', '.add-more-contact-person', function(){
			if(rowNumber < 10)
			{
				var row = '0'+rowNumber;
			}else{
				var row = rowNumber;
			}
			var content = '<div class="supplier-contact-person-details-row">'+
								'<div class="row set-position-relative"><strong>CONTACT PERSON : '+row+'</strong> <span class="delete-contact-details"> REMOVE</span></div>'+
								'<div class="row supplier-contact-person-details">'+
									'<div class="col-md-6">'+
										'<fieldset class="form-group">'+
											'<label>NAME OF CONTACT PERSON</label>'+
											'<input type="text" name="contact_full_name_'+row+'" class="form-control" placeholder="Enter contact person name" required />'+
										'</fieldset>'+
										'<fieldset class="form-group">'+
											'<label>EMAIL ADDRESS</label>'+
											'<input type="text" name="contact_email_address_'+row+'" class="form-control" placeholder="Enter email address">'+
										'</fieldset>'+
										'<fieldset class="form-group">'+
											'<label>MOBILE NUMBER</label>'+
											'<input type="text" name="contact_mobile_number_'+row+'" class="form-control" placeholder="Enter mobile number" required />'+
										'</fieldset>'+
									'</div>'+
									'<div class="col-md-6">'+
										'<fieldset class="form-group">'+
											'<label>DESIGNATION</label>'+
											'<input type="text" name="contact_designation_'+row+'" class="form-control" placeholder="Enter designation" required />'+
										'</fieldset>'+
										'<fieldset class="form-group">'+
											'<label>TELEPHONE NUMBER</label>'+
											'<input type="text" name="contact_telephone_number_'+row+'" class="form-control" placeholder="Enter telephone number">'+
										'</fieldset>'+
										'<fieldset class="form-group">'+
											'<label>WHATSAPP NUMBER</label>'+
											'<input type="text" name="contact_whatsapp_number_'+row+'" class="form-control" placeholder="Enter whatsapp number">'+
										'</fieldset>'+
									'</div>'+
								'</div>'+
								'<input type="hidden" name="contact_details[]" value="'+row+'" />'+
							'</div>';
			$('#multipleContactDetails').append(content);
			rowNumber++;
		});
		$(document).on('click', '.add-more-bank-account', function(){
			if(rowNumber < 10)
			{
				var row = '0'+rowNumber;
			}else{
				var row = rowNumber;
			}
			var content = '<div class="supplier-contact-person-details-row">'+
								'<div class="row set-position-relative"><strong>BANK ACCOUNT : '+row+'</strong> <span class="delete-contact-details"> REMOVE</span></div>'+
								'<div class="row supplier-contact-person-details">'+
									'<div class="col-md-6">'+
										'<fieldset class="form-group">'+
											'<label>BANK NAME</label>'+
											'<input type="text" name="bank_name_'+row+'" class="form-control" placeholder="Enter bank name" required />'+
										'</fieldset>'+
										'<fieldset class="form-group">'+
											'<label>A/C NAME</label>'+
											'<input type="text" name="account_name_'+row+'" class="form-control" placeholder="Enter account name" required />'+
										'</fieldset>'+
									'</div>'+
									'<div class="col-md-6">'+
										'<fieldset class="form-group">'+
											'<label>BRANCH NAME</label>'+
											'<input type="text" name="branch_name_'+row+'" class="form-control" placeholder="Enter branch name" />'+
										'</fieldset>'+
										'<fieldset class="form-group">'+
											'<label>A/C NUMBER</label>'+
											'<input type="text" name="account_number_'+row+'" class="form-control" placeholder="Enter account number" required />'+
										'</fieldset>'+
									'</div>'+
								'</div>'+
								'<input type="hidden" name="bank_details[]" value="'+row+'" />'+
							'</div>';
			$('#multipleBankAccounts').append(content);
			rowNumber++;
		});
		
		$(document).on('click', '.delete-contact-details', function(){
			if(confirm('Are you sure?', true))
			{
				$(this).parent().parent().remove();
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onchangeOpeningBalance', function(){
			var theValue = $(this).val();
			if(theValue == 'DEBIT')
			{
				var content = '<fieldset class="form-group">'+
									'<label>Amount</label>'+
									'<input type="text" name="opbalance_amount" class="form-control format-opening-balance" placeholder="Enter amount" required />'+
								'</fieldset>';
				$('#openingBalanceAmount').html(content);
			}else if(theValue == 'CREDIT'){
				var content = '<fieldset class="form-group">'+
									'<label>Amount</label>'+
									'<input type="text" name="opbalance_amount" class="form-control format-opening-balance" placeholder="Enter amount" required />'+
								'</fieldset>';
				$('#openingBalanceAmount').html(content);
			}else if(theValue == 'NA'){
				var content = '';
				$('#openingBalanceAmount').html(content);
			}else{
				var content = '';
				$('#openingBalanceAmount').html(content);
			}
		});
		
		$(document).on('change', '#onChangeCountry', function(){
			var country_id = $(this).val();
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/suppliers/get_states_by_country",
				data : {country_id:country_id},
				dataType : "json",
				cache: false,
				success : function (data) {
					if(data.status == "ok")
					{
						$("#onChangeState").html(data.content);
						return false;
					}else
					{
						//have end check.
					}
					return false;
				}
			});
		});
		
		$(document).on('change', '#onChangeState', function(){
			var state_id = $(this).val();
			if(state_id != ''){
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/get_cities_by_state",
					data : {state_id:state_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$('#onChangeCityContent').prop("disabled", false);
							$("#onChangeCityContent").html(data.content);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}else{
				$('#onChangeCityContent').prop("disabled", true);
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onchangeFile', function(){
			readFileUrl(this);
		});
	});
	function readFileUrl(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#photoPreview').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<script type="text/javascript">
	$(document).ready(function(){
		// Cache selectors
		var lastId,
			topMenu = $("#stickyNavSection"),
			topMenuHeight = topMenu.outerHeight(),
			// All list items
			menuItems = topMenu.find("a"),
			// Anchors corresponding to menu items
			scrollItems = menuItems.map(function(){
			  var item = $($(this).attr("href"));
			  if (item.length) { return item; }
			});

		// Bind click handler to menu items
		// so we can get a fancy scroll animation
		menuItems.click(function(e){
		  var href = $(this).attr("href"),
			  offsetTop = href === "#" ? 0 : $(href).offset().top-90;
		  $('html, body').stop().animate({ 
			  scrollTop: offsetTop
		  }, 300);
		  e.preventDefault();
		  console.log(offsetTop);
		});

		// Bind to scroll
		$(window).scroll(function(){
		   // Get container scroll position
		   var fromTop = $(this).scrollTop();
		   
		   // Get id of current scroll item
		   var cur = scrollItems.map(function(){
			 if ($(this).offset().top-180 < fromTop)
			   return this;
		   });
		   // Get the id of the current element
		   cur = cur[cur.length-1];
		   var id = cur && cur.length ? cur[0].id : "";
		   
		   if (lastId !== id) {
			   lastId = id;
			   // Set/remove active class
			   menuItems
				 .parent().removeClass("active")
				 .end().filter("[href='#"+id+"']").parent().addClass("active");
		   }                   
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		var project1 = $('.sticky-sidebar').offset();
		var $window = $(window);
		
		$window.scroll(function() {
			if ( $window.scrollTop() >= project1.top) {
				$(".sticky-sidebar").addClass("sticky-active");
			}else{
				$(".sticky-sidebar").removeClass("sticky-active");
			}
		});
	});
</script>	
<script type="text/javascript">
	function formatNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(2));
		return formatTheNumber;
	}
	function deFormatNumber(number) {
		var a = number.replace(/\,/g,'');
		var result = parseFloat(a,10) || 0;
		return result;
	}
	function numberWithCommas(x) {
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	}
	$(document).ready(function(){
		/*********Format number on keyup started**************/
		$(document).on('keyup', '.format-opening-balance', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		/*********Format number on keyup ended**************/
	});
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>