<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#">supplier payments</a></li>
			<li class="breadcrumb-item active">payment receipt</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<section class="invoice-view-wrapper">
	<div class="row">
		<!-- invoice view page -->
		<div class="invoice-container">
			<div class="card invoice-print-area">
				<div class="card-content">
					<?php $company_info = get_company_info(); ?>
					<div class="card-body pb-0" style="padding:10px !important">
						<div class="text-right">
							<div class="invoice-action-btn">
								<a href="<?php echo base_url('purchase/payments/edit/'.$payment_info['payment_formatted_id']); ?>" class="btn btn-info"> <i class="bx bx-edit"></i> <span>Edit</span> </a>
							</div>
							<div class="invoice-action-btn">
								<button class="btn btn-primary invoice-send-btn" data-toggle="modal" data-target="#default"> <i class="bx bx-send"></i> <span>Send</span> </button>
							</div>
							<div class="invoice-action-btn">
								<a class="btn btn-success" href="<?php echo base_url('purchase/payments/download/'); ?>"> <i class='bx bx-download'></i> <span>Download</span> </a>
							</div>
							<div class="invoice-action-btn">
								<button class="btn btn-info invoice-print" onclick="documentPrint()"><i class="bx bx-printer"></i> <span>print</span> </button>
							</div>
						</div>
						<!-- header section -->
						<div class="row">
							<div class="col-md-4">
								<div class="invoice-company-logo"><img src="<?php echo get_company_logo_url(); ?>" alt="Company Logo" /></div>
							</div>
							<div class="col-md-4"></div>
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2><?php echo $company_info['company_name']; ?></h2>
									<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
									<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
									<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
									<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-4"></div>
							<div class="col-md-4" style="color:white;text-align: center;">
								<h4 style="font-size: 15px;margin-top: 5px;margin-bottom: 5px;color: #000">PAYMENT RECEIPT</h4>
								<hr style="margin:0">
							</div>
							<div class="col-md-4 invoice-company-info" style="text-align: right;">
								<p><strong>Date : </strong> <span style="border-bottom:dotted;"><?php echo date("d/m/Y", strtotime($payment_info['payment_date'])); ?></span></p>
							</div>
						</div>
					</div>
					<div class="card-body pb-0" style="padding: 10px;margin-bottom: 25px;">
						<div class="row">
							<div class="col-md-6">
								<div class="invoice-company-info invoice-customer-info">
									<p><strong>Receipt No : </strong> <?php echo $payment_info['payment_receipt_number']; ?></p>
									<p><strong>Paid To : </strong> <?php echo $payment_info['supplier_name']; ?></p>
									<p><strong>Cell No : </strong> <?php echo $payment_info['supplier_telephone_number']; ?></p>
									<?php if($payment_info['payment_method'] == 'CASH'): ?>
									<p><strong>Payment Method :</strong> CASH (<?php echo $payment_info['account_title']; ?>)</p>
									
									<?php elseif($payment_info['payment_method'] == 'CHEQUE'): ?>
									<p><strong>Payment Method :</strong> CHEQUE (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>Cheque Number :</strong> <?php echo $payment_info['cheque_number']; ?> (<strong>Deposit Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['cheque_deposit_date'])); ?>)</p>
									
									<?php elseif($payment_info['payment_method'] == 'BANK_FUND_TRANSFER'): ?>
									<p><strong>Payment Method :</strong> BANK FUND TRANSFER (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>Transfer Receipt Number :</strong> <?php echo $payment_info['fundtransfer_receipt_number']; ?> (<strong>Transfer Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['fundtransfer_date'])); ?>)</p>
									
									<?php elseif($payment_info['payment_method'] == 'MOBILE_BANKING'): ?>
									<p><strong>Payment Method :</strong> MOBILE BANKING (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>A/C Number :</strong> <?php echo $payment_info['account_number']; ?></p>
									
									<?php elseif($payment_info['payment_method'] == 'MOBILE_BANKING'): ?>
									<p><strong>Payment Method :</strong> MOBILE BANKING (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>A/C Number :</strong> <?php echo $payment_info['account_number']; ?></p>
									
									<?php 
										else:
										$another_method = explode(' ', $payment_info['payment_method']);
										$payment_method = array_pop($another_method);
									?>
										<p><strong>Payment Method :</strong> <?php echo str_replace('_', ' ', $payment_info['payment_method']); ?></p>
										<p><strong>CR Note Amount :</strong> <?php echo str_replace('_', ' ', $payment_info['crnote_amount']); ?></p>
										<?php if($payment_method == 'CASH'): ?>
										<p><strong>A/C :</strong> CASH (<?php echo $payment_info['account_title']; ?>)</p>
										
										<?php elseif($payment_method == 'CHEQUE'): ?>
										<p><strong>Bank :</strong> <?php echo $payment_info['account_title']; ?></p>
										<p><strong>Cheque Number :</strong> <?php echo $payment_info['cheque_number']; ?> (<strong>Deposit Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['cheque_deposit_date'])); ?>)</p>
										
										<?php elseif($payment_method == 'BANK_FUND_TRANSFER'): ?>
										<p><strong>Payment Method :</strong> BANK FUND TRANSFER (<?php echo $payment_info['account_title']; ?>)</p>
										<p><strong>Receipt Number :</strong> <?php echo $payment_info['fundtransfer_receipt_number']; ?> (<strong>Transfer Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['fundtransfer_date'])); ?>)</p>
										
										<?php elseif($payment_method == 'MOBILE_BANKING'): ?>
										<p><strong>Payment Method :</strong> MOBILE BANKING (<?php echo $payment_info['account_title']; ?>)</p>
										<p><strong>A/C Number :</strong> <?php echo $payment_info['account_number']; ?></p>
										<?php endif; ?>
										
									<?php endif; ?>
									
									<p><strong>Paid By :</strong> <?php echo $payment_info['admin_full_name']; ?></p>
								</div>
							</div>
							<div class="col-md-2"></div>
							<div class="col-md-4 text-right">
								<div class="invoice-company-info invoice-salesman-info">
									<p><strong>Payment Amount : </strong> <?php echo number_format(floatval($payment_info['payment_amount']), 0, '.', ','); ?> /-</p>
								</div>
							</div>
						</div>
					</div>
					
					<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($payment_info['payment_amount']); ?>)</p>
					<!-- invoice subtotal -->
					<div class="card-body pt-0" style="padding: 0 10px 15px;margin-top:20px;">
						<div class="row">
							<div class="col-md-4">
								<div class="text-left">
									<span style="font-size: 12px;border-top: 1px dashed #333;">Prepared By</span>
								</div>
							</div>
							<div class="col-md-4">
								<div class="text-center">
									<span style="font-size: 12px;border-top: 1px dashed #333;">Received by</span>
								</div>
							</div>
							<div class="col-md-4">
								<div class="text-right">
									<span style="font-size: 12px;border-top: 1px dashed #333;">Approved By</span>
								</div>
							</div>
						</div>
						<hr />
						<p class="text-center">
							Thanks for your business with us. <br />
							<span class="d-inline-block">2020 &copy; PHARMACY CHAIN</span>.
							<span class="d-sm-inline-block d-none">POWERED BY<a class="text-uppercase" href="https://cthealth-bd.com" target="_blank"><strong style="color:#040569"> CT HEALTH LTD</strong></a></span>
						</p>
					</div>
				</div>
			</div>
		</div>
		
		<div class="invoice-container" id="printCopy" style="display:none">
			<div class="card invoice-print-area">
				<div class="card-content">
					<?php $company_info = get_company_info(); ?>
					<div class="card-body pb-0" style="padding:10px !important">
						<!-- header section -->
						<div class="row">
							<div class="col-md-4">
								<div class="invoice-company-logo"><img src="<?php echo get_company_logo_url(); ?>" alt="Company Logo" /></div>
							</div>
							<div class="col-md-4"></div>
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2><?php echo $company_info['company_name']; ?></h2>
									<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
									<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
									<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
									<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-4"></div>
							<div class="col-md-4" style="color:white;text-align: center;">
								<h4 style="font-size: 15px;margin-top: 5px;margin-bottom: 5px;color: #000">PAYMENT RECEIPT</h4>
								<hr style="margin:0">
							</div>
							<div class="col-md-4 invoice-company-info" style="text-align: right;">
								<p><strong>Date : </strong> <span style="border-bottom:dotted;"><?php echo date("d/m/Y", strtotime($payment_info['payment_date'])); ?></span></p>
							</div>
						</div>
					</div>
					<div class="card-body pb-0" style="padding: 10px;margin-bottom: 25px;">
						<div class="row">
							<div class="col-md-6">
								<div class="invoice-company-info invoice-customer-info">
									<p><strong>Receipt No : </strong> <?php echo $payment_info['payment_receipt_number']; ?></p>
									<p><strong>Paid To : </strong> <?php echo $payment_info['supplier_name']; ?></p>
									<p><strong>Cell No : </strong> <?php echo $payment_info['supplier_telephone_number']; ?></p>
									<?php if($payment_info['payment_method'] == 'CASH'): ?>
									<p><strong>Payment Method :</strong> CASH (<?php echo $payment_info['account_title']; ?>)</p>
									
									<?php elseif($payment_info['payment_method'] == 'CHEQUE'): ?>
									<p><strong>Payment Method :</strong> CHEQUE (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>Cheque Number :</strong> <?php echo $payment_info['cheque_number']; ?> (<strong>Deposit Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['cheque_deposit_date'])); ?>)</p>
									
									<?php elseif($payment_info['payment_method'] == 'BANK_FUND_TRANSFER'): ?>
									<p><strong>Payment Method :</strong> BANK FUND TRANSFER (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>Receipt Number :</strong> <?php echo $payment_info['fundtransfer_receipt_number']; ?> (<strong>Transfer Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['fundtransfer_date'])); ?>)</p>
									
									<?php elseif($payment_info['payment_method'] == 'MOBILE_BANKING'): ?>
									<p><strong>Payment Method :</strong> MOBILE BANKING (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>A/C Number :</strong> <?php echo $payment_info['account_number']; ?></p>
									
									<?php elseif($payment_info['payment_method'] == 'MOBILE_BANKING'): ?>
									<p><strong>Payment Method :</strong> MOBILE BANKING (<?php echo $payment_info['account_title']; ?>)</p>
									<p><strong>A/C Number :</strong> <?php echo $payment_info['account_number']; ?></p>
									
									<?php 
										else:
										$another_method = explode(' ', $payment_info['payment_method']);
										$payment_method = array_pop($another_method);
									?>
										<p><strong>Payment Method :</strong> <?php echo str_replace('_', ' ', $payment_info['payment_method']); ?></p>
										<p><strong>CR Note Amount :</strong> <?php echo str_replace('_', ' ', $payment_info['crnote_amount']); ?></p>
										<?php if($payment_method == 'CASH'): ?>
										<p><strong>A/C :</strong> CASH (<?php echo $payment_info['account_title']; ?>)</p>
										
										<?php elseif($payment_method == 'CHEQUE'): ?>
										<p><strong>Bank :</strong> <?php echo $payment_info['account_title']; ?></p>
										<p><strong>Cheque Number :</strong> <?php echo $payment_info['cheque_number']; ?> (<strong>Deposit Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['cheque_deposit_date'])); ?>)</p>
										
										<?php elseif($payment_method == 'BANK_FUND_TRANSFER'): ?>
										<p><strong>Payment Method :</strong> BANK FUND TRANSFER (<?php echo $payment_info['account_title']; ?>)</p>
										<p><strong>Receipt Number :</strong> <?php echo $payment_info['fundtransfer_receipt_number']; ?> (<strong>Transfer Date : </strong><?php echo date("d/m/Y", strtotime($payment_info['fundtransfer_date'])); ?>)</p>
										
										<?php elseif($payment_method == 'MOBILE_BANKING'): ?>
										<p><strong>Payment Method :</strong> MOBILE BANKING (<?php echo $payment_info['account_title']; ?>)</p>
										<p><strong>A/C Number :</strong> <?php echo $payment_info['account_number']; ?></p>
										<?php endif; ?>
										
									<?php endif; ?>
									
									<p><strong>Paid By :</strong> <?php echo $payment_info['admin_full_name']; ?></p>
								</div>
							</div>
							<div class="col-md-2"></div>
							<div class="col-md-4 text-right">
								<div class="invoice-company-info invoice-salesman-info">
									<p><strong>Payment Amount : </strong> <?php echo number_format(floatval($payment_info['payment_amount']), 0, '.', ','); ?> /-</p>
								</div>
							</div>
						</div>
					</div>
					
					<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($payment_info['payment_amount']); ?>)</p>
					<!-- invoice subtotal -->
					<div class="card-body pt-0" style="padding: 0 10px 15px;margin-top:20px;">
						<div class="row">
							<div class="col-md-4">
								<div class="text-left">
									<span style="font-size: 12px;border-top: 1px dashed #333;">Prepared By</span>
								</div>
							</div>
							<div class="col-md-4">
								<div class="text-center">
									<span style="font-size: 12px;border-top: 1px dashed #333;">Received by</span>
								</div>
							</div>
							<div class="col-md-4">
								<div class="text-right">
									<span style="font-size: 12px;border-top: 1px dashed #333;">Approved By</span>
								</div>
							</div>
						</div>
						<hr />
						<p class="text-center">
							Thanks for your business with us. <br />
							<span class="d-inline-block">2020 &copy; PHARMACY CHAIN</span>.
							<span class="d-sm-inline-block d-none">POWERED BY<a class="text-uppercase" href="https://cthealth-bd.com" target="_blank"><strong style="color:#040569"> CT HEALTH LTD</strong></a></span>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="modal fade text-left" id="default" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
<?php  
	$attr = array('id' => 'sendInvoice', 'class' => '');
	echo form_open('', $attr);
?>
  <div class="modal-dialog modal-dialog-scrollable" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h3 class="modal-title" id="myModalLabel1">SEND INVOICE TO YOUR FRIENDS</h3>
	  </div>
	  <div class="modal-body">
		<input type="hidden" name="formatted_id" value="<?php echo $payment_info['payment_formatted_id']; ?>" />
		<div id="modalFormProccess" class="text-center" style="display:none;"><span>.....please wait.....</span></div>
		<div id="alert"></div>
		<fieldset class="form-group">
			<label>EMAIL ADDRESS <span class="mendatory">*</span></label>
			<input type="text" name="email" class="form-control" placeholder="Enter email address">
		</fieldset>
		<fieldset class="form-group">
			<label>SAY SOMETHING </label>
			<textarea name="note" class="form-control" cols="30" rows="5"></textarea>
		</fieldset>
	  </div>
	  <div class="modal-footer">
		<span style="cursor:pointer" class="btn btn-light-secondary" data-dismiss="modal">
		  <i class="bx bx-x d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Cancel</span>
		</span>
		<button type="submit" class="btn btn-primary ml-1">
		  <i class="bx bx-check d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Send</span>
		</button>
	  </div>
	</div>
  </div>
<?php echo form_close(); ?>
</div>
<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#sendInvoice").validate({
			rules:{
				email:{
					required: true,
					email:true,
				},
			},
			submitHandler : function () {
				$('#modalFormProccess').show();
				// your function if, validate is success
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/send",
					data : $('#sendInvoice').serialize(),
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							document.getElementById("sendInvoice").reset();
							$("#alert").html(data.alert);
							$('#modalFormProccess').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							return false;
						}else if(data.status == "error")
						{
							$('#modalFormProccess').hide();
							$("#alert").html(data.alert);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	function documentPrint() 
	{
	  var documentContent=document.getElementById('printCopy');
	  var newWin=window.open('','Print-Window');
	  var content = '<!DOCTYPE html>'+
					'<html class="loading" lang="en" data-textdirection="ltr">'+
					'<head>'+
						'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'+
						'<meta http-equiv="X-UA-Compatible" content="IE=edge">'+
						'<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">'+
						'<title>Print Copy</title>'+
						'<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('backend/app-assets/images/ico/favicon.ico'); ?>">'+
						'<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/pages/app-invoice.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap-extended.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/colors.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/components.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/dark-layout.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/semi-dark-layout.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/assets/css/style.css'); ?>">'+
					'</head>'+
					'<body onload="window.print()">'+documentContent.innerHTML+'</body></html>';

	  newWin.document.open();
	  newWin.document.write(content);
	  newWin.document.close();
	  setTimeout(function(){newWin.close();},10);
	}
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>