<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a>
			</li>
			<li class="breadcrumb-item"><a href="#">purchase</a></li>
			<li class="breadcrumb-item"><a href="#">supplier payments</a></li>
			<li class="breadcrumb-item active">edit payment</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<!-- Basic Inputs start -->
<section id="basic-input" class="set-position-relative">
  <div id="createProgressLoader"><span>.....PLEASE WAIT.....</span></div>
  <?php  
		$attr = array('id' => 'createForm', 'class' => '', 'enctype' => 'multipart/form-data');
		echo form_open('', $attr);
		
		$ac_types_array = array(
							'CASH'               => 'PETTY_CASH',
							'CHEQUE'             => 'BANK',
							'BANK_FUND_TRANSFER' => 'BANK',
							'MOBILE_BANKING'     => 'MOBILE_BANKING',
						);
		if(isset($supplier_info['payment_method']) && array_key_exists($supplier_info['payment_method'], $ac_types_array)){
			$accounts = get_accounts_by_type($ac_types_array[$supplier_info['payment_method']]);
			$payment_method = $supplier_info['payment_method'];
		}elseif(isset($supplier_info['payment_method']) && !array_key_exists($supplier_info['payment_method'], $ac_types_array)){
			$another_method = explode(' ', $supplier_info['payment_method']);
			$payment_method = array_pop($another_method);
			$accounts = (array_key_exists($payment_method, $ac_types_array))? get_accounts_by_type($ac_types_array[$payment_method]) : array();
		}else{
			$accounts = get_accounts_by_type('PETTY_CASH');
			$payment_method = '';
		}
		
		$account_list = '<option value="">Select Account</option>';  
		foreach($accounts as $account):
			if($supplier_info['payment_account_id'] !== '' && $supplier_info['payment_account_id'] == $account['account_id'])
			{
				$selected_option = 'selected';
			}else{
				$selected_option = null;
			}
			$account_list .= '<option value="'.$account['account_id'].'" '.$selected_option.'>'.$account['account_title'].'</option>';
		endforeach;
		
		$accountsJs = get_accounts_by_type('PETTY_CASH');
		$account_list_js = '<option value="">Select Account</option>';  
		foreach($accountsJs as $accountJs):
			$account_list_js .= '<option value="'.$accountJs['account_id'].'">'.$accountJs['account_title'].'</option>';
		endforeach;
  ?>
  <div class="row">
	<input type="hidden" name="payment_id" value="<?php echo $supplier_info['payment_id']; ?>" />
    <div class="col-md-2"></div>
    <div class="col-md-8 card-scroll-container">
		<div id="alert"></div>
        <div class="card" id="generalInformation">
            <div class="card-header put-relative">
                <h4 class="card-title text-center">Supplier Payment </h4>
            </div>
            <div class="card-content">
                <div class="card-body">
					<div id="itemDescriptions">
						<?php $logo_url = $this->Payments_model->get_company_logo_url($supplier_info['supplier_id']); ?>
						<div class="row" style="margin-bottom: 20px;background: #f0f0f0;padding: 15px 0;border-radius: 3px;box-shadow: 0 1px 2px;">
							<div class="col-lg-12">
								<div class="row">
									<div class="col-md-6 text-right">
										<div class="info-area">
											<img style="width: 130px;height: 95px;border-radius: 3px;border: 0;box-shadow: 0 1px 2px;" src="<?php echo $logo_url; ?>" alt="LOGO" />
										</div>
									</div>
									<div class="col-md-6 text-left">
										<div class="info-area">
											<p style="font-size: 16px;margin-bottom: 5px;color: #0c0a80;font-weight: 600;"><strong><?php echo $supplier_info['supplier_name']; ?></strong></p>
											<p style="font-size: 12px;line-height: 16px;"><strong>Address : </strong><?php echo $supplier_info['supplier_address']; ?> 
											<br /> <strong>Cell No : </strong><?php echo $supplier_info['supplier_telephone_number']; ?>
											<br /> <strong>Balance Information : </strong> 
											(
											<?php 
												$balance_info = get_the_supplier_balance($supplier_info['supplier_id']); 
												if($balance_info['balance_type'] == 'DUE')
												{
													echo '<strong style="color:#E00">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
												}elseif ($balance_info['balance_type'] == 'ADVANCE') {
													echo '<strong style="color:#0A0">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
												}elseif ($balance_info['balance_type'] == 'BALANCE') {
													echo '<strong style="color:#333">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
												}else{
													echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 2, '.', ',');
												}
											?>
											)
											</p>
											<input type="hidden" name="supplier_id" value="<?php echo $supplier_info['supplier_id']; ?>" />
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="row" style="margin-bottom:30px;">
							<div class="col-md-12">
								<div class="invoice-product-details table-responsive">
									<h3 class="invoice-items-title">DUE INVOICES DETAILS</h3>
									<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
										<thead>
											<tr class="border-0">
												<th style="width:5%">S.No</th>
												<th class="text-center" style="width:15%;">INVOICE NUMBER</th>
												<th class="text-center" style="width:14%;">ORDER NUMBER</th>
												<th class="text-center" style="width: 15%;">NET TOTAL</th>
												<th class="text-center" style="width: 15%;">PAID AMOUNT</th>
												<th class="text-center text-bold-500" style="color:#A00;width: 15%;">DUE AMOUNT</th>
												<th class="text-center text-bold-500" style="color:#A00;width: 17%;">PAYMENT</th>
												<th class="text-center text-bold-500" style="color:#A00;width: 5%;">REMOVE</th>
											</tr>
										</thead>
										<tbody id="invoiceContents">
											<?php 
												$sl = 1;
												$due_invoice_net_total = 0;
												$due_paid_total        = 0;
												$due_amount_total      = 0;
												$payment_amount_total      = 0;
												$invoices = get_supplier_due_invoices($supplier_info['supplier_id']);
												if(is_array($invoices) && count($invoices) !== 0):
												foreach($invoices as $invoice):
												if(isset($_GET['oinv']) && $_GET['oinv'] !== $invoice['invoice_number'])
												{
													continue;
												}
												$inv_paid_total = invoice_paid_total($invoice['due_invoice_id']);
												$inv_due_total  = invoice_due_total($invoice['due_invoice_id']);
												$due_invoice_net_total += $invoice['due_invoice_net_total'];
												$due_paid_total        += $inv_paid_total;
												$due_amount_total      += $inv_due_total;
												$payment_amount_total  += get_supplier_invoice_payment_amount($supplier_info['payment_id'], $invoice['due_invoice_id']);
											?>
											<tr class="particulars-item-row">
												<td class="text-bold-500 particulars-itm-sl"><?php echo $sl; ?></td>
												<td class="text-center text-bold-500">
													<a href="<?php echo base_url('purchase/view/'.$invoice['order_formatted_id']); ?>" target="__blank"><?php echo $invoice['invoice_number']; ?></a>
													<input type="hidden" name="invoice_number_<?php echo $sl; ?>" value="<?php echo $invoice['invoice_number']; ?>" />
													<input type="hidden" name="invoice_id_<?php echo $sl; ?>" value="<?php echo $invoice['due_invoice_id']; ?>" />
												</td>
												<td class="text-center text-bold-500">
													<?php echo $invoice['order_number']; ?>
													<input type="hidden" name="order_id_<?php echo $sl; ?>" value="<?php echo $invoice['due_order_id']; ?>" />
												</td>
												<td class="text-center text-bold-500">
													<strong>&#2547;</strong> <?php echo number_format(floatval($invoice['due_invoice_net_total']), 0, '.', ','); ?>
													<input type="hidden" name="due_invoice_net_total_<?php echo $sl; ?>" class="due-invoice-net-total due-invoice-net-total-<?php echo $sl; ?>" value="<?php echo $invoice['due_invoice_net_total']; ?>"  />
												</td>
												<td class="text-center text-bold-500">
													<strong>&#2547;</strong> <?php echo number_format(floatval($inv_paid_total), 0, '.', ','); ?>
													<input type="hidden" name="due_invoice_paid_total_<?php echo $sl; ?>" class="due-invoice-paid-total due-invoice-paid-total-<?php echo $sl; ?>" value="<?php echo $inv_paid_total; ?>"  />
												</td>
												<td class="text-center text-bold-500" style="color:#A00">
													<span class="show-invoice-due-total-<?php echo $sl; ?>"><strong>&#2547;</strong> <?php echo number_format(floatval($inv_due_total), 0, '.', ','); ?></span>
													<input type="hidden" name="due_amount_total_<?php echo $sl; ?>" class="due-amount-total-row due-amount-total-<?php echo $sl; ?>" value="<?php echo $inv_due_total; ?>"  />
												</td>
												<td class="text-center text-bold-500">
													<input type="text" value="<?php echo number_format(floatval(get_supplier_invoice_payment_amount($supplier_info['payment_id'], $invoice['due_invoice_id'])), 0, '.', ','); ?>" class="form-control text-center onchange-paid-amount" data-row="<?php echo $sl; ?>" placeholder="Enter amount" autocomplete="off" required />
													<input type="hidden" value="<?php echo get_supplier_invoice_payment_amount($supplier_info['payment_id'], $invoice['due_invoice_id']); ?>" name="due_paid_total_<?php echo $sl; ?>" class="due-paid-total-row due-paid-total-<?php echo $sl; ?>"  />
												</td>
												<td class="text-center text-bold-500" style="color:#A00">
													<span class="invoice-action-view remove-item-from-particulars cursor-pointer" data-row="<?php echo $sl; ?>" style="color:#F00" title="Remove"><i class="bx bxs-x-circle"></i></span>
												</td>
												<input type="hidden" name="rows[]" value="<?php echo $sl; ?>" />
											</tr>
											<?php 
												$sl++;
												endforeach; 
											?>
											<tr>
												<td colspan="3" class="text-right font-weight-bold">Total</td>
												<td class="text-primary text-center font-weight-bold">
													<span id="showDueInvoicesNetTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($due_invoice_net_total), 0, '.', ','); ?></span>
													<input type="hidden" name="due_invoices_net_total" id="dueInvoicesNetTotal" value="<?php echo $due_invoice_net_total ?>" />
												</td>
												<td class="text-primary text-center font-weight-bold">
													<span id="showDueInvoicesPaidTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($due_paid_total), 0, '.', ','); ?></span>
													<input type="hidden" name="due_invoices_paid_total" id="dueInvoicesPaidTotal" value="<?php echo $due_paid_total ?>" />
												</td>
												<td class="text-primary text-center font-weight-bold">
													<span id="showDueInvoicesAmountTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($due_amount_total), 0, '.', ','); ?></span>
													<input type="hidden" name="due_invoices_amount_total" id="dueInvoicesAmountTotal" value="<?php echo $due_amount_total ?>" />
												</td>
												<td class="text-primary text-center font-weight-bold">
													<span id="showDueInvoicesPaymentTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($payment_amount_total), 0, '.', ','); ?></span>
													<input type="hidden" name="due_invoices_payment_total" id="dueInvoicesPaymentTotal" value="<?php echo $payment_amount_total; ?>" />
												</td>
											</tr>
											<?php else: ?>
											<tr><td class="text-center" colspan="8">NO DUE INVOICE FOUND</td></tr>
											<?php endif; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<?php if(is_array($invoices) && count($invoices) !== 0): ?>
						<div class="row">
							<div class="col-md-4" style="max-width:30% !important"></div>
							<div class="col-md-5" style="max-width:60% !important">
								<fieldset class="form-group">
									<label style="width: 100%;">CREDIT NOTE</label>
									<select name="has_credit_note" class="form-control" id="hasCreditNote" style="width: 25%;float: left;margin-right: 10px;" readonly>
										<option value="NO" <?php echo ($supplier_info['payment_has_crnote'] == 'NO')? 'selected' : null; ?>>NO</option>
										<option value="YES" <?php echo ($supplier_info['payment_has_crnote'] == 'YES')? 'selected' : null; ?>>YES</option>
									</select>
									<input type="text" name="credit_amount" value="<?php echo ($supplier_info['crnote_amount'])? number_format(floatval($supplier_info['crnote_amount']), 0, '.', ',') : null; ?>" id="creditValue" class="form-control format-credit-amount" placeholder="Enter credit note amount" style="width: 72.2%;float: left;" autocomplete="off" <?php echo ($supplier_info['payment_has_crnote'] == 'NO')? 'disabled' : null; ?> />
								</fieldset>
								<fieldset class="form-group">
									<label>PAYABLE AMOUNT</label>
									<span id="displayPayableAmount"><input type="text" class="form-control" value="<?php echo '&#2547; '.number_format(floatval($supplier_info['payment_amount']), 0, '.', ','); ?>" disabled /></span>
									<input type="hidden" name="payable_amount" id="payableAmount" value="<?php echo $supplier_info['payment_amount']; ?>" />
								</fieldset>
								<div id="morePaymentOption">
									<?php if($supplier_info['payment_has_crnote'] == 'YES'): ?>
									<fieldset class="form-group">
										<label>NEED MORE PAYMENT OPTIONS ? <span class="mendatory">*</span></label>
										<select name="more_payment_option" class="form-control" id="morePaymentOption" readonly>
											<option value="NO" <?php echo ($supplier_info['payment_has_option'] == 'NO')? 'selected' : null; ?>>NO</option>
											<option value="YES" <?php echo ($supplier_info['payment_has_option'] == 'YES')? 'selected' : null; ?>>YES</option>
										</select>
									</fieldset>
									<?php endif; ?>
								</div>
								<div id="paymentMethod">
									<?php 
										if($payment_method !== '' && ($supplier_info['payment_has_crnote'] == 'NO' || $supplier_info['payment_has_option'] == 'YES')): 
									?>
									<fieldset class="form-group">
										<label>PAYMENT METHOD <span class="mendatory">*</span></label>
										<select name="payment_method" class="form-control" id="paymentType" required>
											<option value="CASH" <?php echo ($payment_method == 'CASH')? 'selected' : null; ?>>CASH</option>
											<option value="CHEQUE" <?php echo ($payment_method == 'CHEQUE')? 'selected' : null; ?>>CHEQUE</option>
											<option value="BANK_FUND_TRANSFER" <?php echo ($payment_method == 'BANK_FUND_TRANSFER')? 'selected' : null; ?>>BANK FUND TRANSFER</option>
											<option value="MOBILE_BANKING" <?php echo ($payment_method == 'MOBILE_BANKING')? 'selected' : null; ?>>MOBILE BANKING</option>
										</select>
									</fieldset>
									<?php endif; ?>
								</div>
								<div id="paymentAccounts" class="set-position-relative">
									<?php 
										if($payment_method !== '' && ($supplier_info['payment_has_crnote'] == 'NO' || $supplier_info['payment_has_option'] == 'YES')): 
									?>
									<?php if($supplier_info['payment_account_id'] !== ''): ?>
									<?php  
										$account_balance = get_account_balance($supplier_info['payment_account_id']);
										$b_content = '<span style="margin-left:60px;font-size: 13px;background: #F0F0F0;padding: 3px 10px;border-radius: 4px;text-align: center;display: block;line-height: 22px;"><strong style="color:#0A0;display: block;">Available Balance </strong> <span>'.number_format(floatval($account_balance), 2, '.', ',').'</span> <strong> (BDT)</strong></span>';
									?>
									<div style="position: absolute;top: 7px;right: -210px;width: 260px;" id="accountBalance"><?php echo $b_content; ?></div>
									<fieldset class="form-group">
										<label>ACCOUNT <span class="mendatory">*</span></label>
										<select name="account_id" id="onChangeAccount" class="form-control" required>
											<?php echo $account_list; ?>
										</select>
									</fieldset>
									<?php endif; ?>
									<?php endif; ?>
								</div>
								<div id="paymentOptionCheque">
									<?php 
										if($payment_method == 'CHEQUE'): 
										$attach_url = get_cheque_scan_url($supplier_info['cheque_id']);
									?>
										<fieldset class="form-group">
											<label>CHEQUE NUMBER <span class="mendatory">*</span></label>
											<input type="text" name="cheque_number" value="<?php echo $supplier_info['cheque_number']; ?>" class="form-control" placeholder="Enter cheque number" required />
										</fieldset>
										<fieldset class="form-group">
											<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>
											<input type="text" name="deposit_branch" value="<?php echo $supplier_info['cheque_deposit_branch']; ?>" class="form-control" placeholder="Enter deposit branch" required />
										</fieldset>
										<fieldset class="form-group">
											<label style="width:100%">UPLOAD DEPOSIT SLIP</label>
											<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded deposit slip</a>
											<input type="file" id="onchangeFile" name="deposit_slip" />
										</fieldset>
									<?php endif; ?>
								</div>
								<div id="paymentOptionBankFundTransfer">
									<?php 
										if($payment_method == 'BANK_FUND_TRANSFER'):
										$attach_url = get_receipt_scan_url($supplier_info['fundtransfer_id']);
									?>
										<fieldset class="form-group">
											<label>RECEIPT NUMBER <span class="mendatory">*</span></label>
											<input type="text" name="receipt_number" value="<?php echo $supplier_info['fundtransfer_receipt_number']; ?>" class="form-control" placeholder="Enter receipt number" required />
										</fieldset>
										<fieldset class="form-group">
											<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>
											<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded transfer receipt</a>
											<input type="file" id="onchangeFile" name="transfer_receipt" />
										</fieldset>
									<?php endif; ?>
								</div>
								<div id="paymentAmount">
									<?php if($supplier_info['payment_has_crnote'] == 'NO' || $supplier_info['payment_has_option'] == 'YES'): ?>
									<fieldset class="form-group">
										<label>AMOUNT <span class="mendatory">*</span></label>
										<input type="text" name="amount" value="<?php echo ($supplier_info['payment_amount_without_crnote'])? number_format(floatval($supplier_info['payment_amount_without_crnote']), 0, '.', ',') : null; ?>" id="payAmount" class="form-control format-payment-amount" placeholder="Enter amount" required />
									</fieldset>
									<?php endif; ?>
								</div>
								<fieldset class="form-group position-relative has-icon-left">
									<label>PAYMENT DATE <span class="mendatory">*</span></label>
									<input type="text" name="payment_date" class="form-control pickadate-months-year" value="<?php echo date("d F, Y", strtotime($supplier_info['payment_date'])); ?>" required />
									<div class="form-control-position dpicker-icon-position">
										<i class='bx bx-calendar'></i>
									</div>
								</fieldset>
								<fieldset class="form-group">
									<label>NOTE </label>
									<textarea name="note" class="form-control" cols="30" rows="5"><?php echo $supplier_info['payment_note']; ?></textarea>
								</fieldset>
							</div>
							<div class="col-md-4" style="max-width:30% !important;"></div>
						</div>
						<div class="form-body">
							<div class="row">
							  <div class="justify-content-end justify-content-custom" style="border-top: 1px solid rgba(0,0,0,0.08);padding-top: 15px;width: 100%;text-align: center;">
								<button type="submit" class="btn btn-custom-form btn-primary"><i class="bx bxs-send"></i> Update Payment</button>
							  </div>
							</div>
						</div>
						<?php endif; ?>
					</div>
                </div>
            </div>
        </div>
    </div>
	<div class="col-md-2"></div>
  </div>
  <?php echo form_close(); ?>
</section>
<!-- Basic Inputs end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#createForm").validate({
			rules:{
				has_credit_note:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#createProgressLoader').show();
				// your function if, validate is success
				var getFrmData = new FormData(document.getElementById('createForm'));
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/payments/update",
					data : getFrmData,
					dataType : "json",
					cache: false,
					contentType: false,
					processData: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$("#alert").html(data.alert);
							$('#createProgressLoader').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							 window.setTimeout(function(){
								window.location.href = baseUrl + "purchase/payments/vouchar/"+data.formatted_id;
							}, 2000);
							return false;
						}else if(data.status == "error")
						{
							$('#createProgressLoader').hide();
							$("#alert").html(data.alert);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onchangeFile', function(){
			readFileUrl(this);
		});
	});
	function readFileUrl(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#photoPreview').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<script type="text/javascript">
	$(document).ready(function(){
		var accounts = '<?php echo $account_list_js; ?>';
		$(document).on('change', '#hasCreditNote', function(){
			var has_credit_note = $(this).val();
			if(has_credit_note == 'YES')
			{
				$('#creditValue').prop('disabled', false);
				$('#creditValue').prop('required', true);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
				$('#paymentAmount').html('');
				var more_payment_option_content = '<fieldset class="form-group">'+
														'<label>NEED MORE PAYMENT OPTIONS ? <span class="mendatory">*</span></label>'+
														'<select name="more_payment_option" class="form-control" id="morePaymentOption" readonly>'+
															'<option value="NO">NO</option>'+
															'<option value="YES">YES</option>'+
														'</select>'+
													'</fieldset>';
				$('#morePaymentOption').html(more_payment_option_content);
			}else if(has_credit_note == 'NO'){
				$('#creditValue').val('');
				$('#creditValue').prop('disabled', true);
				$('#creditValue').prop('required', false);
				set_payable_amount();
				var payment_option_cash_content = '<fieldset class="form-group">'+
														'<label>PAYMENT TYPE <span class="mendatory">*</span></label>'+
														'<select name="payment_method" class="form-control" id="paymentType" required>'+
															'<option value="CASH">CASH</option>'+
															'<option value="CHEQUE">CHEQUE</option>'+
															'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
															'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
														'</select>'+
													'</fieldset>';
				$('#paymentMethod').html(payment_option_cash_content);
				
				var payment_accounts_content = '<div style="position: absolute;top: 7px;right: -210px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				var payment_amount_content = '<fieldset class="form-group">'+
												'<label>AMOUNT <span class="mendatory">*</span></label>'+
												'<input type="text" id="payAmount" name="amount" class="form-control format-payment-amount" placeholder="Enter amount" required />'+
											'</fieldset>';
				$('#paymentAmount').html(payment_amount_content);
				
				$('#morePaymentOption').html('');
				$('#paymentOptionBankFundTransfer').html('');
				
			}
		});
		
		//Select Payment options
		
		$(document).on('change', '#morePaymentOption', function(){
			var nees_more_payment_option = $(this).val();
			if(nees_more_payment_option == 'YES')
			{
				$('#paymentOptionBankFundTransfer').html('');
				var payment_option_cash_content = '<fieldset class="form-group">'+
														'<label>PAYMENT TYPE <span class="mendatory">*</span></label>'+
														'<select name="payment_method" class="form-control" id="paymentType" required>'+
															'<option value="CASH">CASH</option>'+
															'<option value="CHEQUE">CHEQUE</option>'+
															'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
															'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
														'</select>'+
													'</fieldset>';
				$('#paymentMethod').html(payment_option_cash_content);
				
				var payment_accounts_content = '<div style="position: absolute;top: 7px;right: -210px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				var payment_amount_content = '<fieldset class="form-group">'+
												'<label>AMOUNT <span class="mendatory">*</span></label>'+
												'<input type="text" name="amount" id="payAmount" class="form-control format-payment-amount" placeholder="Enter amount" required />'+
											'</fieldset>';
				$('#paymentAmount').html(payment_amount_content);
				
			}else if(nees_more_payment_option == 'NO'){
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
				$('#paymentAmount').html('');
			}
		});
		
		$(document).on('change', '#paymentType', function(){
			var payment_type = $(this).val();
			if(payment_type == 'CASH'){
				
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
			}else if(payment_type == 'CHEQUE'){
				$('#accountBalance').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
				var payment_option_cheque = '<fieldset class="form-group">'+
												'<label>CHEQUE NUMBER <span class="mendatory">*</span></label>'+
												'<input type="text" name="cheque_number" class="form-control" placeholder="Enter cheque number" required />'+
											'</fieldset>'+
											'<fieldset class="form-group">'+
												'<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>'+
												'<input type="text" name="deposit_branch" class="form-control" placeholder="Enter deposit branch" required />'+
											'</fieldset>'+
											'<fieldset class="form-group">'+
												'<label style="width:100%">UPLOAD DEPOSIT SLIP</label>'+
												'<input type="file" id="onchangeFile" name="deposit_slip" />'+
											'</fieldset>';
				$('#paymentOptionCheque').html(payment_option_cheque);
				
			}else if(payment_type == 'BANK_FUND_TRANSFER'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionMobileBanking').html('');
				
				var payment_option_bank_fund_transfer_content = '<fieldset class="form-group">'+
																	'<label>RECEIPT NUMBER <span class="mendatory">*</span></label>'+
																	'<input type="text" name="receipt_number" class="form-control" placeholder="Enter receipt number" required />'+
																'</fieldset>'+
																'<fieldset class="form-group">'+
																	'<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>'+
																	'<input type="file" id="onchangeFile" name="transfer_receipt" />'+
																'</fieldset>';
				$('#paymentOptionBankFundTransfer').html(payment_option_bank_fund_transfer_content);
			}else if(payment_type == 'MOBILE_BANKING'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}
			
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/payments/accounts_by_type",
				data : {type:payment_type},
				dataType : "json",
				cache: false,
				success : function (data) {
					if(data.status == "ok")
					{
						$("#onChangeAccount").html(data.content);
						return false;
					}
					return false;
				}
			});
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onChangeAccount', function(){
			var account_id = $(this).val();
			if(account_id !== ''){
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/payments/get_account_balance",
					data : {id:account_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$("#accountBalance").html(data.content);
							if(data.available_balance < 1)
							{
								$('#payAmount').prop('disabled', true);
							}else{
								$('#payAmount').prop('disabled', false);
							}
							return false;
						}else
						{
							$("#accountBalance").html('');
							return false;
						}
						return false;
					}
				});
			}else{
				$("#accountBalance").html('');
				return false;
			}
		});
	});
</script>
<script type="text/javascript">
	function formatIntNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(0));
		return formatTheNumber;
	}
	function formatNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(2));
		return formatTheNumber;
	}
	function deFormatNumber(number) {
		var a = number.replace(/\,/g,'');
		var result = parseFloat(a,10) || 0;
		return result;
	}
	function numberWithCommas(x) {
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	}
	$(document).ready(function(){
		/*********Format number on keyup started**************/
		$(document).on('keyup', '.format-credit-amount', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.format-payment-amount', function(event){
			  // skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.onchange-paid-amount', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		$(document).on('keyup', '.onchange-sale-price', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		/*********Format number on keyup ended**************/
	});
</script>
<script type="text/javascript">
	function calculation()
	{
		//Set total net amount
		var total_net_amount = get_total_net_amount();
		$('#showDueInvoicesNetTotal').html('<strong>&#2547;</strong> '+formatIntNumber(total_net_amount));
		$('#dueInvoicesNetTotal').val(total_net_amount);
		
		//Set total paid amount
		var total_paid_amount = get_total_paid_amount();
		$('#showDueInvoicesPaidTotal').html('<strong>&#2547;</strong> '+formatIntNumber(total_paid_amount));
		$('#dueInvoicesPaidTotal').val(total_paid_amount);
		
		//Set total due amount
		var total_due_amount = get_total_due_amount();
		$('#showDueInvoicesAmountTotal').html('<strong>&#2547;</strong> '+formatIntNumber(total_due_amount));
		$('#dueInvoicesAmountTotal').val(total_due_amount);
		
		//Set total due amount
		var total_payment_amount = get_total_payment_amount();
		$('#showDueInvoicesPaymentTotal').html('<strong>&#2547;</strong> '+formatIntNumber(total_payment_amount));
		$('#dueInvoicesPaymentTotal').val(total_payment_amount);
		
		
		//Set payable amount
		set_payable_amount();
	}
	
	function calculation_invoice_due(row)
	{
		//set value to row due total
		var invoice_net_total  = parseFloat($('.due-invoice-net-total-'+row).val()) || 0;
		var invoice_invoice_paid_total = parseFloat($('.due-invoice-paid-total-'+row).val()) || 0;
		var invoice_paid_total = parseFloat($('.due-paid-total-'+row).val()) || 0;
		var invoice_due_total  = invoice_net_total - (invoice_invoice_paid_total + invoice_paid_total);
		$('.show-invoice-due-total-'+row).html('<strong>&#2547;</strong> '+formatIntNumber(invoice_due_total));
		$('.due-amount-total-'+row).val(invoice_due_total);
		
		calculation();
	}
	
	function set_payable_amount()
	{
		var total_paid_amount = get_total_payment_amount();
		var credit_amount = parseFloat(deFormatNumber($('#creditValue').val())) || 0;
		var total_payable_amount = total_paid_amount - credit_amount;
		$('#payableAmount').val(total_payable_amount);
		$('#displayPayableAmount').html('<input type="text" class="form-control" value="&#2547; '+formatIntNumber(total_payable_amount)+'" disabled />');
	}
	
	function get_total_net_amount()
	{
		var netAmounts = $('.due-invoice-net-total');
		var totalAmount = 0;
		for(var i=0; i < netAmounts.length; i++){
			var value = parseFloat($(netAmounts.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function get_total_paid_amount()
	{
		var paidAmounts = $('.due-invoice-paid-total');
		var totalAmount = 0;
		for(var i=0; i < paidAmounts.length; i++){
			var value = parseFloat($(paidAmounts.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function get_total_payment_amount()
	{
		var paidAmounts = $('.due-paid-total-row');
		var totalAmount = 0;
		for(var i=0; i < paidAmounts.length; i++){
			var value = parseFloat($(paidAmounts.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function get_total_payment_amount()
	{
		var paidAmounts = $('.due-paid-total-row');
		var totalAmount = 0;
		for(var i=0; i < paidAmounts.length; i++){
			var value = parseFloat($(paidAmounts.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function get_total_due_amount(){
		var dueAmounts = $('.due-amount-total-row');
		var totalAmount = 0;
		for(var i=0; i < dueAmounts.length; i++){
			var value = parseFloat($(dueAmounts.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	function setSl(selector)
	{
		var particularsItmSl = $(selector);
		for(var i=0; i < particularsItmSl.length; i++){
			var element = particularsItmSl.eq(i);
			var x = i+1;
			var sl = x;
			$(element).text(sl);
		}
	}
	$(document).ready(function(){
		$(document).on('keyup', '.onchange-paid-amount', function(){
			var row_number = $(this).attr('data-row');
			var invoiceNetTotal = parseFloat($('.due-invoice-net-total-'+row_number).val()) || 0
			var invoicePaidTotal = parseFloat($('.due-invoice-paid-total-'+row_number).val()) || 0
			var dueValue = invoiceNetTotal - invoicePaidTotal;
			var paidValue = parseFloat(deFormatNumber($(this).val())) || 0;
			if(paidValue > dueValue){
				alert("Sorry the due amount is only : "+formatIntNumber(dueValue));
				$(this).val('');
				$('.due-paid-total-'+row_number).val(formatIntNumber(0));
				calculation_invoice_due(row_number);
			}else{
				$('.due-paid-total-'+row_number).val(paidValue);
				calculation_invoice_due(row_number);
			}
		});
		
		$(document).on('keyup', '#creditValue', function(){
			var payAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			var payableAmount = parseFloat(deFormatNumber($('#dueInvoicesPaymentTotal').val())) || 0;
			if(payAmount > payableAmount)
			{
				alert("Sorry payable amount is : "+ formatIntNumber(payableAmount));
				$(this).val('');
				set_payable_amount();
			}else{
				set_payable_amount();
			}
		});
		$(document).on('keyup', '#payAmount', function(){
			var payAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			var payableAmount = parseFloat(deFormatNumber($('#payableAmount').val())) || 0;
			if(payAmount > payableAmount)
			{
				alert("Sorry payable amount is : "+ formatIntNumber(payableAmount));
				$(this).val('');
			}
		});
		
		$(document).on('click', '.remove-item-from-particulars', function(){	
			var row_number = $(this).attr('data-row');
			if(confirm('Are you sure?', true))
			{
				$(this).parent().parent().remove();
				setSl(".particulars-itm-sl");
				var totalItems = $('.particulars-item-row').length;
				if(totalItems < 1)
				{
					var content = '<tr>'+
									'<tr><td class="text-center" colspan="8">NO DUE INVOICE FOUND</td></tr>'+
								'</tr>';
					$("#invoiceContents").html(content);
				}
				
				$('#creditValue').val('');
				$('#payAmount').val('');
				calculation();
				return false;
			}
		});
	});
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>