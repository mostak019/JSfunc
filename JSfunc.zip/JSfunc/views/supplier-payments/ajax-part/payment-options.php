<?php 
	$logo_url = $this->Suppliers_model->get_company_logo_url($supplier_info['supplier_id']);
	$accounts = get_accounts_by_type('PETTY_CASH');
	$account_list = '<option value="">Select Account</option>';  
	foreach($accounts as $account):
		$account_list .= '<option value="'.$account['account_id'].'">'.$account['account_title'].'</option>';
	endforeach;
?>
<div class="row" style="margin-bottom: 20px;background: #f0f0f0;padding: 15px 0;border-radius: 3px;box-shadow: 0 1px 2px;">
	<div class="col-lg-12">
		<div class="row">
			<div class="col-md-6 text-right">
				<div class="info-area">
					<img style="width: 130px;height: 95px;border-radius: 3px;border: 0;box-shadow: 0 1px 2px;" src="<?php echo $logo_url; ?>" alt="LOGO" />
				</div>
			</div>
			<div class="col-md-6 text-left">
				<div class="info-area">
					<p style="font-size: 16px;margin-bottom: 5px;color: #0c0a80;font-weight: 600;"><strong><?php echo $supplier_info['supplier_name']; ?></strong></p>
					<p style="font-size: 12px;line-height: 16px;"><strong>Address : </strong><?php echo $supplier_info['supplier_address']; ?> 
					<br /> <strong>Cell No : </strong><?php echo $supplier_info['supplier_telephone_number']; ?>
					<br /> <strong>Balance Information : </strong> 
					(
					<?php 
						$balance_info = get_the_supplier_balance($supplier_info['supplier_id']); 
						if($balance_info['balance_type'] == 'DUE')
						{
							echo '<strong style="color:#E00">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
						}elseif ($balance_info['balance_type'] == 'ADVANCE') {
							echo '<strong style="color:#0A0">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
						}elseif ($balance_info['balance_type'] == 'BALANCE') {
							echo '<strong style="color:#333">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
						}else{
							echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 2, '.', ',');
						}
					?>
					)
					</p>
					<input type="hidden" name="supplier_id" value="<?php echo $supplier_info['supplier_id']; ?>" />
				</div>
			</div>
		</div>
	</div>
</div>
<div class="row" style="margin-bottom:30px;">
	<div class="col-md-12">
		<div class="invoice-product-details table-responsive">
			<h3 class="invoice-items-title">DUE INVOICES DETAILS</h3>
			<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
				<thead>
					<tr class="border-0">
						<th style="width:5%">S.No</th>
						<th class="text-center" style="width:15%;">INVOICE NUMBER</th>
						<th class="text-center" style="width:14%;">ORDER NUMBER</th>
						<th class="text-center" style="width: 15%;">NET TOTAL</th>
						<th class="text-center" style="width: 15%;">PAID AMOUNT</th>
						<th class="text-center text-bold-500" style="color:#A00;width: 15%;">DUE AMOUNT</th>
						<th class="text-center text-bold-500" style="color:#A00;width: 17%;">PAYMENT</th>
						<th class="text-center text-bold-500" style="color:#A00;width: 5%;">REMOVE</th>
					</tr>
				</thead>
				<tbody id="invoiceContents">
					<?php 
						$sl = 1;
						$due_invoice_net_total = 0;
						$due_paid_total        = 0;
						$due_amount_total      = 0;
						$invoices = get_supplier_due_invoices($supplier_info['supplier_id']);
						if(is_array($invoices) && count($invoices) !== 0):
						foreach($invoices as $invoice):
						$inv_paid_total = invoice_paid_total($invoice['due_invoice_id']);
						$inv_due_total  = invoice_due_total($invoice['due_invoice_id']);
						$due_invoice_net_total += $invoice['due_invoice_net_total'];
						$due_paid_total        += $inv_paid_total;
						$due_amount_total      += $inv_due_total;
					?>
					<tr class="particulars-item-row">
						<td class="text-bold-500 particulars-itm-sl"><?php echo $sl; ?></td>
						<td class="text-center text-bold-500">
							<a href="<?php echo base_url('purchase/view/'.$invoice['order_formatted_id']); ?>" target="__blank"><?php echo $invoice['invoice_number']; ?></a>
							<input type="hidden" name="invoice_number_<?php echo $sl; ?>" value="<?php echo $invoice['invoice_number']; ?>" />
							<input type="hidden" name="invoice_id_<?php echo $sl; ?>" value="<?php echo $invoice['due_invoice_id']; ?>" />
						</td>
						<td class="text-center text-bold-500">
							<?php echo $invoice['order_number']; ?>
							<input type="hidden" name="order_id_<?php echo $sl; ?>" value="<?php echo $invoice['due_order_id']; ?>" />
						</td>
						<td class="text-center text-bold-500">
							<strong>&#2547;</strong> <?php echo number_format(floatval($invoice['due_invoice_net_total']), 0, '.', ','); ?>
							<input type="hidden" name="due_invoice_net_total_<?php echo $sl; ?>" class="due-invoice-net-total due-invoice-net-total-<?php echo $sl; ?>" value="<?php echo $invoice['due_invoice_net_total']; ?>"  />
						</td>
						<td class="text-center text-bold-500">
							<strong>&#2547;</strong> <?php echo number_format(floatval($inv_paid_total), 0, '.', ','); ?>
							<input type="hidden" name="due_invoice_paid_total_<?php echo $sl; ?>" class="due-invoice-paid-total due-invoice-paid-total-<?php echo $sl; ?>" value="<?php echo $inv_paid_total; ?>"  />
						</td>
						<td class="text-center text-bold-500" style="color:#A00">
							<span class="show-invoice-due-total-<?php echo $sl; ?>"><strong>&#2547;</strong> <?php echo number_format(floatval($inv_due_total), 0, '.', ','); ?></span>
							<input type="hidden" name="due_amount_total_<?php echo $sl; ?>" class="due-amount-total-row due-amount-total-<?php echo $sl; ?>" value="<?php echo $inv_due_total; ?>"  />
						</td>
						<td class="text-center text-bold-500">
							<input type="text" class="form-control text-center onchange-paid-amount" data-row="<?php echo $sl; ?>" placeholder="Enter amount" autocomplete="off" required />
							<input type="hidden" name="due_paid_total_<?php echo $sl; ?>" class="due-paid-total-row due-paid-total-<?php echo $sl; ?>"  />
						</td>
						<td class="text-center text-bold-500" style="color:#A00">
							<span class="invoice-action-view remove-item-from-particulars cursor-pointer" data-row="<?php echo $sl; ?>" style="color:#F00" title="Remove"><i class="bx bxs-x-circle"></i></span>
						</td>
						<input type="hidden" name="rows[]" value="<?php echo $sl; ?>" />
					</tr>
					<?php 
						$sl++;
						endforeach; 
					?>
					<tr>
						<td colspan="3" class="text-right font-weight-bold">Total</td>
						<td class="text-primary text-center font-weight-bold">
							<span id="showDueInvoicesNetTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($due_invoice_net_total), 0, '.', ','); ?></span>
							<input type="hidden" name="due_invoices_net_total" id="dueInvoicesNetTotal" value="<?php echo $due_invoice_net_total ?>" />
						</td>
						<td class="text-primary text-center font-weight-bold">
							<span id="showDueInvoicesPaidTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($due_paid_total), 0, '.', ','); ?></span>
							<input type="hidden" name="due_invoices_paid_total" id="dueInvoicesPaidTotal" value="<?php echo $due_paid_total ?>" />
						</td>
						<td class="text-primary text-center font-weight-bold">
							<span id="showDueInvoicesAmountTotal"><strong>&#2547;</strong> <?php echo number_format(floatval($due_amount_total), 0, '.', ','); ?></span>
							<input type="hidden" name="due_invoices_amount_total" id="dueInvoicesAmountTotal" value="<?php echo $due_amount_total ?>" />
						</td>
						<td class="text-primary text-center font-weight-bold">
							<span id="showDueInvoicesPaymentTotal"><strong>&#2547;</strong> <?php echo number_format(floatval(0), 0, '.', ','); ?></span>
							<input type="hidden" name="due_invoices_payment_total" id="dueInvoicesPaymentTotal" value="<?php echo 0; ?>" />
						</td>
					</tr>
					<?php else: ?>
					<tr><td class="text-center" colspan="8">NO DUE INVOICE FOUND</td></tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php if(is_array($invoices) && count($invoices) !== 0): ?>
<div class="row">
	<div class="col-md-4" style="max-width:30% !important"></div>
	<div class="col-md-5" style="max-width:60% !important">
		<fieldset class="form-group">
			<label style="width: 100%;">CREDIT NOTE</label>
			<select name="has_credit_note" class="form-control" id="hasCreditNote" style="width: 25%;float: left;margin-right: 10px;" readonly>
				<option value="NO">NO</option>
				<option value="YES">YES</option>
			</select>
			<input type="text" name="credit_amount" id="creditValue" class="form-control format-credit-amount" placeholder="Enter credit note amount" style="width: 72.2%;float: left;" autocomplete="off" disabled />
		</fieldset>
		<fieldset class="form-group">
			<label>PAYABLE AMOUNT</label>
			<span id="displayPayableAmount"><input type="text" class="form-control" value="<?php echo '&#2547; '.number_format(floatval(0), 0, '.', ','); ?>" disabled /></span>
			<input type="hidden" name="payable_amount" id="payableAmount" value="<?php echo 0; ?>" />
		</fieldset>
		<div id="morePaymentOption"></div>
		<div id="paymentMethod">
			<fieldset class="form-group">
				<label>PAYMENT METHOD <span class="mendatory">*</span></label>
				<select name="payment_method" class="form-control" id="paymentType" required>
					<option value="CASH">CASH</option>
					<option value="CHEQUE">CHEQUE</option>
					<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>
					<option value="MOBILE_BANKING">MOBILE BANKING</option>
				</select>
			</fieldset>
		</div>
		<div id="paymentAccounts" class="set-position-relative">
			<div style="position: absolute;top: 7px;right: -210px;width: 260px;" id="accountBalance"></div>
			<fieldset class="form-group">
				<label>ACCOUNT <span class="mendatory">*</span></label>
				<select name="account_id" id="onChangeAccount" class="form-control" required>
					<?php echo $account_list; ?>
				</select>
			</fieldset>
		</div>
		<div id="paymentOptionCheque"></div>
		<div id="paymentOptionBankFundTransfer"></div>
		<div id="paymentAmount">
			<fieldset class="form-group">
				<label>AMOUNT <span class="mendatory">*</span></label>
				<input type="text" name="amount" id="payAmount" class="form-control format-payment-amount" placeholder="Enter amount" required />
			</fieldset>
		</div>
		<fieldset class="form-group position-relative has-icon-left">
			<label>PAYMENT DATE <span class="mendatory">*</span></label>
			<input type="text" name="payment_date" class="form-control pickadate-months-year" value="<?php echo date("d F, Y"); ?>" required />
			<div class="form-control-position dpicker-icon-position">
				<i class='bx bx-calendar'></i>
			</div>
		</fieldset>
		<fieldset class="form-group">
			<label>NOTE </label>
			<textarea name="note" class="form-control" cols="30" rows="5"></textarea>
		</fieldset>
	</div>
	<div class="col-md-4" style="max-width:30% !important;"></div>
</div>
<div class="form-body">
	<div class="row">
	  <div class="justify-content-end justify-content-custom" style="border-top: 1px solid rgba(0,0,0,0.08);padding-top: 15px;width: 100%;text-align: center;">
		<button type="submit" class="btn btn-custom-form btn-primary"><i class="bx bxs-send"></i> Add Payment</button>
	  </div>
	</div>
</div>
<?php endif; ?>