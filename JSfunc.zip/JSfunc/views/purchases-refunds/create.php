<?php require_once APPPATH.'modules/common/header.php'; ?>
<?php 
	$accounts = get_accounts_by_type('PETTY_CASH');
	$account_list = '<option value="">Select Account</option>';  
	foreach($accounts as $account):
		$account_list .= '<option value="'.$account['account_id'].'">'.$account['account_title'].'</option>';
	endforeach;
?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#">purchase refund</a></li>
			<li class="breadcrumb-item active">create</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<!-- Basic Inputs start -->
<section id="basic-input" class="set-position-relative">
  <div id="createProgressLoader"><span>.....PLEASE WAIT.....</span></div>
  <?php  
		$attr = array('id' => 'createForm', 'class' => '', 'enctype' => 'multipart/form-data');
		echo form_open('', $attr);
  ?>
  
  <div class="row">
    <div class="col-md-12">
		<div id="alert"></div>
        <div class="row" style="margin: 25px;">
			<div class="col-12 text-center">
				<div class="form-group add-product-search-field">
					<label style="display: block;" for="first-name-vertical">SEARCH INVOICE</label>
					<input name="srcfield" type="text" id="searchInvoices" class="form-control ui-autocomplete-input" style="width: 50%;display: inline-block;" placeholder="Search invoice by invoice number, order number etc ...." autocomplete="off"> 
				</div>
			</div>
		</div>
    </div>
  </div>
  
  <div id="refundInvoiceItemsContent"><h2 class="water-mark-text">PURCHASE REFUND</h2></div>
  
  <?php echo form_close(); ?>
</section>
<!-- Basic Inputs end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#createForm").validate({
			rules:{
				refund_date:{
					required: true,
				},
				branch:{
					required: true,
				},
				warehouse:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#createProgressLoader').show();
				// your function if, validate is success
				var getFrmData = new FormData(document.getElementById('createForm'));
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/purchaserefund/create",
					data : getFrmData,
					dataType : "json",
					cache: false,
					contentType: false,
					processData: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$("#alert").html(data.alert);
							$('#createProgressLoader').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							 var content = '<tr>'+
											'<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="12">NO PRODUCT ADDED</td>'+
										'</tr>';
							$("#productContents").html(content);
							showCalculation();
							
							window.setTimeout(function(){
								window.location.href = baseUrl + "purchase/purchaserefund/vouchar/"+data.formatted_id;
							}, 2000);
							return false;
						}else if(data.status == "error")
						{
							$('#createProgressLoader').hide();
							$("#alert").html(data.alert);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
		
		$(document).on('change', '#onChangeBranch', function(){
			var branch_id = $(this).val();
			if(branch_id !== '')
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "inventories/warehouse/get_warehouses",
					data : {branch_id:branch_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$('#warehouseContent').html(data.content);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#searchInvoices').autocomplete({
		  source: function( request, response ) {
			  if(request.term !== ''){
				  $.ajax({
					  type: "GET",
					  url: baseUrl + "purchase/purchaserefund/srcinvoices",
					  dataType: "json",
					  data: {
						q: request.term,
					  },
					  success: function( data ) {
						response( data.content);
					  }
				 });
			  }else{
				  return false;
			  }
		  },
		  select: function (event, ui) {
					//var hiddenValue = $(this).attr('data-section');
					//$(this).val(ui.item.label); // display the selected text
					$(this).val(''); // display the selected text
					//$('#'+hiddenValue).val(ui.item.value); // save selected id to hidden input
					$.ajax({
						type : "POST",
						url : baseUrl + "purchase/purchaserefund/getinvoiceinfo",
						data : {id:ui.item.value},
						dataType : "json",
						cache: false,
						success : function (data) {
							if(data.status == "ok")
							{
								$("#refundInvoiceItemsContent").html(data.content);
								$(".pickadate-months-year").pickadate({
									selectYears: !0,
									selectMonths: !0
								});
								return false;
							}else
							{
								//have end check.
							}
							return false;
						}
					});
					return false;
		  },
		  open: function() {
			$( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
		  },
		  close: function() {
			$( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
		  }
		}).autocomplete( "instance" )._renderItem = function( ul, item ) {
		  return $( "<li>" )
			.append( '<div class="ui-item-list-wrapp">'+item.label+'<span style="color:#2c2c8c"> | '+item.supplier+'</span></div>' )
			.appendTo( ul );
		};
	});
</script>
<script type="text/javascript">
	//Add product functions
	$(document).ready(function(){
		$(document).on('keyup', '.onchange-item-refund-qty', function(){
			var refundType = document.getElementById('refundType');
			var amountDistribute = document.getElementById('amountDistribute');
			var paymentMethod = document.getElementById('paymentMethod');
			var paymentAccounts = document.getElementById('paymentAccounts');
			var paymentOptionCheque = document.getElementById('paymentOptionCheque');
			var paymentOptionBankFundTransfer = document.getElementById('paymentOptionBankFundTransfer');
			$(refundType).html('<option value="">Select Type</option>');
			$(amountDistribute).html('');
			$(paymentMethod).html('');
			$(paymentAccounts).html('');
			$(paymentOptionCheque).html('');
			$(paymentOptionBankFundTransfer).html('');
			
			var rowNumber = $(this).attr('data-row');
			var qty = parseFloat(deFormatNumber($('.qty-'+rowNumber).val())) || 0;
			var refudnQty = parseFloat(deFormatNumber($(this).val())) || 0;
			if(refudnQty <= qty)
			{
				var purchasePrice = parseFloat(deFormatNumber($('.purchase-price-'+rowNumber).val())) || 0;
				var refundCharge  = parseFloat(deFormatNumber($('.item-refund-charge-'+rowNumber).val())) || 0;
				var subtotal = add_product_subtotal_amount(refudnQty, purchasePrice);
				var refundAmount = subtotal - refundCharge;
				
				//Show item refund amount
				$('.show-refund-amounts-'+rowNumber).val(formatNumber(refundAmount));
				$('.refund-amounts-'+rowNumber).val(refundAmount);
				
				//Show item refund subtotal
				$('.show-refund-subtotal-amounts-'+rowNumber).val(formatNumber(subtotal));
				$('.refund-subtotal-amounts-'+rowNumber).val(subtotal);
				
				showCalculation();
			}else{
				alert('Sorry! you can add max qty - '+qty);
				$(this).val('');
				return false;
			}
		});
		$(document).on('keyup', '.onchange-item-refund-charge', function(){
			var refundType = document.getElementById('refundType');
			var amountDistribute = document.getElementById('amountDistribute');
			var paymentMethod = document.getElementById('paymentMethod');
			var paymentAccounts = document.getElementById('paymentAccounts');
			var paymentOptionCheque = document.getElementById('paymentOptionCheque');
			var paymentOptionBankFundTransfer = document.getElementById('paymentOptionBankFundTransfer');
			$(refundType).html('<option value="">Select Type</option>');
			$(amountDistribute).html('');
			$(paymentMethod).html('');
			$(paymentAccounts).html('');
			$(paymentOptionCheque).html('');
			$(paymentOptionBankFundTransfer).html('');
			
			var rowNumber = $(this).attr('data-row');
			var refudnQty = parseFloat(deFormatNumber($('.item-refund-qty-'+rowNumber).val())) || 0;
			
			var purchasePrice = parseFloat(deFormatNumber($('.purchase-price-'+rowNumber).val())) || 0;
			var refundCharge  = parseFloat(deFormatNumber($(this).val())) || 0;
			var subtotal = add_product_subtotal_amount(refudnQty, purchasePrice);
			var refundAmount = subtotal - refundCharge;
			
			//Show item refund amount
			$('.show-refund-amounts-'+rowNumber).val(formatNumber(refundAmount));
			$('.refund-amounts-'+rowNumber).val(refundAmount);
			
			//Show item refund subtotal
			$('.show-refund-subtotal-amounts-'+rowNumber).val(formatNumber(subtotal));
			$('.refund-subtotal-amounts-'+rowNumber).val(subtotal);
			
			showCalculation();
		});
	});
	
	function supplier_balance_update_by_refund_charge(refundChargeAmount)
	{
		var balanceType = $('#balanceType').val();
		var balanceAmount = parseFloat($('#balanceAmount').val()) || 0;
		var updatedBalanceType = balanceType;
		var updatedBalance = balanceAmount;
		if(refundChargeAmount !== '')
		{
			if(balanceType == 'ADVANCE'){
				if(balanceAmount == refundChargeAmount)
				{
					var updatedBalanceType = 'BALANCE';
					var updatedBalance = 0;
					var updatedBalanceContent = '<strong style="color:#333">BALANCE</strong> : '+formatNumber(updatedBalance);
					$('#spShowBalance').html(updatedBalanceContent);
				}else if(balanceAmount > refundChargeAmount){
					var updatedBalanceType = 'ADVANCE';
					var updatedBalance = balanceAmount - refundChargeAmount;
					var updatedBalanceContent = '<strong style="color:#0A0">ADVANCE</strong> : '+formatNumber(updatedBalance);
					$('#spShowBalance').html(updatedBalanceContent);
				}else if(balanceAmount < refundChargeAmount){
					var updatedBalanceType = 'DUE';
					var updatedBalance = refundChargeAmount - balanceAmount;
					var updatedBalanceContent = '<strong style="color:#A00">DUE</strong> : '+formatNumber(updatedBalance);
					$('#spShowBalance').html(updatedBalanceContent);
				}
			}else if(balanceType == 'DUE'){
				var updatedBalanceType = 'DUE';
				var updatedBalance = balanceAmount + refundChargeAmount;
				var updatedBalanceContent = '<strong style="color:#A00">DUE</strong> : '+formatNumber(updatedBalance);
				$('#spShowBalance').html(updatedBalanceContent);
			}else if(balanceType == 'BALANCE'){
				var updatedBalanceType = 'DUE';
				var updatedBalance = balanceAmount + refundChargeAmount;
				var updatedBalanceContent = '<strong style="color:#A00">DUE</strong> : '+formatNumber(updatedBalance);
				$('#spShowBalance').html(updatedBalanceContent);
			}
		}
		
		$('#balanceTypeUpdated').val(updatedBalanceType);
		$('#balanceAmountUpdated').val(updatedBalance);
	}
	
	function add_product_subtotal_amount(qty, purchasePrice)
	{
		var subtotal = purchasePrice * qty;
		return subtotal;
	}
</script>
<script type="text/javascript">
/*********Calculation related functions started**************/
	function getRefundSubtotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat($(particularsItmPrice.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function getRefundChargeTotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat(deFormatNumber($(particularsItmPrice.eq(i)).val())) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function getRefundAmountTotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat($(particularsItmPrice.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function showCalculation()
	{
		var refundSubtotal    = getRefundSubtotal('.refund-subtotal-amounts');
		var refundChargetotal = getRefundChargeTotal('.item-refund-charge-total');
		var refundAmountTotal = getRefundAmountTotal('.refund-amounts');
		var refundNetTotal    = refundSubtotal;
		var refundNetProfit   = refundChargetotal;
		
		//Show amount in refund sub total
		$('#refundSubtotal').val(formatNumber(refundSubtotal));
		
		//Show amount in refund charge total
		$('#refundChargeTotal').val(formatNumber(refundChargetotal));
		
		//Update supplier balance
		supplier_balance_update_by_refund_charge(refundChargetotal);
		
		//Show amount in refund amount total
		$('#refundAmountTotal').val(formatNumber(refundAmountTotal));
		$('#displayReceivableAmount').html('<input type="text" class="form-control" value="&#2547; '+formatNumber(refundAmountTotal)+'" disabled="" />');
		$('#receivableAmount').val(refundAmountTotal);
		if(refundAmountTotal == 0)
		{
			var refundType = document.getElementById('refundType');
			var amountDistribute = document.getElementById('amountDistribute');
			var paymentMethod = document.getElementById('paymentMethod');
			var paymentAccounts = document.getElementById('paymentAccounts');
			var paymentOptionCheque = document.getElementById('paymentOptionCheque');
			var paymentOptionBankFundTransfer = document.getElementById('paymentOptionBankFundTransfer');
			$(refundType).html('<option value="">Select Type</option>');
			$(amountDistribute).html('');
			$(paymentMethod).html('');
			$(paymentAccounts).html('');
			$(paymentOptionCheque).html('');
			$(paymentOptionBankFundTransfer).html('');
		}else{
			var balanceType   = $('#balanceTypeUpdated').val();
			var balanceAmount = parseFloat($('#balanceAmountUpdated').val()) || 0;
			var refundType = document.getElementById('refundType');
			if(balanceType == 'DUE'){
				
				if(refundAmountTotal < balanceAmount){
					var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="DUE_ADJUSTMENT" data-adjust-amount="'+refundAmountTotal+'">Due Adjustment</option>'+
										'<option value="DUE_ADJUSTMENT_AND_MONEY_RETURN" data-adjust-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Due Adjustment & Money Return</option>';
					$(refundType).html(refundTypeContent);
					
				}else if(refundAmountTotal > balanceAmount){
					var DUE_ADJUSTMENT_AND_MONEY_RETURN = refundAmountTotal - balanceAmount;
					var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="DUE_ADJUSTMENT_AND_MONEY_RETURN" data-adjust-amount="'+balanceAmount+'" data-return-amount="'+DUE_ADJUSTMENT_AND_MONEY_RETURN+'">Due Adjustment & Money Return</option>'+
										'<option value="DUE_ADJUSTMENT_AND_ADVANCE_ADD" data-adjust-amount="'+balanceAmount+'" data-advance-amount="'+DUE_ADJUSTMENT_AND_MONEY_RETURN+'">Due Adjustment & Advance Add</option>';
					$(refundType).html(refundTypeContent);
				}else if(refundAmountTotal == balanceAmount){
					var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="ADVANCE_ADD" data-advance-amount="'+refundAmountTotal+'">Advance Add</option>'+
										'<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Advance Add & Money Return</option>';
					$(refundType).html(refundTypeContent);
				}
				
			}else if(balanceType == 'ADVANCE'){
				var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="ADVANCE_ADD" data-advance-amount="'+refundAmountTotal+'">Advance Add</option>'+
										'<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Advance Add & Money Return</option>';
				$(refundType).html(refundTypeContent);
			}else if(balanceType == 'BALANCE'){
				var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="ADVANCE_ADD" data-advance-amount="'+refundAmountTotal+'">Advance Add</option>'+
										'<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Advance Add & Money Return</option>';
				$(refundType).html(refundTypeContent);
			}
		}
		
		//Show amount in refund net total
		$('#showRefundNetTotal').html(formatNumber(refundNetTotal));
		$('#refundNetTotal').val(refundNetTotal);
		
		//Show amount in refund net profit
		$('#showRefundNetProfit').html(formatNumber(refundNetProfit));
		$('#refundNetProfit').val(refundNetProfit);
	}
	function formatIntNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(0));
		return formatTheNumber;
	}
	function formatNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(2));
		return formatTheNumber;
	}
	function deFormatNumber(number) {
		var a = number.replace(/\,/g,'');
		var result = parseFloat(a,10) || 0;
		return result;
	}
	function numberWithCommas(x) {
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	}
	function setSl(selector)
	{
		var particularsItmSl = $(selector);
		for(var i=0; i < particularsItmSl.length; i++){
			var element = particularsItmSl.eq(i);
			var x = i+1;
			if(x<10){
				var sl = '0'+x;
			}else{
				var sl = x;
			}
			$(element).text(sl);
		}
	}
/*********Calculation related functions ended**************/
</script>	
<script type="text/javascript">
	$(document).ready(function(){
		/*********Format number on keyup started**************/
		$(document).on('keyup', '.onchange-item-refund-qty', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.onchange-item-refund-charge', function(event){
			  // skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.format-payment-amount', function(event){
			  // skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		/*********Format number on keyup ended**************/
		
		$(document).on('click', '.remove-item-from-particulars', function(){	
			if(confirm('Are you sure?', true))
			{
				$(this).parent().parent().remove();
				setSl(".particulars-itm-sl");
				var totalItems = $('.particulars-item-row').length;
				if(totalItems < 1)
				{
					var content = '<tr>'+
									'<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="12">NO ITEMS FOUND</td>'+
								'</tr>';
					$("#productContents").html(content);
				}
				showCalculation();
				return false;
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		var accounts = '<?php echo $account_list; ?>';
		$(document).on('change', '#refundType', function(){
			var refundType = $(this).val();
			if(refundType == 'MONEY_RETURN'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var returnAmount = parseFloat(selectedOption.getAttribute('data-return-amount')) || 0;
				var content = '<fieldset class="form-group">'+
								'<label>MONEY RETURN AMOUNT</label>'+
								'<input type="text" id="moneyReturnAmount" class="form-control" value="&#2547; '+formatIntNumber(returnAmount)+'" disabled />'+
								'<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" value="'+returnAmount+'" />'+
							'</fieldset>';
				$('#amountDistribute').html(content);
				
				var payment_pathod = '<fieldset class="form-group">'+
										'<label>PAYMENT METHOD <span class="mendatory">*</span></label>'+
										'<select name="payment_method" class="form-control" id="paymentType" required>'+
											'<option value="CASH">CASH</option>'+
											'<option value="CHEQUE">CHEQUE</option>'+
											'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
											'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
										'</select>'+
									'</fieldset>';
				$('#paymentMethod').html(payment_pathod);
				
				var payment_accounts_content = '<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'DUE_ADJUSTMENT'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var adjustAmount = parseFloat(selectedOption.getAttribute('data-adjust-amount')) || 0;
				var content = '<fieldset class="form-group">'+
								'<label>DUE ADJUSTMENT AMOUNT</label>'+
								'<input type="text" id="dueAdjustmentAmount" class="form-control" value="&#2547; '+formatIntNumber(adjustAmount)+'" disabled />'+
								'<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="'+adjustAmount+'" />'+
							'</fieldset>';
				$('#amountDistribute').html(content);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'){
				var content = '<fieldset class="form-group">'+
									'<label>DUE ADJUSTMENT AMOUNT</label>'+
									'<input type="text" id="dueAdjustmentAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" />'+
								'</fieldset>'+
								'<fieldset class="form-group">'+
									'<label>MONEY RETURN AMOUNT</label>'+
									'<input type="text" id="moneyReturnAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				
				var payment_pathod = '<fieldset class="form-group">'+
										'<label>PAYMENT METHOD <span class="mendatory">*</span></label>'+
										'<select name="payment_method" class="form-control" id="paymentType" required>'+
											'<option value="CASH">CASH</option>'+
											'<option value="CHEQUE">CHEQUE</option>'+
											'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
											'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
										'</select>'+
									'</fieldset>';
				$('#paymentMethod').html(payment_pathod);
				
				var payment_accounts_content = '<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'DUE_ADJUSTMENT_AND_ADVANCE_ADD'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var adjustAmount = parseFloat(selectedOption.getAttribute('data-adjust-amount')) || 0;
				var advanceAmount = parseFloat(selectedOption.getAttribute('data-advance-amount')) || 0;
				var content = '<fieldset class="form-group">'+
									'<label>DUE ADJUSTMENT AMOUNT</label>'+
									'<input type="text" id="dueAdjustmentAmount" class="form-control format-payment-amount" value="'+formatIntNumber(adjustAmount)+'" disabled />'+
									'<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="'+adjustAmount+'" />'+
								'</fieldset>'+
								'<fieldset class="form-group">'+
									'<label>ADVANCE ADD AMOUNT</label>'+
									'<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" value="'+formatIntNumber(advanceAmount)+'" disabled />'+
									'<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="'+advanceAmount+'" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'ADVANCE_ADD'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var advanceAmount = parseFloat(selectedOption.getAttribute('data-advance-amount')) || 0;
				var content = '<fieldset class="form-group">'+
									'<label>ADVANCE ADD AMOUNT</label>'+
									'<input type="text" id="advanceAddAmount" class="form-control" value="'+formatIntNumber(advanceAmount)+'" disabled />'+
									'<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="'+advanceAmount+'" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'ADVANCE_ADD_AND_MONEY_RETURN'){
				var content = '<fieldset class="form-group">'+
									'<label>ADVANCE ADD AMOUNT</label>'+
									'<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" />'+
								'</fieldset>'+
								'<fieldset class="form-group">'+
									'<label>MONEY RETURN AMOUNT</label>'+
									'<input type="text" id="moneyReturnAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				
				var payment_pathod = '<fieldset class="form-group">'+
										'<label>PAYMENT METHOD <span class="mendatory">*</span></label>'+
										'<select name="payment_method" class="form-control" id="paymentType" required>'+
											'<option value="CASH">CASH</option>'+
											'<option value="CHEQUE">CHEQUE</option>'+
											'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
											'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
										'</select>'+
									'</fieldset>';
				$('#paymentMethod').html(payment_pathod);
				
				var payment_accounts_content = '<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else{
				$('#amountDistribute').html('');
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}
		});
		
		$(document).on('change', '#paymentType', function(){
			var payment_type = $(this).val();
			if(payment_type == 'CASH'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
			}else if(payment_type == 'CHEQUE'){
				$('#accountBalance').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
				var payment_option_cheque = '<fieldset class="form-group">'+
												'<label>CHEQUE NUMBER <span class="mendatory">*</span></label>'+
												'<input type="text" name="cheque_number" class="form-control" placeholder="Enter cheque number" required />'+
											'</fieldset>'+
											'<fieldset class="form-group">'+
												'<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>'+
												'<input type="text" name="deposit_branch" class="form-control" placeholder="Enter deposit branch" required />'+
											'</fieldset>'+
											'<fieldset class="form-group">'+
												'<label style="width:100%">UPLOAD DEPOSIT SLIP</label>'+
												'<input type="file" id="onchangeFile" name="deposit_slip" />'+
											'</fieldset>';
				$('#paymentOptionCheque').html(payment_option_cheque);
				
			}else if(payment_type == 'BANK_FUND_TRANSFER'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionMobileBanking').html('');
				
				var payment_option_bank_fund_transfer_content = '<fieldset class="form-group">'+
																	'<label>RECEIPT NUMBER <span class="mendatory">*</span></label>'+
																	'<input type="text" name="receipt_number" class="form-control" placeholder="Enter receipt number" required />'+
																'</fieldset>'+
																'<fieldset class="form-group">'+
																	'<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>'+
																	'<input type="file" id="onchangeFile" name="transfer_receipt" />'+
																'</fieldset>';
				$('#paymentOptionBankFundTransfer').html(payment_option_bank_fund_transfer_content);
			}else if(payment_type == 'MOBILE_BANKING'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}
			
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/payments/accounts_by_type",
				data : {type:payment_type},
				dataType : "json",
				cache: false,
				success : function (data) {
					if(data.status == "ok")
					{
						$("#onChangeAccount").html(data.content);
						return false;
					}
					return false;
				}
			});
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onChangeAccount', function(){
			var account_id = $(this).val();
			if(account_id !== ''){
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/payments/get_account_balance",
					data : {id:account_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$("#accountBalance").html(data.content);
							if(data.available_balance < 1)
							{
								$('#payAmount').prop('disabled', true);
							}else{
								$('#payAmount').prop('disabled', false);
							}
							return false;
						}else
						{
							$("#accountBalance").html('');
							return false;
						}
						return false;
					}
				});
			}else{
				$("#accountBalance").html('');
				return false;
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('keyup', '#dueAdjustmentAmount', function(){
			var receivableAmountInput = document.getElementById('receivableAmount');
			var moneyReturnAmount = document.getElementById('moneyReturnAmount');
			var moneyReturnAmountHidden = document.getElementById('moneyReturnAmountHidden');
			var dueAdjustmentAmountHidden = document.getElementById('dueAdjustmentAmountHidden');
			var receivableAmount = parseFloat($(receivableAmountInput).val()) || 0;
			var dueAdjustmentAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			if(dueAdjustmentAmount > receivableAmount)
			{
				alert("Sorry receivable amount is : "+ formatIntNumber(receivableAmount));
				$(this).val('');
			}else{
				var setMoneyReturnAmount = receivableAmount - dueAdjustmentAmount;
				$(moneyReturnAmount).val(formatIntNumber(setMoneyReturnAmount));
				$(moneyReturnAmountHidden).val(setMoneyReturnAmount);
				$(dueAdjustmentAmountHidden).val(dueAdjustmentAmount);
			}
		});
		
		$(document).on('keyup', '#moneyReturnAmount', function(){
			var receivableAmountInput = document.getElementById('receivableAmount');
			
			var dueAdjustmentAmount = document.getElementById('dueAdjustmentAmount');
			var dueAdjustmentAmountHidden = document.getElementById('dueAdjustmentAmountHidden');
			
			var advanceAddAmount = document.getElementById('advanceAddAmount');
			var advanceAddAmountHidden = document.getElementById('advanceAddAmountHidden');
			
			var moneyReturnAmountHidden = document.getElementById('moneyReturnAmountHidden');
			
			var receivableAmount = parseFloat($(receivableAmountInput).val()) || 0;
			var moneyReturnAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			if(moneyReturnAmount > receivableAmount)
			{
				alert("Sorry receivable amount is : "+ formatIntNumber(receivableAmount));
				$(this).val('');
			}else{
				var setDueAdjustmentAmount = receivableAmount - moneyReturnAmount;
				
				$(dueAdjustmentAmount).val(formatIntNumber(setDueAdjustmentAmount));
				$(dueAdjustmentAmountHidden).val(setDueAdjustmentAmount);
				
				$(advanceAddAmount).val(formatIntNumber(setDueAdjustmentAmount));
				$(advanceAddAmountHidden).val(setDueAdjustmentAmount);
				$(moneyReturnAmountHidden).val(moneyReturnAmount);
			}
		});
		
		$(document).on('keyup', '#advanceAddAmount', function(){
			var receivableAmountInput = document.getElementById('receivableAmount');
			var moneyReturnAmount = document.getElementById('moneyReturnAmount');
			var moneyReturnAmountHidden = document.getElementById('moneyReturnAmountHidden');
			var advanceAddAmountHidden = document.getElementById('advanceAddAmountHidden');
			var receivableAmount = parseFloat($(receivableAmountInput).val()) || 0;
			var advanceAddAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			if(advanceAddAmount > receivableAmount)
			{
				alert("Sorry receivable amount is : "+ formatIntNumber(receivableAmount));
				$(this).val('');
			}else{
				var setMoneyReturnAmount = receivableAmount - advanceAddAmount;
				$(moneyReturnAmount).val(formatIntNumber(setMoneyReturnAmount));
				$(moneyReturnAmountHidden).val(setMoneyReturnAmount);
				$(advanceAddAmountHidden).val(advanceAddAmount);
			}
		});
	});
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>