<?php require_once APPPATH.'modules/common/header.php'; ?>
<?php 
	$ac_types_array = array(
							'CASH'               => 'PETTY_CASH',
							'CHEQUE'             => 'BANK',
							'BANK_FUND_TRANSFER' => 'BANK',
							'MOBILE_BANKING'     => 'MOBILE_BANKING',
						);
	$accounts = (isset($refund_info['prefund_payment_method']))? get_accounts_by_type($ac_types_array[$refund_info['prefund_payment_method']]) : get_accounts_by_type('PETTY_CASH');
	$account_list = '<option value="">Select Account</option>';  
	foreach($accounts as $account):
		$selected = ($refund_info['prefund_account_id'] && $refund_info['prefund_account_id'] == $account['account_id'])? 'selected' : null;
		if($account['account_type'] == 'PETTY_CASH')
		{
			$account_list .= '<option value="'.$account['account_id'].'" '.$selected.'>'.$account['account_title'].'</option>';
		}else{
			$account_list .= '<option value="'.$account['account_id'].'" '.$selected.'>'.$account['account_title'].' - A/C :'.$account['account_number'].'</option>';
		}
	endforeach;
?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#">purchase refund</a></li>
			<li class="breadcrumb-item active">edit</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>
<!-- Basic Inputs start -->
<section id="basic-input" class="set-position-relative">
  <div id="createProgressLoader"><span>.....PLEASE WAIT.....</span></div>
  <?php  
		$attr = array('id' => 'createForm', 'class' => '');
		echo form_open('', $attr);
  ?>
	<div id="alert"></div>
	<div class="row">
		<div class="col-md-12">
			<div class="row" style="padding: 0 3px;">
				<div class="col-md-15"></div>
				<div class="col-md-15"></div>
				<div class="col-md-15">
					<label style="padding-top: 9px;display: block;">REFUND DATE <span class="mendatory">*</span></label>
					<fieldset class="form-group position-relative has-icon-left">
						<input type="text" name="refund_date" value="<?php echo date("d F, Y", strtotime($refund_info['refund_date'])); ?>" class="form-control pickadate-months-year" placeholder="Select Date">
						<div class="form-control-position dpicker-icon-position">
							<i class='bx bx-calendar' style="top:-25px !important"></i>
						</div>
					</fieldset>
				</div>
				<div class="col-md-15">
					<label style="padding-top: 9px;display: block;">BRANCH <span class="mendatory">*</span></label>
					<fieldset class="form-group">
						<select name="branch" class="custom-select" id="onChangeBranch">
							<option value="">Select Branch</option>
							<?php 
								$branchs = $this->Purchaserefund_model->get_all_branchs();
								foreach($branchs as $branch):
							?>
							<option value="<?php echo $branch['branch_id']; ?>" <?php echo ($refund_info['refund_branch_id'] == $branch['branch_id'])? 'selected' : null; ?>><?php echo $branch['branch_name']; ?></option>
							<?php endforeach; ?>
						</select>
					</fieldset>
				</div>
				<div class="col-md-15">
					<label style="padding-top: 9px;display: block;">WAREHOUSE <span class="mendatory">*</span></label>
					<fieldset class="form-group">
						<select name="warehouse" class="custom-select" id="warehouseContent">
							<option value="">Select Warehouse</option>
							<?php 
								$warehouses = $this->Purchaserefund_model->get_all_warehouses_by_branch($refund_info['refund_branch_id']);
								foreach($warehouses as $warehouse):
							?>
							<option value="<?php echo $warehouse['warehouse_id']; ?>" <?php echo ($refund_info['refund_warehouse_id'] == $warehouse['warehouse_id'])? 'selected' : null; ?>><?php echo $warehouse['warehouse_name']; ?></option>
							<?php endforeach; ?>
						</select>
					</fieldset>
				</div>
			</div>
			
			<div class="card set-position-relative">
				<div class="card-header" style="margin-bottom: 0;">
					<h4 class="card-title">Purchase Informations</h4>
					<input type="hidden" name="refund_id" value="<?php echo $refund_info['refund_id']; ?>" />
					<input type="hidden" name="refund_fid" value="<?php echo $refund_info['refund_formatted_id']; ?>" />
				</div>
				<div class="card-content" style="padding: 15px 0 30px;">
					<div class="card-body" style="padding:0">
						<div class="row">
							<div class="col-md-12">
								<!-- table striped -->
								<div class="table-responsive">
								  <table class="table mb-0">
									<thead>
									  <tr>
										<th class="text-center">Invoice Number</th>
										<th class="text-center">Order Number</th>
										<th class="text-center">Order date</th>
										<th class="text-center">Supplier</th>
										<th class="text-center">Purchased By</th>
										<th class="text-center">Sub Total</th>
										<th class="text-center">Net Total</th>
									  </tr>
									</thead>
									<tbody>
										<tr>
											<td class="text-center"><?php echo $refund_info['invoice_number']; ?></td>
											<td class="text-center"><?php echo $refund_info['order_number']; ?></td>
											<td class="text-center"><?php echo date("d F, Y", strtotime($refund_info['order_date'])); ?></td>
											<td class="text-center"><?php echo $refund_info['supplier_name']; ?></td>
											<td class="text-center"><?php echo $refund_info['admin_full_name']; ?></td>
											<td class="text-center"><?php echo number_format($refund_info['osummery_subtotal'], 2, '.', ','); ?></td>
											<td class="text-center"><?php echo number_format($refund_info['osummery_net_total'], 2, '.', ','); ?></td>
											
											<input type="hidden" name="supplier_id" value="<?php echo $refund_info['order_supplier_id']; ?>" />
											<input type="hidden" name="invoice_id" value="<?php echo $refund_info['invoice_id']; ?>" />
											<input type="hidden" name="order_id" value="<?php echo $refund_info['order_id']; ?>" />
										</tr>
									</tbody>
								  </table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<h4 class="card-title" style="margin-bottom: 5px;">PURCHASE ITEMS</h4>
			<div class="card set-position-relative">
				<div class="card-content">
					<div class="card-body" style="padding:0">
						<div class="row">
							<div class="col-md-12">
								<!-- table striped -->
								<div class="table-responsive">
								  <table class="table table-striped mb-0">
									<thead>
										<tr>
											<th style="width:3%;">S.No</th>
											<th style="width:20%;">PRODUCT</th>
											<th class="text-center">PHOTO</th>
											<th class="text-center" style="width: 9%;">REFUNDABLE QTY</th>
											<th class="text-center">UNIT</th>
											<th class="text-center" style="width: 10%;">PURCHASE PRICE</th>
											<th class="text-center" style="width: 5%;">SUBTOTAL</th>
											<th class="text-center" style="width:10%">REFUND QTY</th>
											<th class="text-center" style="width:10%">REFUND CHARGE</th>
											<th class="text-center" style="width: 10%;">REFUND AMOUNT</th>
											<th class="text-center" style="width: 10%;">REFUND SUBTOTAL</th>
											<th class="text-center" style="width: 1%;">REMOVE</th>
										</tr>
									</thead>
									<tbody id="productContents">
										<?php 
											$content = '';
											$products = $this->Purchaserefund_model->get_refund_items($refund_info['refund_id']);
											if(is_array($products) && count($products) !== 0):
												$x = 1;
												foreach($products as $item)
												{
													$product_id = $item['refitem_product_id'];
													$product_info = $this->Purchaserefund_model->get_product_info($item['refitem_product_id']);
													if($product_info['product_type'] == 'GENERAL'){
														$photo_url = get_product_photo_url($product_info['product_id']);
													}else{
														$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
													}
													$purchase_has_variations = $product_info['product_has_variations'];
													if($purchase_has_variations == 'YES'){
														$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_option_id($item['refitem_order_id'], $item['refitem_product_id'], $item['refitem_variation_option_id']);
													}else{
														$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_id($item['refitem_order_id'], $item['refitem_product_id']);
													}
													$product = array_merge($item, $purchase_item);
													if($x < 10){
														$sl = '0'.$x;
													}else{
														$sl = $x;
													}
													if($purchase_has_variations == 'YES'){
														$provariation_id = $product['oitem_provariation_id'];
														$variation_option_id = $product['oitem_variation_option_id'];
														$variant_name   = $this->Purchaserefund_model->get_variant_name($provariation_id);
														$option_name   = $this->Purchaserefund_model->get_option_name($variation_option_id);
														$variation_content = '<br style="margin-bottom:5px;" /> <strong>Description :</strong> '.$variant_name.' : '.$option_name
																			 .'<input type="hidden" name="item_provariation_id_'.$x.'" class="update-provariation-id-'.$x.'" value="'.$provariation_id.'" />
																				<input type="hidden" name="item_variation_option_id_'.$x.'" class="update-variation-option-id-'.$x.'" value="'.$variation_option_id.'" />';
														$variation_id = $this->Purchaserefund_model->get_variation_id($provariation_id, $item['refitem_product_id']);
														$quantity    = product_purchase_refundable_qty_by_variation($item['refitem_order_id'], $item['refitem_product_id'], $variation_id, $variation_option_id) + intval($product['refitem_refund_qty']);
													}else{
														$variation_content = '';
														$quantity    = product_purchase_refundable_qty($item['refitem_order_id'], $item['refitem_product_id']) + intval($product['refitem_refund_qty']);
													}
													$unit_id     = $product['oitem_unit_id'];
													$unit_name   = $this->Purchaserefund_model->get_unit_name($unit_id);
													$purchase_price = $product['oitem_purchase_per_qty'];
													$sale_price     = $product['oitem_sale_per_qty'];
													$profit_per_qty = $product['oitem_profit_per_qty'];
													$subtotal_amount = $product['oitem_subtotal'];
													if($product_info['product_type'] == 'GENERAL'){
														$product_title = $product_info['product_name']; 
													}else{
														$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
														$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
													}
													$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
																	<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
																	<td>
																		'.$product_title.'
																		<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
																		'.$variation_content.'
																		<input type="hidden" name="item_product_id_'.$x.'" value="'.$product_id.'" />
																	</td>
																	<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
																	<td class="text-center">
																		'.$quantity.'
																		<input type="hidden" name="item_quantity_'.$x.'" class="qty-'.$x.'" value="'.$quantity.'" />
																	</td>
																	<td class="text-center">
																		'.$unit_name.'
																		<input type="hidden" name="item_unit_id_'.$x.'" class="unit-id-'.$x.'" value="'.$unit_id.'" />
																	</td>
																	<td class="text-center">
																		'.number_format($purchase_price, 0, '.', ',').'
																		<input type="hidden" name="item_purchase_per_qty_'.$x.'" class="purchase-price-'.$x.'" value="'.$purchase_price.'" />
																	</td>
																	<td class="text-center">
																		'.number_format($subtotal_amount, 0, '.', ',').'
																		<input type="hidden" class="subtotal-amounts-'.$x.'" name="item_subtotal_'.$x.'" value="'.$subtotal_amount.'" />
																	</td>
																	<td class="text-center">
																		<input type="text" class="form-control text-center onchange-item-refund-qty item-refund-qty-'.$x.'" data-row="'.$x.'" name="item_refund_qty_'.$x.'" value="'.number_format($product['refitem_refund_qty'], 0, '.', ',').'" required /> 
																	</td>
																	<td class="text-center">
																		<input type="text" class="form-control text-center onchange-item-refund-charge item-refund-charge-total item-refund-charge-'.$x.'" data-row="'.$x.'" name="item_refund_charge_'.$x.'" value="'.number_format($product['refitem_refund_charge'], 0, '.', ',').'" required /> 
																	</td>
																	<td class="text-center">
																		<input type="text" class="form-control text-center show-refund-amounts-'.$x.'" value="'.number_format($product['refitem_refund_amount'], 0, '.', ',').'" disabled />
																		<input type="hidden" class="refund-amounts refund-amounts-'.$x.'" name="item_refund_amount_'.$x.'" value="'.$product['refitem_refund_amount'].'" />
																	</td>
																	<td class="text-center">
																		<input type="text" class="form-control text-center show-refund-subtotal-amounts-'.$x.'" value="'.number_format($product['refitem_refund_subtotal'], 0, '.', ',').'" disabled />
																		<input type="hidden" class="refund-subtotal-amounts refund-subtotal-amounts-'.$x.'" name="item_refund_subtotal_'.$x.'" value="'.$product['refitem_refund_subtotal'].'" />
																	</td>
																	<td class="text-center">
																		<span class="remove-item-icon remove-item-from-particulars"><i class="bx bx-x"></i></span>
																	</td>
																	<input type="hidden" name="item_has_variations_'.$x.'" value="'.$purchase_has_variations.'" />
																	<input type="hidden" name="particular_items[]" value="'.$x.'" />
																</tr>';
													$x++;
												}
												echo $content;
											else: 
										?>
										<tr>
											<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="12">NO ITEMS FOUND</td>
										</tr>
										<?php endif; ?>
									</tbody>
								  </table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-5">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title">Summery</h4>
				</div>
				<div class="card-content">
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<fieldset class="form-group">
									<label>Terms</label>
									<textarea name="terms" class="form-control" cols="30" rows="2"><?php echo $refund_info['refund_terms']; ?></textarea>
								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="form-group">
									<label>Remarks</label>
									<textarea name="remarks" class="form-control" cols="30" rows="2"><?php echo $refund_info['refund_remarks']; ?></textarea>
								</fieldset>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title">Payment <br />
						<span style="text-transform: capitalize;margin-top: 5px;display: block;font-size: 12px;">Supplier Balanace : 
						(<span id="spShowBalance"><?php 
							$balance_info = get_the_supplier_balance($refund_info['order_supplier_id']);
							if($balance_info['balance_type'] == 'DUE'){
								echo '<strong style="color:#E00">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
							}elseif ($balance_info['balance_type'] == 'ADVANCE') {
								echo '<strong style="color:#0A0">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
							}elseif ($balance_info['balance_type'] == 'BALANCE') {
								echo '<strong style="color:#333">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
							}else{
								echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 2, '.', ',');
							}
						?> TK </span>)
						<?php echo '<input type="hidden" id="balanceType" value="'.$balance_info['balance_type'].'" /><input type="hidden" id="balanceAmount" value="'.$balance_info['balance_amount'].'" />'; ?>
						</span>
						<input type="hidden" name="prefund_id" value="<?php echo $refund_info['prefund_id']; ?>" />
					</h4>
				</div>
				<div class="card-content">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<fieldset class="form-group">
									<label>RECEIVABLE AMOUNT</label>
									<span id="displayReceivableAmount"><input type="text" class="form-control" value="<?php echo '&#2547; '.number_format(floatval($refund_info['prefund_amount_total']), 0, '.', ','); ?>" disabled /></span>
									<input type="hidden" name="receivable_amount" id="receivableAmount" value="<?php echo $refund_info['prefund_amount_total']; ?>" />
								</fieldset>
							</div>
							<div class="col-md-12">
								<fieldset class="form-group">
									<label>RECEIVABLE AMOUNT SHOULD BE</label>
									<select name="payment_refund_type" class="form-control" id="refundType" required readonly >
										<option value="">Select Type</option>
										<?php if($balance_info['balance_type'] == 'DUE'): ?>
											<?php if($refund_info['refund_amount_total'] < $balance_info['balance_amount']): ?>
											<option value="MONEY_RETURN" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'MONEY_RETURN')? 'selected' : null; ?>>Money Return</option>
											<option value="DUE_ADJUSTMENT" data-adjust-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'DUE_ADJUSTMENT')? 'selected' : null; ?>>Due Adjustment</option>
											<option value="DUE_ADJUSTMENT_AND_MONEY_RETURN" data-adjust-amount="<?php echo $refund_info['refund_amount_total']; ?>" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN')? 'selected' : null; ?>>Due Adjustment & Money Return</option>
											
											<?php elseif($refund_info['refund_amount_total'] > $balance_info['balance_amount']): ?>
											<option value="MONEY_RETURN" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'MONEY_RETURN')? 'selected' : null; ?>>Money Return</option>
											<option value="DUE_ADJUSTMENT_AND_MONEY_RETURN" data-adjust-amount="<?php echo $balance_info['balance_amount']; ?>" data-return-amount="DUE_ADJUSTMENT_AND_MONEY_RETURN" <?php echo ($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN')? 'selected' : null; ?>>Due Adjustment & Money Return</option>
											<option value="DUE_ADJUSTMENT_AND_ADVANCE_ADD" data-adjust-amount="<?php echo $balance_info['balance_amount']; ?>" data-advance-amount="DUE_ADJUSTMENT_AND_MONEY_RETURN" <?php echo ($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_ADVANCE_ADD')? 'selected' : null; ?>>Due Adjustment & Advance Add</option>
											
											<?php elseif($refund_info['refund_amount_total'] == $balance_info['balance_amount']): ?>
											<option value="MONEY_RETURN" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'MONEY_RETURN')? 'selected' : null; ?>>Money Return</option>
											<option value="ADVANCE_ADD" data-advance-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'ADVANCE_ADD')? 'selected' : null; ?>>Advance Add</option>
											<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="<?php echo $refund_info['refund_amount_total']; ?>" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN')? 'selected' : null; ?>>Advance Add & Money Return</option>
											<?php endif; ?>
											
										<?php elseif($balance_info['balance_type'] == 'ADVANCE'): ?>
										<option value="MONEY_RETURN" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'MONEY_RETURN')? 'selected' : null; ?>>Money Return</option>
										<option value="ADVANCE_ADD" data-advance-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'ADVANCE_ADD')? 'selected' : null; ?>>Advance Add</option>
										<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="<?php echo $refund_info['refund_amount_total']; ?>" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN')? 'selected' : null; ?>>Advance Add & Money Return</option>
										
										<?php elseif($balance_info['balance_type'] == 'BALANCE'): ?>
										<option value="MONEY_RETURN" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'MONEY_RETURN')? 'selected' : null; ?>>Money Return</option>
										<option value="ADVANCE_ADD" data-advance-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'ADVANCE_ADD')? 'selected' : null; ?>>Advance Add</option>
										<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="<?php echo $refund_info['refund_amount_total']; ?>" data-return-amount="<?php echo $refund_info['refund_amount_total']; ?>" <?php echo ($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN')? 'selected' : null; ?>>Advance Add & Money Return</option>
										<?php endif; ?>
									</select>
								</fieldset>
							</div>
							<div class="col-md-12">
								<div id="amountDistribute">
									<?php if($refund_info['prefund_type'] == 'MONEY_RETURN'): ?>
										<fieldset class="form-group">
											<label>MONEY RETURN AMOUNT</label>
											<input type="text" id="moneyReturnAmount" class="form-control" value="&#2547; <?php echo number_format(floatval($refund_info['prefund_moneyreturn_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" value="<?php echo $refund_info['prefund_moneyreturn_amount']; ?>" />
										</fieldset>
									<?php elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT'): ?>
										<fieldset class="form-group">
											<label>DUE ADJUSTMENT AMOUNT</label>
											<input type="text" id="dueAdjustmentAmount" class="form-control" value="&#2547; <?php echo number_format(floatval($refund_info['prefund_dueadjust_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="<?php echo $refund_info['prefund_dueadjust_amount']; ?>" />
										</fieldset>	
									<?php elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'): ?>
										<fieldset class="form-group">
											<label>DUE ADJUSTMENT AMOUNT</label>
											<input type="text" id="dueAdjustmentAmount" class="form-control" value="&#2547; <?php echo number_format(floatval($refund_info['prefund_dueadjust_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="<?php echo $refund_info['prefund_dueadjust_amount']; ?>" />
										</fieldset>
										<fieldset class="form-group">
											<label>MONEY RETURN AMOUNT</label>
											<input type="text" id="moneyReturnAmount" class="form-control" value="&#2547; <?php echo number_format(floatval($refund_info['prefund_moneyreturn_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" value="<?php echo $refund_info['prefund_moneyreturn_amount']; ?>" />
										</fieldset>
									<?php elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_ADVANCE_ADD'): ?>
										<fieldset class="form-group">
											<label>DUE ADJUSTMENT AMOUNT</label>
											<input type="text" id="dueAdjustmentAmount" class="form-control" value="&#2547; <?php echo number_format(floatval($refund_info['prefund_dueadjust_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="<?php echo $refund_info['prefund_dueadjust_amount']; ?>" />
										</fieldset>
										<fieldset class="form-group">
											<label>ADVANCE ADD AMOUNT</label>
											<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" value="<?php echo number_format(floatval($refund_info['prefund_advance_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="<?php echo $refund_info['prefund_advance_amount']; ?>" />
										</fieldset>	
									<?php elseif($refund_info['prefund_type'] == 'ADVANCE_ADD'): ?>
										<fieldset class="form-group">
											<label>ADVANCE ADD AMOUNT</label>
											<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" value="<?php echo number_format(floatval($refund_info['prefund_advance_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="<?php echo $refund_info['prefund_advance_amount']; ?>" />
										</fieldset>	
									<?php elseif($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN'): ?>
										<fieldset class="form-group">
											<label>ADVANCE ADD AMOUNT</label>
											<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" value="<?php echo number_format(floatval($refund_info['prefund_advance_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="<?php echo $refund_info['prefund_advance_amount']; ?>" />
										</fieldset>
										<fieldset class="form-group">
											<label>MONEY RETURN AMOUNT</label>
											<input type="text" id="moneyReturnAmount" class="form-control" value="&#2547; <?php echo number_format(floatval($refund_info['prefund_moneyreturn_amount']), 0, '.', ','); ?>" disabled />
											<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" value="<?php echo $refund_info['prefund_moneyreturn_amount']; ?>" />
										</fieldset>	
									<?php endif; ?>
								</div>
								<div id="paymentMethod">
									<?php if($refund_info['prefund_type'] == 'MONEY_RETURN'): ?>
										<fieldset class="form-group">
											<label>PAYMENT METHOD <span class="mendatory">*</span></label>
											<select name="payment_method" class="form-control" id="paymentType" required>
												<option value="CASH" <?php echo ($refund_info['prefund_payment_method'] == 'CASH')? 'selected' : null; ?>>CASH</option>
												<option value="CHEQUE" <?php echo ($refund_info['prefund_payment_method'] == 'CHEQUE')? 'selected' : null; ?>>CHEQUE</option>
												<option value="BANK_FUND_TRANSFER" <?php echo ($refund_info['prefund_payment_method'] == 'BANK_FUND_TRANSFER')? 'selected' : null; ?>>BANK FUND TRANSFER</option>
												<option value="MOBILE_BANKING" <?php echo ($refund_info['prefund_payment_method'] == 'MOBILE_BANKING')? 'selected' : null; ?>>MOBILE BANKING</option>
											</select>
										</fieldset>		
									<?php elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'): ?>
										<fieldset class="form-group">
											<label>PAYMENT METHOD <span class="mendatory">*</span></label>
											<select name="payment_method" class="form-control" id="paymentType" required>
												<option value="CASH" <?php echo ($refund_info['prefund_payment_method'] == 'CASH')? 'selected' : null; ?>>CASH</option>
												<option value="CHEQUE" <?php echo ($refund_info['prefund_payment_method'] == 'CHEQUE')? 'selected' : null; ?>>CHEQUE</option>
												<option value="BANK_FUND_TRANSFER" <?php echo ($refund_info['prefund_payment_method'] == 'BANK_FUND_TRANSFER')? 'selected' : null; ?>>BANK FUND TRANSFER</option>
												<option value="MOBILE_BANKING" <?php echo ($refund_info['prefund_payment_method'] == 'MOBILE_BANKING')? 'selected' : null; ?>>MOBILE BANKING</option>
											</select>
										</fieldset>			
									<?php elseif($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN'): ?>
										<fieldset class="form-group">
											<label>PAYMENT METHOD <span class="mendatory">*</span></label>
											<select name="payment_method" class="form-control" id="paymentType" required>
												<option value="CASH" <?php echo ($refund_info['prefund_payment_method'] == 'CASH')? 'selected' : null; ?>>CASH</option>
												<option value="CHEQUE" <?php echo ($refund_info['prefund_payment_method'] == 'CHEQUE')? 'selected' : null; ?>>CHEQUE</option>
												<option value="BANK_FUND_TRANSFER" <?php echo ($refund_info['prefund_payment_method'] == 'BANK_FUND_TRANSFER')? 'selected' : null; ?>>BANK FUND TRANSFER</option>
												<option value="MOBILE_BANKING" <?php echo ($refund_info['prefund_payment_method'] == 'MOBILE_BANKING')? 'selected' : null; ?>>MOBILE BANKING</option>
											</select>
										</fieldset>	
									<?php endif; ?>
								</div>
								<div id="paymentAccounts" class="set-position-relative">
									<?php 
										if($refund_info['prefund_type'] == 'MONEY_RETURN'): 
										$account_balance = get_account_balance($refund_info['prefund_account_id']);
										$b_content = '<span style="margin-left:60px;font-size: 13px;background: #F0F0F0;padding: 3px 10px;border-radius: 4px;text-align: center;display: block;line-height: 22px;"><strong style="color:#0A0;display: block;">Available Balance </strong> <span>'.number_format(floatval($account_balance), 2, '.', ',').'</span> <strong> (BDT)</strong></span>';
									?>
										<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"><?php echo $b_content; ?></div>
										<fieldset class="form-group">
											<label>ACCOUNT <span class="mendatory">*</span></label>
											<select name="account_id" id="onChangeAccount" class="form-control" required>
												<?php echo $account_list; ?>
											</select>
										</fieldset>
									<?php 
										elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'): 
										$account_balance = get_account_balance($refund_info['prefund_account_id']);
										$b_content = '<span style="margin-left:60px;font-size: 13px;background: #F0F0F0;padding: 3px 10px;border-radius: 4px;text-align: center;display: block;line-height: 22px;"><strong style="color:#0A0;display: block;">Available Balance </strong> <span>'.number_format(floatval($account_balance), 2, '.', ',').'</span> <strong> (BDT)</strong></span>';
									?>
										<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"><?php echo $b_content; ?></div>
										<fieldset class="form-group">
											<label>ACCOUNT <span class="mendatory">*</span></label>
											<select name="account_id" id="onChangeAccount" class="form-control" required>
												<?php echo $account_list; ?>
											</select>
										</fieldset>			
									<?php 
										elseif($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN'): 
										$account_balance = get_account_balance($refund_info['prefund_account_id']);
										$b_content = '<span style="margin-left:60px;font-size: 13px;background: #F0F0F0;padding: 3px 10px;border-radius: 4px;text-align: center;display: block;line-height: 22px;"><strong style="color:#0A0;display: block;">Available Balance </strong> <span>'.number_format(floatval($account_balance), 2, '.', ',').'</span> <strong> (BDT)</strong></span>';
									?>
										<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"><?php echo $b_content; ?></div>
										<fieldset class="form-group">
											<label>ACCOUNT <span class="mendatory">*</span></label>
											<select name="account_id" id="onChangeAccount" class="form-control" required>
												<?php echo $account_list; ?>
											</select>
										</fieldset>	
									<?php endif; ?>
								</div>
								<div id="paymentOptionCheque">
									<?php if($refund_info['prefund_type'] == 'MONEY_RETURN'): ?>
										<?php 
											if($refund_info['prefund_payment_method'] == 'CHEQUE'): 
											$attach_url = get_cheque_scan_url($refund_info['cheque_id']);
										?>
											<fieldset class="form-group">
												<label>CHEQUE NUMBER <span class="mendatory">*</span></label>
												<input type="text" name="cheque_number" value="<?php echo $refund_info['cheque_number']; ?>" class="form-control" placeholder="Enter cheque number" required />
											</fieldset>
											<fieldset class="form-group">
												<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>
												<input type="text" name="deposit_branch" value="<?php echo $refund_info['cheque_deposit_branch']; ?>" class="form-control" placeholder="Enter deposit branch" required />
											</fieldset>
											<fieldset class="form-group">
												<label style="width:100%">UPLOAD DEPOSIT SLIP</label>
												<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded deposit slip</a>
												<input type="file" id="onchangeFile" name="deposit_slip" />
											</fieldset>
										<?php endif; ?>
									<?php elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'): ?>
										<?php 
											if($refund_info['prefund_payment_method'] == 'CHEQUE'): 
											$attach_url = get_cheque_scan_url($refund_info['cheque_id']);
										?>
											<fieldset class="form-group">
												<label>CHEQUE NUMBER <span class="mendatory">*</span></label>
												<input type="text" name="cheque_number" value="<?php echo $refund_info['cheque_number']; ?>" class="form-control" placeholder="Enter cheque number" required />
											</fieldset>
											<fieldset class="form-group">
												<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>
												<input type="text" name="deposit_branch" value="<?php echo $refund_info['cheque_deposit_branch']; ?>" class="form-control" placeholder="Enter deposit branch" required />
											</fieldset>
											<fieldset class="form-group">
												<label style="width:100%">UPLOAD DEPOSIT SLIP</label>
												<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded deposit slip</a>
												<input type="file" id="onchangeFile" name="deposit_slip" />
											</fieldset>
										<?php endif; ?>	
									<?php elseif($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN'): ?>
										<?php 
											if($refund_info['prefund_payment_method'] == 'CHEQUE'): 
											$attach_url = get_cheque_scan_url($refund_info['cheque_id']);
										?>
											<fieldset class="form-group">
												<label>CHEQUE NUMBER <span class="mendatory">*</span></label>
												<input type="text" name="cheque_number" value="<?php echo $refund_info['cheque_number']; ?>" class="form-control" placeholder="Enter cheque number" required />
											</fieldset>
											<fieldset class="form-group">
												<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>
												<input type="text" name="deposit_branch" value="<?php echo $refund_info['cheque_deposit_branch']; ?>" class="form-control" placeholder="Enter deposit branch" required />
											</fieldset>
											<fieldset class="form-group">
												<label style="width:100%">UPLOAD DEPOSIT SLIP</label>
												<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded deposit slip</a>
												<input type="file" id="onchangeFile" name="deposit_slip" />
											</fieldset>
										<?php endif; ?>	
									<?php endif; ?>
								</div>
								<div id="paymentOptionBankFundTransfer">
									<?php if($refund_info['prefund_type'] == 'MONEY_RETURN'): ?>
										<?php 
											if($refund_info['prefund_payment_method'] == 'BANK_FUND_TRANSFER'):
											$attach_url = get_receipt_scan_url($refund_info['fundtransfer_id']);
										?>
											<fieldset class="form-group">
												<label>RECEIPT NUMBER <span class="mendatory">*</span></label>
												<input type="text" name="receipt_number" value="<?php echo $refund_info['fundtransfer_receipt_number']; ?>" class="form-control" placeholder="Enter receipt number" required />
											</fieldset>
											<fieldset class="form-group">
												<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>
												<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded transfer receipt</a>
												<input type="file" id="onchangeFile" name="transfer_receipt" />
											</fieldset>
										<?php endif; ?>
									<?php elseif($refund_info['prefund_type'] == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'): ?>
										<?php 
											if($refund_info['prefund_payment_method'] == 'BANK_FUND_TRANSFER'): 
											$attach_url = get_receipt_scan_url($refund_info['fundtransfer_id']);
										?>
											<fieldset class="form-group">
												<label>RECEIPT NUMBER <span class="mendatory">*</span></label>
												<input type="text" name="receipt_number" value="<?php echo $refund_info['fundtransfer_receipt_number']; ?>" class="form-control" placeholder="Enter receipt number" required />
											</fieldset>
											<fieldset class="form-group">
												<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>
												<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded transfer receipt</a>
												<input type="file" id="onchangeFile" name="transfer_receipt" />
											</fieldset>
										<?php endif; ?>	
									<?php elseif($refund_info['prefund_type'] == 'ADVANCE_ADD_AND_MONEY_RETURN'): ?>
										<?php 
											if($refund_info['prefund_payment_method'] == 'BANK_FUND_TRANSFER'): 
											$attach_url = get_receipt_scan_url($refund_info['fundtransfer_id']);
										?>
											<fieldset class="form-group">
												<label>RECEIPT NUMBER <span class="mendatory">*</span></label>
												<input type="text" name="receipt_number" value="<?php echo $refund_info['fundtransfer_receipt_number']; ?>" class="form-control" placeholder="Enter receipt number" required />
											</fieldset>
											<fieldset class="form-group">
												<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>
												<a href="<?php echo $attach_url; ?>" style="display: block;padding: 5px 0 10px;" target="__blank">View uploaded transfer receipt</a>
												<input type="file" id="onchangeFile" name="transfer_receipt" />
											</fieldset>
										<?php endif; ?>	
									<?php endif; ?>
								</div>
							</div>
							<div class="col-md-12">
								
							</div>
							<div class="col-md-12">
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4">
		  <div class="card">
			<div class="card-content">
			  <div class="card-body" style="padding-bottom: 2px;">
				  <div class="form-body">
					<div class="row">
					  <div class="col-12">
						<div class="invoice-subtotal">
						  <div class="invoice-calc d-flex justify-content-between">
							<span class="invoice-title">Refund Subtotal</span>
							<span class="invoice-value" style="font-size: 13px;"><input type="text" name="refund_subtotal" id="refundSubtotal" class="form-control text-right" value="<?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?>" readonly /></span>
						  </div>
						  <div class="invoice-calc d-flex justify-content-between">
							<span class="invoice-title">Total Refund Charges</span>
							<span class="invoice-value" style="font-size: 13px;"><input type="text" name="refund_charge_total" id="refundChargeTotal" class="form-control text-right" value="<?php echo number_format($refund_info['refund_charge_total'], 2, '.', ','); ?>" readonly /></span>
						  </div>
						  <div class="invoice-calc d-flex justify-content-between">
							<span class="invoice-title">Total Amount to be Refunded</span>
							<span class="invoice-value" style="font-size: 13px;"><input type="text" name="refund_amount_total" id="refundAmountTotal" class="form-control text-right" value="<?php echo number_format($refund_info['refund_amount_total'], 2, '.', ','); ?>" readonly /></span>
						  </div>
						  <hr>
						  <div class="invoice-calc d-flex justify-content-between" style="color:#a52323">
							<span class="invoice-title">Refund Net Total</span>
							<span class="invoice-value" style="font-size: 13px;padding: 0 15px;font-size: 14px;font-weight: bold;"><strong>BDT</strong> <span id="showRefundNetTotal"><?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></span></span>
							<input type="hidden" name="refund_net_total" id="refundNetTotal" value="<?php echo $refund_info['refund_net_total']; ?>" />
						  </div>
						  <div class="invoice-calc d-flex justify-content-between" style="color:#2a7f52">
							<span class="invoice-title">Refund Net Profit</span>
							<span class="invoice-value" style="font-size: 13px;padding: 0 15px;font-size: 14px;font-weight: bold;"><strong>BDT</strong> <span id="showRefundNetProfit"><?php echo number_format($refund_info['refund_net_profit'], 2, '.', ','); ?></span></span>
							<input type="hidden" name="refund_net_profit" id="refundNetProfit" value="<?php echo $refund_info['refund_net_profit']; ?>" />
						  </div>
						</div>
					  </div>
					  <div class="col-12 d-flex justify-content-end justify-content-custom">
						<button type="submit" class="btn btn-custom-form btn-primary mr-1 mb-1"><i class="bx bxs-send"></i> Update Refund Voucher</button>
					  </div>
					</div>
				  </div>
			  </div>
			</div>
		  </div>
		</div>
	</div>
  
  <?php echo form_close(); ?>
</section>
<!-- Basic Inputs end -->

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#createForm").validate({
			rules:{
				refund_date:{
					required: true,
				},
				branch:{
					required: true,
				},
				warehouse:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#createProgressLoader').show();
				// your function if, validate is success
				var getFrmData = new FormData(document.getElementById('createForm'));
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/purchaserefund/update",
					data : getFrmData,
					dataType : "json",
					cache: false,
					contentType: false,
					processData: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$("#alert").html(data.alert);
							$('#createProgressLoader').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							showCalculation();
							window.setTimeout(function(){
								window.location.href = baseUrl + "purchase/purchaserefund/vouchar/"+data.formatted_id;
							}, 2000);
							return false;
						}else if(data.status == "error")
						{
							$('#createProgressLoader').hide();
							$("#alert").html(data.alert);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
		
		$(document).on('change', '#onChangeBranch', function(){
			var branch_id = $(this).val();
			if(branch_id !== '')
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "inventories/warehouse/get_warehouses",
					data : {branch_id:branch_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$('#warehouseContent').html(data.content);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	//Add product functions
	$(document).ready(function(){
		$(document).on('keyup', '.onchange-item-refund-qty', function(){
			var refundType = document.getElementById('refundType');
			var amountDistribute = document.getElementById('amountDistribute');
			var paymentMethod = document.getElementById('paymentMethod');
			var paymentAccounts = document.getElementById('paymentAccounts');
			var paymentOptionCheque = document.getElementById('paymentOptionCheque');
			var paymentOptionBankFundTransfer = document.getElementById('paymentOptionBankFundTransfer');
			$(refundType).html('<option value="">Select Type</option>');
			$(amountDistribute).html('');
			$(paymentMethod).html('');
			$(paymentAccounts).html('');
			$(paymentOptionCheque).html('');
			$(paymentOptionBankFundTransfer).html('');
			
			var rowNumber = $(this).attr('data-row');
			var qty = parseFloat(deFormatNumber($('.qty-'+rowNumber).val())) || 0;
			var refudnQty = parseFloat(deFormatNumber($(this).val())) || 0;
			if(refudnQty <= qty)
			{
				var purchasePrice = parseFloat(deFormatNumber($('.purchase-price-'+rowNumber).val())) || 0;
				var refundCharge  = parseFloat(deFormatNumber($('.item-refund-charge-'+rowNumber).val())) || 0;
				var subtotal = add_product_subtotal_amount(refudnQty, purchasePrice);
				var refundAmount = subtotal - refundCharge;
				
				//Show item refund amount
				$('.show-refund-amounts-'+rowNumber).val(formatNumber(refundAmount));
				$('.refund-amounts-'+rowNumber).val(refundAmount);
				
				//Show item refund subtotal
				$('.show-refund-subtotal-amounts-'+rowNumber).val(formatNumber(subtotal));
				$('.refund-subtotal-amounts-'+rowNumber).val(subtotal);
				
				showCalculation();
			}else{
				alert('Sorry! you can add max qty - '+qty);
				$(this).val('');
				return false;
			}
		});
		$(document).on('keyup', '.onchange-item-refund-charge', function(){
			var refundType = document.getElementById('refundType');
			var amountDistribute = document.getElementById('amountDistribute');
			var paymentMethod = document.getElementById('paymentMethod');
			var paymentAccounts = document.getElementById('paymentAccounts');
			var paymentOptionCheque = document.getElementById('paymentOptionCheque');
			var paymentOptionBankFundTransfer = document.getElementById('paymentOptionBankFundTransfer');
			$(refundType).html('<option value="">Select Type</option>');
			$(amountDistribute).html('');
			$(paymentMethod).html('');
			$(paymentAccounts).html('');
			$(paymentOptionCheque).html('');
			$(paymentOptionBankFundTransfer).html('');
			
			var rowNumber = $(this).attr('data-row');
			var refudnQty = parseFloat(deFormatNumber($('.item-refund-qty-'+rowNumber).val())) || 0;
			
			var purchasePrice = parseFloat(deFormatNumber($('.purchase-price-'+rowNumber).val())) || 0;
			var refundCharge  = parseFloat(deFormatNumber($(this).val())) || 0;
			var subtotal = add_product_subtotal_amount(refudnQty, purchasePrice);
			var refundAmount = subtotal - refundCharge;
			
			//Show item refund amount
			$('.show-refund-amounts-'+rowNumber).val(formatNumber(refundAmount));
			$('.refund-amounts-'+rowNumber).val(refundAmount);
			
			//Show item refund subtotal
			$('.show-refund-subtotal-amounts-'+rowNumber).val(formatNumber(subtotal));
			$('.refund-subtotal-amounts-'+rowNumber).val(subtotal);
			
			showCalculation();
		});
	});
	
	function add_product_subtotal_amount(qty, purchasePrice)
	{
		var subtotal = purchasePrice * qty;
		return subtotal;
	}
</script>
<script type="text/javascript">
/*********Calculation related functions started**************/
	function getRefundSubtotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat($(particularsItmPrice.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function getRefundChargeTotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat(deFormatNumber($(particularsItmPrice.eq(i)).val())) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function getRefundAmountTotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat($(particularsItmPrice.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function showCalculation()
	{
		var refundSubtotal    = getRefundSubtotal('.refund-subtotal-amounts');
		var refundChargetotal = getRefundChargeTotal('.item-refund-charge-total');
		var refundAmountTotal = getRefundAmountTotal('.refund-amounts');
		var refundNetTotal    = refundSubtotal;
		var refundNetProfit   = refundChargetotal;
		
		//Show amount in refund sub total
		$('#refundSubtotal').val(formatNumber(refundSubtotal));
		
		//Show amount in refund charge total
		$('#refundChargeTotal').val(formatNumber(refundChargetotal));
		
		//Show amount in refund amount total
		$('#refundAmountTotal').val(formatNumber(refundAmountTotal));
		$('#displayReceivableAmount').html('<input type="text" class="form-control" value="&#2547; '+formatNumber(refundAmountTotal)+'" disabled="" />');
		$('#receivableAmount').val(refundAmountTotal);
		if(refundAmountTotal == 0)
		{
			var refundType = document.getElementById('refundType');
			var amountDistribute = document.getElementById('amountDistribute');
			var paymentMethod = document.getElementById('paymentMethod');
			var paymentAccounts = document.getElementById('paymentAccounts');
			var paymentOptionCheque = document.getElementById('paymentOptionCheque');
			var paymentOptionBankFundTransfer = document.getElementById('paymentOptionBankFundTransfer');
			$(refundType).html('<option value="">Select Type</option>');
			$(amountDistribute).html('');
			$(paymentMethod).html('');
			$(paymentAccounts).html('');
			$(paymentOptionCheque).html('');
			$(paymentOptionBankFundTransfer).html('');
		}else{
			var balanceType   = document.getElementById('balanceType').value;
			var balanceAmount = parseFloat(document.getElementById('balanceAmount').value) || 0;
			var refundType = document.getElementById('refundType');
			if(balanceType == 'DUE'){
				
				if(refundAmountTotal < balanceAmount){
					var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="DUE_ADJUSTMENT" data-adjust-amount="'+refundAmountTotal+'">Due Adjustment</option>'+
										'<option value="DUE_ADJUSTMENT_AND_MONEY_RETURN" data-adjust-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Due Adjustment & Money Return</option>';
					$(refundType).html(refundTypeContent);
					
				}else if(refundAmountTotal > balanceAmount){
					var DUE_ADJUSTMENT_AND_MONEY_RETURN = refundAmountTotal - balanceAmount;
					var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="DUE_ADJUSTMENT_AND_MONEY_RETURN" data-adjust-amount="'+balanceAmount+'" data-return-amount="'+DUE_ADJUSTMENT_AND_MONEY_RETURN+'">Due Adjustment & Money Return</option>'+
										'<option value="DUE_ADJUSTMENT_AND_ADVANCE_ADD" data-adjust-amount="'+balanceAmount+'" data-advance-amount="'+DUE_ADJUSTMENT_AND_MONEY_RETURN+'">Due Adjustment & Advance Add</option>';
					$(refundType).html(refundTypeContent);
				}else if(refundAmountTotal == balanceAmount){
					var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="ADVANCE_ADD" data-advance-amount="'+refundAmountTotal+'">Advance Add</option>'+
										'<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Advance Add & Money Return</option>';
					$(refundType).html(refundTypeContent);
				}
				
			}else if(balanceType == 'ADVANCE'){
				var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="ADVANCE_ADD" data-advance-amount="'+refundAmountTotal+'">Advance Add</option>'+
										'<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Advance Add & Money Return</option>';
				$(refundType).html(refundTypeContent);
			}else if(balanceType == 'BALANCE'){
				var refundTypeContent = '<option value="">Select Type</option>'+
										'<option value="MONEY_RETURN" data-return-amount="'+refundAmountTotal+'">Money Return</option>'+
										'<option value="ADVANCE_ADD" data-advance-amount="'+refundAmountTotal+'">Advance Add</option>'+
										'<option value="ADVANCE_ADD_AND_MONEY_RETURN" data-advance-amount="'+refundAmountTotal+'" data-return-amount="'+refundAmountTotal+'">Advance Add & Money Return</option>';
				$(refundType).html(refundTypeContent);
			}
		}
		
		//Show amount in refund net total
		$('#showRefundNetTotal').html(formatNumber(refundNetTotal));
		$('#refundNetTotal').val(refundNetTotal);
		
		//Show amount in refund net profit
		$('#showRefundNetProfit').html(formatNumber(refundNetProfit));
		$('#refundNetProfit').val(refundNetProfit);
	}
	function formatIntNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(0));
		return formatTheNumber;
	}
	function formatNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(2));
		return formatTheNumber;
	}
	function deFormatNumber(number) {
		var a = number.replace(/\,/g,'');
		var result = parseFloat(a,10) || 0;
		return result;
	}
	function numberWithCommas(x) {
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	}
	function setSl(selector)
	{
		var particularsItmSl = $(selector);
		for(var i=0; i < particularsItmSl.length; i++){
			var element = particularsItmSl.eq(i);
			var x = i+1;
			if(x<10){
				var sl = '0'+x;
			}else{
				var sl = x;
			}
			$(element).text(sl);
		}
	}
/*********Calculation related functions ended**************/
</script>	
<script type="text/javascript">
	$(document).ready(function(){
		/*********Format number on keyup started**************/
		$(document).on('keyup', '.onchange-item-refund-qty', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.onchange-item-refund-charge', function(event){
			  // skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.format-payment-amount', function(event){
			  // skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		/*********Format number on keyup ended**************/
		
		$(document).on('click', '.remove-item-from-particulars', function(){	
			if(confirm('Are you sure?', true))
			{
				$(this).parent().parent().remove();
				setSl(".particulars-itm-sl");
				var totalItems = $('.particulars-item-row').length;
				if(totalItems < 1)
				{
					var content = '<tr>'+
									'<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="12">NO ITEMS FOUND</td>'+
								'</tr>';
					$("#productContents").html(content);
				}
				showCalculation();
				return false;
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		var accounts = '<?php echo $account_list; ?>';
		$(document).on('change', '#refundType', function(){
			var refundType = $(this).val();
			if(refundType == 'MONEY_RETURN'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var returnAmount = parseFloat(selectedOption.getAttribute('data-return-amount')) || 0;
				var content = '<fieldset class="form-group">'+
								'<label>MONEY RETURN AMOUNT</label>'+
								'<input type="text" id="moneyReturnAmount" class="form-control" value="&#2547; '+formatIntNumber(returnAmount)+'" disabled />'+
								'<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" value="'+returnAmount+'" />'+
							'</fieldset>';
				$('#amountDistribute').html(content);
				
				var payment_pathod = '<fieldset class="form-group">'+
										'<label>PAYMENT METHOD <span class="mendatory">*</span></label>'+
										'<select name="payment_method" class="form-control" id="paymentType" required>'+
											'<option value="CASH">CASH</option>'+
											'<option value="CHEQUE">CHEQUE</option>'+
											'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
											'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
										'</select>'+
									'</fieldset>';
				$('#paymentMethod').html(payment_pathod);
				
				var payment_accounts_content = '<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'DUE_ADJUSTMENT'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var adjustAmount = parseFloat(selectedOption.getAttribute('data-adjust-amount')) || 0;
				var content = '<fieldset class="form-group">'+
								'<label>DUE ADJUSTMENT AMOUNT</label>'+
								'<input type="text" id="dueAdjustmentAmount" class="form-control" value="&#2547; '+formatIntNumber(adjustAmount)+'" disabled />'+
								'<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="'+adjustAmount+'" />'+
							'</fieldset>';
				$('#amountDistribute').html(content);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'DUE_ADJUSTMENT_AND_MONEY_RETURN'){
				var content = '<fieldset class="form-group">'+
									'<label>DUE ADJUSTMENT AMOUNT</label>'+
									'<input type="text" id="dueAdjustmentAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" />'+
								'</fieldset>'+
								'<fieldset class="form-group">'+
									'<label>MONEY RETURN AMOUNT</label>'+
									'<input type="text" id="moneyReturnAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				
				var payment_pathod = '<fieldset class="form-group">'+
										'<label>PAYMENT METHOD <span class="mendatory">*</span></label>'+
										'<select name="payment_method" class="form-control" id="paymentType" required>'+
											'<option value="CASH">CASH</option>'+
											'<option value="CHEQUE">CHEQUE</option>'+
											'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
											'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
										'</select>'+
									'</fieldset>';
				$('#paymentMethod').html(payment_pathod);
				
				var payment_accounts_content = '<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'DUE_ADJUSTMENT_AND_ADVANCE_ADD'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var adjustAmount = parseFloat(selectedOption.getAttribute('data-adjust-amount')) || 0;
				var advanceAmount = parseFloat(selectedOption.getAttribute('data-advance-amount')) || 0;
				var content = '<fieldset class="form-group">'+
									'<label>DUE ADJUSTMENT AMOUNT</label>'+
									'<input type="text" id="dueAdjustmentAmount" class="form-control format-payment-amount" value="'+formatIntNumber(adjustAmount)+'" disabled />'+
									'<input type="hidden" name="due_adjustment_amount" id="dueAdjustmentAmountHidden" value="'+adjustAmount+'" />'+
								'</fieldset>'+
								'<fieldset class="form-group">'+
									'<label>ADVANCE ADD AMOUNT</label>'+
									'<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" value="'+formatIntNumber(advanceAmount)+'" disabled />'+
									'<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="'+advanceAmount+'" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'ADVANCE_ADD'){
				var selectedRefundType = document.getElementById('refundType');
				var selectedOption = selectedRefundType.options[selectedRefundType.selectedIndex];
				var advanceAmount = parseFloat(selectedOption.getAttribute('data-advance-amount')) || 0;
				var content = '<fieldset class="form-group">'+
									'<label>ADVANCE ADD AMOUNT</label>'+
									'<input type="text" id="advanceAddAmount" class="form-control" value="'+formatIntNumber(advanceAmount)+'" disabled />'+
									'<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" value="'+advanceAmount+'" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else if(refundType == 'ADVANCE_ADD_AND_MONEY_RETURN'){
				var content = '<fieldset class="form-group">'+
									'<label>ADVANCE ADD AMOUNT</label>'+
									'<input type="text" id="advanceAddAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="advance_add_amount" id="advanceAddAmountHidden" />'+
								'</fieldset>'+
								'<fieldset class="form-group">'+
									'<label>MONEY RETURN AMOUNT</label>'+
									'<input type="text" id="moneyReturnAmount" class="form-control format-payment-amount" required />'+
									'<input type="hidden" name="money_return_amount" id="moneyReturnAmountHidden" />'+
								'</fieldset>';
				$('#amountDistribute').html(content);
				
				var payment_pathod = '<fieldset class="form-group">'+
										'<label>PAYMENT METHOD <span class="mendatory">*</span></label>'+
										'<select name="payment_method" class="form-control" id="paymentType" required>'+
											'<option value="CASH">CASH</option>'+
											'<option value="CHEQUE">CHEQUE</option>'+
											'<option value="BANK_FUND_TRANSFER">BANK FUND TRANSFER</option>'+
											'<option value="MOBILE_BANKING">MOBILE BANKING</option>'+
										'</select>'+
									'</fieldset>';
				$('#paymentMethod').html(payment_pathod);
				
				var payment_accounts_content = '<div style="position: absolute;top: 13px;right: -235px;width: 260px;" id="accountBalance"></div>'+
													'<fieldset class="form-group">'+
														'<label>ACCOUNT <span class="mendatory">*</span></label>'+
														'<select name="account_id" id="onChangeAccount" class="form-control" required>'+accounts+
														'</select>'+
												'</fieldset>';
				$('#paymentAccounts').html(payment_accounts_content);
				
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}else{
				$('#amountDistribute').html('');
				$('#paymentMethod').html('');
				$('#paymentAccounts').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}
		});
		
		$(document).on('change', '#paymentType', function(){
			var payment_type = $(this).val();
			if(payment_type == 'CASH'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
			}else if(payment_type == 'CHEQUE'){
				$('#accountBalance').html('');
				$('#paymentOptionBankFundTransfer').html('');
				$('#paymentOptionMobileBanking').html('');
				var payment_option_cheque = '<fieldset class="form-group">'+
												'<label>CHEQUE NUMBER <span class="mendatory">*</span></label>'+
												'<input type="text" name="cheque_number" class="form-control" placeholder="Enter cheque number" required />'+
											'</fieldset>'+
											'<fieldset class="form-group">'+
												'<label>DEPOSIT BRANCH <span class="mendatory">*</span></label>'+
												'<input type="text" name="deposit_branch" class="form-control" placeholder="Enter deposit branch" required />'+
											'</fieldset>'+
											'<fieldset class="form-group">'+
												'<label style="width:100%">UPLOAD DEPOSIT SLIP</label>'+
												'<input type="file" id="onchangeFile" name="deposit_slip" />'+
											'</fieldset>';
				$('#paymentOptionCheque').html(payment_option_cheque);
				
			}else if(payment_type == 'BANK_FUND_TRANSFER'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionMobileBanking').html('');
				
				var payment_option_bank_fund_transfer_content = '<fieldset class="form-group">'+
																	'<label>RECEIPT NUMBER <span class="mendatory">*</span></label>'+
																	'<input type="text" name="receipt_number" class="form-control" placeholder="Enter receipt number" required />'+
																'</fieldset>'+
																'<fieldset class="form-group">'+
																	'<label style="width:100%">UPLOAD TRANSFER RECEIPT</label>'+
																	'<input type="file" id="onchangeFile" name="transfer_receipt" />'+
																'</fieldset>';
				$('#paymentOptionBankFundTransfer').html(payment_option_bank_fund_transfer_content);
			}else if(payment_type == 'MOBILE_BANKING'){
				$('#accountBalance').html('');
				$('#paymentOptionCheque').html('');
				$('#paymentOptionBankFundTransfer').html('');
			}
			
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/payments/accounts_by_type",
				data : {type:payment_type},
				dataType : "json",
				cache: false,
				success : function (data) {
					if(data.status == "ok")
					{
						$("#onChangeAccount").html(data.content);
						return false;
					}
					return false;
				}
			});
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onChangeAccount', function(){
			var account_id = $(this).val();
			if(account_id !== ''){
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/payments/get_account_balance",
					data : {id:account_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$("#accountBalance").html(data.content);
							if(data.available_balance < 1)
							{
								$('#payAmount').prop('disabled', true);
							}else{
								$('#payAmount').prop('disabled', false);
							}
							return false;
						}else
						{
							$("#accountBalance").html('');
							return false;
						}
						return false;
					}
				});
			}else{
				$("#accountBalance").html('');
				return false;
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('keyup', '#dueAdjustmentAmount', function(){
			var receivableAmountInput = document.getElementById('receivableAmount');
			var moneyReturnAmount = document.getElementById('moneyReturnAmount');
			var moneyReturnAmountHidden = document.getElementById('moneyReturnAmountHidden');
			var dueAdjustmentAmountHidden = document.getElementById('dueAdjustmentAmountHidden');
			var receivableAmount = parseFloat($(receivableAmountInput).val()) || 0;
			var dueAdjustmentAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			if(dueAdjustmentAmount > receivableAmount)
			{
				alert("Sorry receivable amount is : "+ formatIntNumber(receivableAmount));
				$(this).val('');
			}else{
				var setMoneyReturnAmount = receivableAmount - dueAdjustmentAmount;
				$(moneyReturnAmount).val(formatIntNumber(setMoneyReturnAmount));
				$(moneyReturnAmountHidden).val(setMoneyReturnAmount);
				$(dueAdjustmentAmountHidden).val(dueAdjustmentAmount);
			}
		});
		
		$(document).on('keyup', '#moneyReturnAmount', function(){
			var receivableAmountInput = document.getElementById('receivableAmount');
			
			var dueAdjustmentAmount = document.getElementById('dueAdjustmentAmount');
			var dueAdjustmentAmountHidden = document.getElementById('dueAdjustmentAmountHidden');
			
			var advanceAddAmount = document.getElementById('advanceAddAmount');
			var advanceAddAmountHidden = document.getElementById('advanceAddAmountHidden');
			
			var moneyReturnAmountHidden = document.getElementById('moneyReturnAmountHidden');
			
			var receivableAmount = parseFloat($(receivableAmountInput).val()) || 0;
			var moneyReturnAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			if(moneyReturnAmount > receivableAmount)
			{
				alert("Sorry receivable amount is : "+ formatIntNumber(receivableAmount));
				$(this).val('');
			}else{
				var setDueAdjustmentAmount = receivableAmount - moneyReturnAmount;
				
				$(dueAdjustmentAmount).val(formatIntNumber(setDueAdjustmentAmount));
				$(dueAdjustmentAmountHidden).val(setDueAdjustmentAmount);
				
				$(advanceAddAmount).val(formatIntNumber(setDueAdjustmentAmount));
				$(advanceAddAmountHidden).val(setDueAdjustmentAmount);
				$(moneyReturnAmountHidden).val(moneyReturnAmount);
			}
		});
		
		$(document).on('keyup', '#advanceAddAmount', function(){
			var receivableAmountInput = document.getElementById('receivableAmount');
			var moneyReturnAmount = document.getElementById('moneyReturnAmount');
			var moneyReturnAmountHidden = document.getElementById('moneyReturnAmountHidden');
			var advanceAddAmountHidden = document.getElementById('advanceAddAmountHidden');
			var receivableAmount = parseFloat($(receivableAmountInput).val()) || 0;
			var advanceAddAmount = parseFloat(deFormatNumber($(this).val())) || 0;
			if(advanceAddAmount > receivableAmount)
			{
				alert("Sorry receivable amount is : "+ formatIntNumber(receivableAmount));
				$(this).val('');
			}else{
				var setMoneyReturnAmount = receivableAmount - advanceAddAmount;
				$(moneyReturnAmount).val(formatIntNumber(setMoneyReturnAmount));
				$(moneyReturnAmountHidden).val(setMoneyReturnAmount);
				$(advanceAddAmountHidden).val(advanceAddAmount);
			}
		});
	});
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>