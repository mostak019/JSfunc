<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#">purchase refund</a></li>
			<li class="breadcrumb-item active">view</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<section class="invoice-view-wrapper">
	<div class="row">
		<!-- invoice view page -->
		<div class="invoice-container">
			<div class="card invoice-print-area">
				<div class="card-content">
					<?php $company_info = get_company_info(); ?>
					<div class="card-body pb-0" style="padding:10px !important">
						<div class="text-right">
							<div class="invoice-action-btn">
								<a href="<?php echo base_url('purchase/purchaserefund/edit/'.$refund_info['refund_formatted_id']); ?>" class="btn btn-info"> <i class="bx bx-edit"></i> <span>Edit</span> </a>
							</div>
							<div class="invoice-action-btn">
								<button class="btn btn-primary invoice-send-btn"> <i class="bx bx-send"></i> <span>Send</span> </button>
							</div>
							<div class="invoice-action-btn">
								<a href="<?php echo base_url('purchase/purchaserefund/download/'.$refund_info['refund_formatted_id'].'?TYPE=DETAILS'); ?>" class="btn btn-success"> <i class='bx bx-download'></i> <span>Download</span> </a>
							</div>
							<div class="invoice-action-btn">
								<button class="btn btn-info invoice-print" onclick="documentPrint()"><i class="bx bx-printer"></i> <span>print</span> </button>
							</div>
						</div>
						<!-- header section -->
						<div class="row">
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2><?php echo $company_info['company_name']; ?></h2>
									<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
									<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
									<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
									<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
								</div>
							</div>
							<div class="col-md-4">
								<span class="invoice-label-txt">PURCHASE REFUND</span>
							</div>
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2>REFUND VOUCHAR</h2>
									<p><strong>Refund Vouchar No : </strong> <?php echo $refund_info['refund_voucher_number']; ?></p>
									<p><strong>Refund Invoice No : </strong> <?php echo $refund_info['invoice_number']; ?></p>
									<p><strong>Refund Date : </strong> <?php echo date("d F, Y", strtotime($refund_info['refund_date'])); ?></p>
									<p><strong>Refund By : </strong> <?php echo $refund_info['admin_full_name']; ?></p>
									<p><strong>Refund Type : </strong> <span style="font-size:11px;"><?php echo str_replace('_', ' ', $refund_info['refund_payment_type']); ?></span></p>
									<p><strong>Branch : </strong> <?php echo $refund_info['branch_name']; ?></p>
								</div>
							</div>
						</div>
					</div>
					<div class="card-body pb-0" style="padding: 10px;margin-bottom: 25px;">
						<div class="row">
							<div class="col-md-6">
								<div class="invoice-company-info invoice-customer-info">
									<h2>REFUND TO</h2>
									<p><strong><?php echo $refund_info['supplier_name']; ?></strong></p>
									<p><strong>Cell No : </strong> <?php echo $refund_info['supplier_telephone_number']; ?></p>
									<p><strong>Address : </strong> <?php echo $refund_info['supplier_address']; ?></p>
								</div>
							</div>
							<div class="col-md-2"></div>
							<div class="col-md-4">
							</div>
						</div>
					</div>
					
					<!-- invoice address and contact -->
					<hr>
					<!-- product details table-->
					<div class="invoice-product-details table-responsive">
						<h3 class="invoice-items-title">REFUND ITEM DETAILS</h3>
						<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
							<thead>
								  <tr class="border-0">
									<th style="width:3%;">S.No</th>
									<th style="width:25%;">PRODUCT</th>
									<th class="text-center" style="width: 5%;">PHOTO</th>
									<th class="text-center" style="width:1%">REFUND QTY</th>
									<th class="text-center" style="width: 7%;">UNIT</th>
									<th class="text-center" style="width: 7%;">UNIT PRICE</th>
									<th class="text-right" style="width: 12%;">REFUND SUBTOTAL</th>
									<th class="text-right" style="width:11%;">REFUND CHARGE</th>
									<th class="text-right" style="width: 11%;">REFUND AMOUNT</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$content = '';
									$total_refund_charges = 0;
									$total_refund_amount = 0;
									$total_refund_subtotal = 0;
									$products = $this->Purchaserefund_model->get_refund_items($refund_info['refund_id']);
									if(is_array($products) && count($products) !== 0):
										$x = 1;
										foreach($products as $item)
										{
											$product_id = $item['refitem_product_id'];
											$product_info = $this->Purchaserefund_model->get_product_info($item['refitem_product_id']);
											if($product_info['product_type'] == 'GENERAL'){
												$photo_url = get_product_photo_url($product_info['product_id']);
											}else{
												$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
											}
											$purchase_has_variations = $product_info['product_has_variations'];
											if($purchase_has_variations == 'YES'){
												$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_option_id($item['refitem_order_id'], $item['refitem_product_id'], $item['refitem_variation_option_id']);
											}else{
												$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_id($item['refitem_order_id'], $item['refitem_product_id']);
											}
											$product = array_merge($item, $purchase_item);
											if($x < 10){
												$sl = '0'.$x;
											}else{
												$sl = $x;
											}
											if($purchase_has_variations == 'YES'){
												$provariation_id = $product['oitem_provariation_id'];
												$variation_option_id = $product['oitem_variation_option_id'];
												$variant_name   = $this->Purchaserefund_model->get_variant_name($provariation_id);
												$option_name   = $this->Purchaserefund_model->get_option_name($variation_option_id);
												$variation_content = '<br style="margin-bottom:5px;" /> <strong>Description :</strong> '.$variant_name.' : '.$option_name;
												$variation_id = $this->Purchaserefund_model->get_variation_id($provariation_id, $item['refitem_product_id']);
												$quantity    = product_purchase_refundable_qty_by_variation($item['refitem_order_id'], $item['refitem_product_id'], $variation_id, $variation_option_id) + intval($product['refitem_refund_qty']);
											}else{
												$variation_content = '';
												$quantity    = product_purchase_refundable_qty($item['refitem_order_id'], $item['refitem_product_id']) + intval($product['refitem_refund_qty']);
											}
											$unit_id     = $product['oitem_unit_id'];
											$unit_name   = $this->Purchaserefund_model->get_unit_name($unit_id);
											$purchase_price = $product['oitem_purchase_per_qty'];
											$sale_price     = $product['oitem_sale_per_qty'];
											$profit_per_qty = $product['oitem_profit_per_qty'];
											$subtotal_amount = $product['oitem_subtotal'];
											
											$total_refund_charges += $product['refitem_refund_charge'];
											$total_refund_amount += $product['refitem_refund_amount'];
											$total_refund_subtotal += $product['refitem_refund_subtotal'];
											if($product_info['product_type'] == 'GENERAL'){
												$product_title = $product_info['product_name']; 
											}else{
												$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
												$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
											}
											$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
															<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
															<td>
																'.$product_title.'
																<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
																'.$variation_content.'
															</td>
															<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
															<td class="text-center">'.number_format($product['refitem_refund_qty'], 0, '.', ',').'</td>
															<td class="text-center">'.$unit_name.'</td>
															<td class="text-center text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($purchase_price, 0, '.', ',').' /-</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($product['refitem_refund_subtotal'], 0, '.', ',').' /-</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($product['refitem_refund_charge'], 0, '.', ',').' /-</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($product['refitem_refund_amount'], 0, '.', ',').' /-</td>
														</tr>';
											$x++;
										}
										echo $content;
									else: 
								?>
								<tr>
									<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="9">NO ITEMS FOUND</td>
								</tr>
								<?php endif; ?>
								<tr>
									<td colspan="6" class="text-right font-weight-bold">Total</td>
									<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> <?php echo number_format($total_refund_subtotal, 0, '.', ','); ?> /-</td>
									<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> <?php echo number_format($total_refund_charges, 0, '.', ','); ?> /-</td>
									<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> <?php echo number_format($total_refund_amount, 0, '.', ','); ?> /-</td>
								</tr>
							</tbody>
						</table>
					</div>
					<!-- invoice subtotal -->
					<div class="card-body pt-0" style="padding: 0 10px 15px;">
						<div class="row">
							<?php if($refund_info['refund_terms'] && $refund_info['refund_remarks']): ?>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Terms</strong></p>
									<p><?php echo $refund_info['refund_terms']; ?></p>
								</div>
							</div>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Remarks</strong></p>
									<p><?php echo $refund_info['refund_remarks']; ?></p>
								</div>
							</div>
							<?php elseif($refund_info['refund_terms'] || $refund_info['refund_remarks']): ?>
								<div class="col-8 col-sm-8 mt-75">
									<?php if($refund_info['refund_terms']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Terms</strong></p>
										<p><?php echo $refund_info['refund_terms']; ?></p>
									</div>
									<?php elseif($refund_info['refund_remarks']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Remarks</strong></p>
										<p><?php echo $refund_info['refund_remarks']; ?></p>
									</div>
									<?php endif; ?>
								</div>
							<?php else: ?>
							<div class="col-8 col-sm-8 mt-75"></div>
							<?php endif; ?>
							<div class="col-4 col-sm-4 d-flex justify-content-end mt-75">
								<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
									<tbody>
										<tr>
											<td class="text-right">Refund Subtotal</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Total Refund Charges</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_charge_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-primary text-right">Total Amount to be Refunded</td>
											<td class="text-primary text-right font-weight-bold" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_amount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Refund Net Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Refund Net Profit</td>
											<td class="text-right" style="color:#0B0;width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_net_profit'], 2, '.', ','); ?></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($refund_info['refund_net_total']); ?>)</p>
						<hr />
						<p class="text-center">Thanks for your business with us.</p>
					</div>
				</div>
			</div>
		</div>
		
		<!--Print Copy-->
		<div class="invoice-container" id="printCopy" style="display:none">
			<div class="card invoice-print-area">
				<div class="card-content">
					<div class="card-body pb-0" style="padding:10px !important">
						<!-- header section -->
						<div class="row">
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2><?php echo $company_info['company_name']; ?></h2>
									<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
									<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
									<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
									<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
								</div>
							</div>
							<div class="col-md-4">
								<span class="invoice-label-txt">PURCHASE REFUND</span>
							</div>
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2>REFUND VOUCHAR</h2>
									<p><strong>Refund Vouchar No : </strong> <?php echo $refund_info['refund_voucher_number']; ?></p>
									<p><strong>Refund Invoice No : </strong> <?php echo $refund_info['invoice_number']; ?></p>
									<p><strong>Refund Date : </strong> <?php echo date("d F, Y", strtotime($refund_info['refund_date'])); ?></p>
									<p><strong>Refund By : </strong> <?php echo $refund_info['admin_full_name']; ?></p>
									<p><strong>Refund Type : </strong> <span style="font-size:11px;"><?php echo str_replace('_', ' ', $refund_info['refund_payment_type']); ?></span></p>
									<p><strong>Branch : </strong> <?php echo $refund_info['branch_name']; ?></p>
								</div>
							</div>
						</div>
					</div>
					<div class="card-body pb-0" style="padding: 10px;margin-bottom: 25px;">
						<div class="row">
							<div class="col-md-6">
								<div class="invoice-company-info invoice-customer-info">
									<h2>REFUND TO</h2>
									<p><strong><?php echo $refund_info['supplier_name']; ?></strong></p>
									<p><strong>Cell No : </strong> <?php echo $refund_info['supplier_telephone_number']; ?></p>
									<p><strong>Address : </strong> <?php echo $refund_info['supplier_address']; ?></p>
								</div>
							</div>
							<div class="col-md-2"></div>
							<div class="col-md-4">
							</div>
						</div>
					</div>
					
					<!-- invoice address and contact -->
					<hr>
					<!-- product details table-->
					<div class="invoice-product-details table-responsive">
						<h3 class="invoice-items-title">REFUND ITEM DETAILS</h3>
						<table class="table table-bordered table-striped mb-0" style="width:98% !important;margin:0 auto;">
							<thead>
								  <tr class="border-0">
									<th style="width:3%;">S.No</th>
									<th style="width:25%;">PRODUCT</th>
									<th class="text-center" style="width: 5%;">PHOTO</th>
									<th class="text-center" style="width:1%">REFUND QTY</th>
									<th class="text-center" style="width: 7%;">UNIT</th>
									<th class="text-center" style="width: 7%;">UNIT PRICE</th>
									<th class="text-right" style="width: 12%;">REFUND SUBTOTAL</th>
									<th class="text-right" style="width:11%;">REFUND CHARGE</th>
									<th class="text-right" style="width: 11%;">REFUND AMOUNT</th>
								</tr>
							</thead>
							<tbody>
								<?php 
									$content = '';
									$total_refund_charges = 0;
									$total_refund_amount = 0;
									$total_refund_subtotal = 0;
									$products = $this->Purchaserefund_model->get_refund_items($refund_info['refund_id']);
									if(is_array($products) && count($products) !== 0):
										$x = 1;
										foreach($products as $item)
										{
											$product_id = $item['refitem_product_id'];
											$product_info = $this->Purchaserefund_model->get_product_info($item['refitem_product_id']);
											$photo_url = $this->Purchaserefund_model->get_product_photo_url($product_info['product_id']);
											$purchase_has_variations = $product_info['product_has_variations'];
											if($purchase_has_variations == 'YES'){
												$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_option_id($item['refitem_order_id'], $item['refitem_product_id'], $item['refitem_variation_option_id']);
											}else{
												$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_id($item['refitem_order_id'], $item['refitem_product_id']);
											}
											$product = array_merge($item, $purchase_item);
											if($x < 10){
												$sl = '0'.$x;
											}else{
												$sl = $x;
											}
											if($purchase_has_variations == 'YES'){
												$provariation_id = $product['oitem_provariation_id'];
												$variation_option_id = $product['oitem_variation_option_id'];
												$variant_name   = $this->Purchaserefund_model->get_variant_name($provariation_id);
												$option_name   = $this->Purchaserefund_model->get_option_name($variation_option_id);
												$variation_content = '<br style="margin-bottom:5px;" /> <strong>Description :</strong> '.$variant_name.' : '.$option_name;
												$variation_id = $this->Purchaserefund_model->get_variation_id($provariation_id, $item['refitem_product_id']);
												$quantity    = product_purchase_refundable_qty_by_variation($item['refitem_order_id'], $item['refitem_product_id'], $variation_id, $variation_option_id) + intval($product['refitem_refund_qty']);
											}else{
												$variation_content = '';
												$quantity    = product_purchase_refundable_qty($item['refitem_order_id'], $item['refitem_product_id']) + intval($product['refitem_refund_qty']);
											}
											$unit_id     = $product['oitem_unit_id'];
											$unit_name   = $this->Purchaserefund_model->get_unit_name($unit_id);
											$purchase_price = $product['oitem_purchase_per_qty'];
											$sale_price     = $product['oitem_sale_per_qty'];
											$profit_per_qty = $product['oitem_profit_per_qty'];
											$subtotal_amount = $product['oitem_subtotal'];
											
											$total_refund_charges += $product['refitem_refund_charge'];
											$total_refund_amount += $product['refitem_refund_amount'];
											$total_refund_subtotal += $product['refitem_refund_subtotal'];
											
											$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
															<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
															<td>
																'.$product_info['product_name'].'
																<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
																'.$variation_content.'
															</td>
															<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
															<td class="text-center">'.number_format($product['refitem_refund_qty'], 0, '.', ',').'</td>
															<td class="text-center">'.$unit_name.'</td>
															<td class="text-center text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($purchase_price, 0, '.', ',').' /-</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($product['refitem_refund_subtotal'], 0, '.', ',').' /-</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($product['refitem_refund_charge'], 0, '.', ',').' /-</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> '.number_format($product['refitem_refund_amount'], 0, '.', ',').' /-</td>
														</tr>';
											$x++;
										}
										echo $content;
									else: 
								?>
								<tr>
									<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="9">NO ITEMS FOUND</td>
								</tr>
								<?php endif; ?>
								<tr>
									<td colspan="6" class="text-right font-weight-bold">Total</td>
									<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> <?php echo number_format($total_refund_subtotal, 0, '.', ','); ?> /-</td>
									<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> <?php echo number_format($total_refund_charges, 0, '.', ','); ?> /-</td>
									<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong> <?php echo number_format($total_refund_amount, 0, '.', ','); ?> /-</td>
								</tr>
							</tbody>
						</table>
					</div>
					<!-- invoice subtotal -->
					<div class="card-body pt-0" style="padding: 0 10px 15px;">
						<div class="row">
							<?php if($refund_info['refund_terms'] && $refund_info['refund_remarks']): ?>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Terms</strong></p>
									<p><?php echo $refund_info['refund_terms']; ?></p>
								</div>
							</div>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Remarks</strong></p>
									<p><?php echo $refund_info['refund_remarks']; ?></p>
								</div>
							</div>
							<?php elseif($refund_info['refund_terms'] || $refund_info['refund_remarks']): ?>
								<div class="col-8 col-sm-8 mt-75">
									<?php if($refund_info['refund_terms']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Terms</strong></p>
										<p><?php echo $refund_info['refund_terms']; ?></p>
									</div>
									<?php elseif($refund_info['refund_remarks']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Remarks</strong></p>
										<p><?php echo $refund_info['refund_remarks']; ?></p>
									</div>
									<?php endif; ?>
								</div>
							<?php else: ?>
							<div class="col-8 col-sm-8 mt-75"></div>
							<?php endif; ?>
							<div class="col-4 col-sm-4 d-flex justify-content-end mt-75">
								<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
									<tbody>
										<tr>
											<td class="text-right">Refund Subtotal</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Total Refund Charges</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_charge_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Total Amount to be Refunded</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_amount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Refund Net Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Refund Net Profit</td>
											<td class="text-right" style="color:#0B0;width:150px;"><strong>&#2547;</strong> <?php echo number_format($refund_info['refund_net_profit'], 2, '.', ','); ?></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($refund_info['refund_net_total']); ?>)</p>
						<hr />
						<p class="text-center">Thanks for your business with us.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	function documentPrint() 
	{
	  var documentContent=document.getElementById('printCopy');
	  var newWin=window.open('','Print-Window');
	  var content = '<!DOCTYPE html>'+
					'<html class="loading" lang="en" data-textdirection="ltr">'+
					'<head>'+
						'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'+
						'<meta http-equiv="X-UA-Compatible" content="IE=edge">'+
						'<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">'+
						'<title>Print Copy</title>'+
						'<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('backend/app-assets/images/ico/favicon.ico'); ?>">'+
						'<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/pages/app-invoice.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap-extended.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/colors.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/components.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/dark-layout.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/semi-dark-layout.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/assets/css/style.css'); ?>">'+
					'</head>'+
					'<body onload="window.print()">'+documentContent.innerHTML+'</body></html>';

	  newWin.document.open();
	  newWin.document.write(content);
	  newWin.document.close();
	  setTimeout(function(){newWin.close();},10);
	}
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>