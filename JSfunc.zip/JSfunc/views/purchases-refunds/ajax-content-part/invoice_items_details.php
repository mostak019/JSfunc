<?php 
	$accounts = get_accounts_by_type('PETTY_CASH');
	$account_list = '<option value="">Select Account</option>';  
	foreach($accounts as $account):
		$account_list .= '<option value="'.$account['account_id'].'">'.$account['account_title'].'</option>';
	endforeach;
?>
<div class="row">
	<div class="col-md-12">
		<div class="row" style="padding: 0 3px;">
			<div class="col-md-15"></div>
			<div class="col-md-15"></div>
			<div class="col-md-15">
				<label style="padding-top: 9px;display: block;">REFUND DATE <span class="mendatory">*</span></label>
				<fieldset class="form-group position-relative has-icon-left">
					<input type="text" name="refund_date" value="<?php echo date("d F, Y"); ?>" class="form-control pickadate-months-year" placeholder="Select Date">
					<div class="form-control-position dpicker-icon-position">
						<i class='bx bx-calendar' style="top:-25px !important"></i>
					</div>
				</fieldset>
			</div>
			<div class="col-md-15">
				<label style="padding-top: 9px;display: block;">BRANCH <span class="mendatory">*</span></label>
				<fieldset class="form-group">
					<select name="branch" class="custom-select" id="onChangeBranch">
						<option value="">Select Branch</option>
						<?php 
							$branchs = $this->Purchaserefund_model->get_all_branchs();
							foreach($branchs as $branch):
						?>
						<option value="<?php echo $branch['branch_id']; ?>"><?php echo $branch['branch_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</fieldset>
			</div>
			<div class="col-md-15">
				<label style="padding-top: 9px;display: block;">WAREHOUSE <span class="mendatory">*</span></label>
				<fieldset class="form-group">
					<select name="warehouse" class="custom-select" id="warehouseContent">
						<option value="">Select Warehouse</option>
					</select>
				</fieldset>
			</div>
		</div>
		<div class="card set-position-relative">
			<div class="card-header" style="margin-bottom: 0;">
				<h4 class="card-title">Purchase Informations</h4>
			</div>
			<div class="card-content" style="padding: 15px 0 30px;">
				<div class="card-body" style="padding:0">
					<div class="row">
						<div class="col-md-12">
							<!-- table striped -->
							<div class="table-responsive">
							  <table class="table mb-0">
								<thead>
								  <tr>
									<th class="text-center">Invoice Number</th>
									<th class="text-center">Order Number</th>
									<th class="text-center">Order date</th>
									<th class="text-center">Supplier</th>
									<th class="text-center">Purchased By</th>
									<th class="text-center">Sub Total</th>
									<th class="text-center">Net Total</th>
								  </tr>
								</thead>
								<tbody>
									<tr>
										<td class="text-center"><?php echo $order_info['invoice_number']; ?></td>
										<td class="text-center"><?php echo $order_info['order_number']; ?></td>
										<td class="text-center"><?php echo date("d F, Y", strtotime($order_info['order_date'])); ?></td>
										<td class="text-center"><?php echo $order_info['supplier_name']; ?></td>
										<td class="text-center"><?php echo $order_info['admin_full_name']; ?></td>
										<td class="text-center"><?php echo number_format($order_info['osummery_subtotal'], 2, '.', ','); ?></td>
										<td class="text-center"><?php echo number_format($order_info['osummery_net_total'], 2, '.', ','); ?></td>
										
										<input type="hidden" name="supplier_id" value="<?php echo $order_info['order_supplier_id']; ?>" />
										<input type="hidden" name="invoice_id" value="<?php echo $order_info['invoice_id']; ?>" />
										<input type="hidden" name="invoice_number" value="<?php echo $order_info['invoice_number']; ?>" />
										<input type="hidden" name="order_id" value="<?php echo $order_info['order_id']; ?>" />
									</tr>
								</tbody>
							  </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<h4 class="card-title" style="margin-bottom: 5px;">PURCHASE ITEMS</h4>
		<div class="card set-position-relative">
			<div class="card-content">
				<div class="card-body" style="padding:0">
					<div class="row">
						<div class="col-md-12">
							<!-- table striped -->
							<div class="table-responsive">
							  <table class="table table-striped mb-0">
								<thead>
									<tr>
										<th style="width:3%;">S.No</th>
										<th style="width:20%;">PRODUCT</th>
										<th class="text-center">PHOTO</th>
										<th class="text-center" style="width: 9%;">REFUNDABLE QTY</th>
										<th class="text-center">UNIT</th>
										<th class="text-center" style="width: 10%;">PURCHASE PRICE</th>
										<th class="text-center" style="width: 5%;">SUBTOTAL</th>
										<th class="text-center" style="width:10%">REFUND QTY</th>
										<th class="text-center" style="width:10%">REFUND CHARGE</th>
										<th class="text-center" style="width: 10%;">REFUND AMOUNT</th>
										<th class="text-center" style="width: 10%;">REFUND SUBTOTAL</th>
										<th class="text-center" style="width: 1%;">REMOVE</th>
									</tr>
								</thead>
								<tbody id="productContents">
									<?php 
										$content = '';
										$products = $this->Purchaserefund_model->get_order_items($order_info['order_id']);
										if(is_array($products) && count($products) !== 0):
											$x = 1;
											foreach($products as $product)
											{
												$product_id = $product['oitem_product_id'];
												$product_info = $this->Purchaserefund_model->get_product_info($product['oitem_product_id']);
												if($product_info['product_type'] == 'GENERAL'){
													$photo_url = get_product_photo_url($product_info['product_id']);
												}else{
													$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
												}
												$purchase_has_variations = $product_info['product_has_variations'];
												if($x < 10){
													$sl = '0'.$x;
												}else{
													$sl = $x;
												}
												if($purchase_has_variations == 'YES'){
													$provariation_id = $product['oitem_provariation_id'];
													$variation_option_id = $product['oitem_variation_option_id'];
													$variant_name   = $this->Purchaserefund_model->get_variant_name($provariation_id);
													$option_name   = $this->Purchaserefund_model->get_option_name($variation_option_id);
													$variation_content = '<br style="margin-bottom:5px;" /> <strong>Description :</strong> '.$variant_name.' : '.$option_name
																		 .'<input type="hidden" name="item_provariation_id_'.$x.'" class="update-provariation-id-'.$x.'" value="'.$provariation_id.'" />
																			<input type="hidden" name="item_variation_option_id_'.$x.'" class="update-variation-option-id-'.$x.'" value="'.$variation_option_id.'" />';
													$variation_id = $this->Purchaserefund_model->get_variation_id($provariation_id, $product['oitem_product_id']);
													$quantity    = product_purchase_refundable_qty_by_variation($order_info['order_id'], $product['oitem_product_id'], $variation_id, $variation_option_id);
												}else{
													$variation_content = '';
													$quantity    = product_purchase_refundable_qty($order_info['order_id'], $product['oitem_product_id']);
												}
												$unit_id     = $product['oitem_unit_id'];
												$unit_name   = $this->Purchaserefund_model->get_unit_name($unit_id);
												$purchase_price = $product['oitem_purchase_per_qty'];
												$sale_price     = $product['oitem_sale_per_qty'];
												$profit_per_qty = $product['oitem_profit_per_qty'];
												$subtotal_amount = $product['oitem_subtotal'];
												if($product_info['product_type'] == 'GENERAL'){
													$product_title = $product_info['product_name']; 
												}else{
													$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
													$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
												}
												if($quantity == 0){
													$refund_disabled = 'disabled';
												}else{
													$refund_disabled = '';
												}
												$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
																<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
																<td>
																	'.$product_title.'
																	<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
																	'.$variation_content.'
																	<input type="hidden" name="item_product_id_'.$x.'" value="'.$product_id.'" />
																</td>
																<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
																<td class="text-center">
																	'.$quantity.'
																	<input type="hidden" name="item_quantity_'.$x.'" class="qty-'.$x.'" value="'.$quantity.'" />
																</td>
																<td class="text-center">
																	'.$unit_name.'
																	<input type="hidden" name="item_unit_id_'.$x.'" class="unit-id-'.$x.'" value="'.$unit_id.'" />
																</td>
																<td class="text-center">
																	'.number_format($purchase_price, 0, '.', ',').'
																	<input type="hidden" name="item_purchase_per_qty_'.$x.'" class="purchase-price-'.$x.'" value="'.$purchase_price.'" />
																</td>
																<td class="text-center">
																	'.number_format($subtotal_amount, 0, '.', ',').'
																	<input type="hidden" class="subtotal-amounts-'.$x.'" name="item_subtotal_'.$x.'" value="'.$subtotal_amount.'" />
																</td>
																<td class="text-center">
																	<input type="text" class="form-control text-center onchange-item-refund-qty item-refund-qty-'.$x.'" data-row="'.$x.'" name="item_refund_qty_'.$x.'" required '.$refund_disabled.' /> 
																</td>
																<td class="text-center">
																	<input type="text" class="form-control text-center onchange-item-refund-charge item-refund-charge-total item-refund-charge-'.$x.'" data-row="'.$x.'" name="item_refund_charge_'.$x.'" required '.$refund_disabled.' /> 
																</td>
																<td class="text-center">
																	<input type="text" class="form-control text-center show-refund-amounts-'.$x.'" value="0" disabled />
																	<input type="hidden" class="refund-amounts refund-amounts-'.$x.'" name="item_refund_amount_'.$x.'" />
																</td>
																<td class="text-center">
																	<input type="text" class="form-control text-center show-refund-subtotal-amounts-'.$x.'" value="0" disabled />
																	<input type="hidden" class="refund-subtotal-amounts refund-subtotal-amounts-'.$x.'" name="item_refund_subtotal_'.$x.'" />
																</td>
																<td class="text-center">
																	<span class="remove-item-icon remove-item-from-particulars"><i class="bx bx-x"></i></span>
																</td>
																<input type="hidden" name="item_has_variations_'.$x.'" value="'.$purchase_has_variations.'" />
																<input type="hidden" name="particular_items[]" value="'.$x.'" />
															</tr>';
												$x++;
											}
											echo $content;
										else: 
									?>
									<tr>
										<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="10">NO ITEMS FOUND</td>
									</tr>
									<?php endif; ?>
								</tbody>
							  </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-5">
		<div class="card">
			<div class="card-header">
				<h4 class="card-title">Summery</h4>
			</div>
			<div class="card-content">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<fieldset class="form-group">
								<label>Terms</label>
								<textarea name="terms" class="form-control" cols="30" rows="4"></textarea>
							</fieldset>
						</div>
						<div class="col-md-6">
							<fieldset class="form-group">
								<label>Remarks</label>
								<textarea name="remarks" class="form-control" cols="30" rows="4"></textarea>
							</fieldset>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="card">
			<div class="card-header">
				<h4 class="card-title">Payment <br />
					<span style="text-transform: capitalize;margin-top: 5px;display: block;font-size: 12px;">Supplier Balanace : 
					(<span id="spShowBalance"><?php 
						$balance_info = get_the_supplier_balance($order_info['order_supplier_id']);
						if($balance_info['balance_type'] == 'DUE'){
							echo '<strong style="color:#E00">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
						}elseif ($balance_info['balance_type'] == 'ADVANCE') {
							echo '<strong style="color:#0A0">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
						}elseif ($balance_info['balance_type'] == 'BALANCE') {
							echo '<strong style="color:#333">'.$balance_info['balance_type'].'</strong> : '.number_format(floatval($balance_info['balance_amount']), 2, '.', ',');
						}else{
							echo '<strong style="color:#333">BALANCE</strong> : '.number_format(floatval(0), 2, '.', ',');
						}
					?> TK </span>)
					<?php echo '<input type="hidden" id="balanceType" value="'.$balance_info['balance_type'].'" /><input type="hidden" id="balanceAmount" value="'.$balance_info['balance_amount'].'" />'; ?>
					<?php echo '<input type="hidden" id="balanceTypeUpdated" value="'.$balance_info['balance_type'].'" /><input type="hidden" id="balanceAmountUpdated" value="'.$balance_info['balance_amount'].'" />'; ?>
					</span>
				</h4>
			</div>
			<div class="card-content">
				<div class="card-body">
					<div class="row">
						<div class="col-md-12">
							<fieldset class="form-group">
								<label>RECEIVABLE AMOUNT</label>
								<span id="displayReceivableAmount"><input type="text" class="form-control" value="<?php echo '&#2547; '.number_format(floatval(0), 0, '.', ','); ?>" disabled /></span>
								<input type="hidden" name="receivable_amount" id="receivableAmount" value="0" />
							</fieldset>
						</div>
						<div class="col-md-12">
							<fieldset class="form-group">
								<label>RECEIVABLE AMOUNT SHOULD BE</label>
								<select name="payment_refund_type" class="form-control" id="refundType" required readonly >
									<option value="">Select Type</option>
								</select>
							</fieldset>
						</div>
						<div class="col-md-12">
							<div id="amountDistribute"></div>
							<div id="paymentMethod"></div>
							<div id="paymentAccounts" class="set-position-relative"></div>
							<div id="paymentOptionCheque"></div>
							<div id="paymentOptionBankFundTransfer"></div>
						</div>
						<div class="col-md-12">
							
						</div>
						<div class="col-md-12">
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-4">
	  <div class="card">
		<div class="card-content">
		  <div class="card-body" style="padding-bottom: 2px;">
			  <div class="form-body">
				<div class="row">
				  <div class="col-12">
					<div class="invoice-subtotal">
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Refund Subtotal</span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="refund_subtotal" id="refundSubtotal" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Total Refund Charges</span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="refund_charge_total" id="refundChargeTotal" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Total Amount to be Refunded</span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="refund_amount_total" id="refundAmountTotal" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <hr>
					  <div class="invoice-calc d-flex justify-content-between" style="color:#a52323">
						<span class="invoice-title">Refund Net Total</span>
						<span class="invoice-value" style="font-size: 13px;padding: 0 15px;font-size: 14px;font-weight: bold;"><strong>BDT</strong> <span id="showRefundNetTotal">0.00</span></span>
						<input type="hidden" name="refund_net_total" id="refundNetTotal" />
					  </div>
					  <div class="invoice-calc d-flex justify-content-between" style="color:#2a7f52">
						<span class="invoice-title">Refund Net Profit</span>
						<span class="invoice-value" style="font-size: 13px;padding: 0 15px;font-size: 14px;font-weight: bold;"><strong>BDT</strong> <span id="showRefundNetProfit">0.00</span></span>
						<input type="hidden" name="refund_net_profit" id="refundNetProfit" />
					  </div>
					</div>
				  </div>
				  <div class="col-12 d-flex justify-content-end justify-content-custom">
					<button type="submit" class="btn btn-custom-form btn-primary mr-1 mb-1"><i class="bx bxs-send"></i> Create Refund Voucher</button>
				  </div>
				</div>
			  </div>
		  </div>
		</div>
	  </div>
	</div>
</div>