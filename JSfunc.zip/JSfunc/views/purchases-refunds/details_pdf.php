<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>PURCHASE REFUND DETAILS</title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('backend/app-assets/images/ico/favicon.ico'); ?>">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/pages/app-invoice.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap.pdf.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap-extended.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/colors.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/components.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/dark-layout.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/semi-dark-layout.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/assets/css/style.css'); ?>">
	<style type="text/css">
		body {
			margin: 0;
			font-size: 12px;
			color: #727E8C;
			background-color: #F2F4F4;
			line-height:18px;
		}
		p{color: #555;}
		th{
			color:#475F7B !important;
			font-size:11px !important;
			letter-spacing:1px !important;
			padding:5px !important;
		}
		th, td{padding:5px !important;border:1px solid #d5d5d5;}
		.table td, .table th {
			/* padding: 1.15rem 2rem; */
			/* border-top: 1px solid #DFE3E7; */
			padding: 10px !important;
			border-top: 0 !important;
			font-size: 11px !important;
		}
		strong{color: #4A4A4A;font-weight:bold}
		.table-striped tbody tr:nth-of-type(odd) {
			background-color: #FAFBFB;
		}
	</style>
</head>

<body>
	<?php $company_info = get_company_info(); ?>
	<div class="">
		<div class="">
			<div class="card-body pt-0" style="padding: 0 10px 15px;">
			<table style="border:0;width:100%">
				<tr>
					<td style="border:0;width:33.33%;">
						<div class="invoice-company-info">
							<h2><?php echo $company_info['company_name']; ?></h2>
							<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
							<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
							<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
							<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
						</div>
					</td>
					<td style="border:0;width:33.33%;text-align:center"><div class="text-center" style="width:100%;font-size:26px;">PURCHASE REFUND</h2></div>
					<td style="border:0;width:33.33%;">
						<div class="invoice-company-info">
							<h2>REFUND VOUCHAR</h2>
							<p><strong>Refund Vouchar No : </strong> <?php echo $refund_info['refund_voucher_number']; ?></p>
							<p><strong>Refund Invoice No : </strong> <?php echo $refund_info['invoice_number']; ?></p>
							<p><strong>Refund Date : </strong> <?php echo date("d F, Y", strtotime($refund_info['refund_date'])); ?></p>
							<p><strong>Refund By : </strong> <?php echo $refund_info['admin_full_name']; ?></p>
							<p><strong>Refund Type : </strong> <span style="font-size:11px;"><?php echo str_replace('_', ' ', $refund_info['refund_payment_type']); ?></span></p>
							<p><strong>Branch : </strong> <?php echo $refund_info['branch_name']; ?></p>
						</div>
					</td>
				</tr>
			</table>
			<table style="border:0;width:100%">
				<tr>
					<td style="border:0;width:50%">
						<div class="invoice-company-info invoice-customer-info">
							<h2>REFUND TO</h2>
							<p><strong><?php echo $refund_info['supplier_name']; ?></strong></p>
							<p><strong>Cell No : </strong> <?php echo $refund_info['supplier_telephone_number']; ?></p>
							<p><strong>Address : </strong> <?php echo $refund_info['supplier_address']; ?></p>
						</div>
					</td>
					<td style="border:0;width:16.66%"></td>
					<td style="border:0;width:33.33%">
					</td>
				</tr>
			</table>
			</div>
			
			<!-- invoice address and contact -->
			<div style="height:0;margin-top:1rem;margin-bottom:1rem;display:block; width:100%; border-top:1px solid #DFE3E7;border-style:dotted;"></div>
			<div class="card-body pt-0" style="padding: 0 10px 15px;">
				<h3 class="invoice-items-title">REFUND ITEM DETAILS</h3>
				<table class="table table-bordered table-striped" style="border:0;width:100%">
					<thead class="items-thead">
						<tr>
							<th style="padding:5px;border-bottom:0px;">S.No</th>
							<th style="padding:5px;border-bottom:0px;">PRODUCT</th>
							<th class="text-center" style="padding:5px;border-bottom:0px;">PHOTO</th>
							<th class="text-center" style="padding:5px;border-bottom:0px;">REFUND QTY</th>
							<th class="text-center" style="padding:5px;border-bottom:0px;">UNIT</th>
							<th class="text-center" style="padding:5px;border-bottom:0px;">UNIT PRICE</th>
							<th class="text-right" style="padding:5px;border-bottom:0px;">REFUND SUBTOTAL</th>
							<th class="text-right" style="padding:5px;border-bottom:0px;">REFUND CHARGE</th>
							<th class="text-right" style="padding:5px;border-bottom:0px;width:100px;">REFUND AMOUNT</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$content = '';
							$total_refund_charges = 0;
							$total_refund_amount = 0;
							$total_refund_subtotal = 0;
							$products = $this->Purchaserefund_model->get_refund_items($refund_info['refund_id']);
							if(is_array($products) && count($products) !== 0):
								$x = 1;
								foreach($products as $item)
								{
									$product_id = $item['refitem_product_id'];
									$product_info = $this->Purchaserefund_model->get_product_info($item['refitem_product_id']);
									if($product_info['product_type'] == 'GENERAL'){
										$photo_url = get_product_photo_dir($product_info['product_id']);
									}else{
										$photo_url = get_product_photo_dir($product_info['product_id'], 'DRUGS');
									}
									$purchase_has_variations = $product_info['product_has_variations'];
									if($purchase_has_variations == 'YES'){
										$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_option_id($item['refitem_order_id'], $item['refitem_product_id'], $item['refitem_variation_option_id']);
									}else{
										$purchase_item = $this->Purchaserefund_model->get_purchase_itemby_product_id($item['refitem_order_id'], $item['refitem_product_id']);
									}
									$product = array_merge($item, $purchase_item);
									if($x < 10){
										$sl = '0'.$x;
									}else{
										$sl = $x;
									}
									if($purchase_has_variations == 'YES'){
										$provariation_id = $product['oitem_provariation_id'];
										$variation_option_id = $product['oitem_variation_option_id'];
										$variant_name   = $this->Purchaserefund_model->get_variant_name($provariation_id);
										$option_name   = $this->Purchaserefund_model->get_option_name($variation_option_id);
										$variation_content = '<br style="margin-bottom:5px;" /> <strong>Description :</strong> '.$variant_name.' : '.$option_name;
										$variation_id = $this->Purchaserefund_model->get_variation_id($provariation_id, $item['refitem_product_id']);
										$quantity    = product_purchase_refundable_qty_by_variation($item['refitem_order_id'], $item['refitem_product_id'], $variation_id, $variation_option_id) + intval($product['refitem_refund_qty']);
									}else{
										$variation_content = '';
										$quantity    = product_purchase_refundable_qty($item['refitem_order_id'], $item['refitem_product_id']) + intval($product['refitem_refund_qty']);
									}
									$unit_id     = $product['oitem_unit_id'];
									$unit_name   = $this->Purchaserefund_model->get_unit_name($unit_id);
									$purchase_price = $product['oitem_purchase_per_qty'];
									$sale_price     = $product['oitem_sale_per_qty'];
									$profit_per_qty = $product['oitem_profit_per_qty'];
									$subtotal_amount = $product['oitem_subtotal'];
									
									$total_refund_charges += $product['refitem_refund_charge'];
									$total_refund_amount += $product['refitem_refund_amount'];
									$total_refund_subtotal += $product['refitem_refund_subtotal'];
									if($product_info['product_type'] == 'GENERAL'){
										$product_title = $product_info['product_name']; 
									}else{
										$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
										$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
									}
						?>
									<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
										<td style="padding:10px"><?php echo $sl; ?></td>
										<td style="padding:10px">
											<?php echo $product_title; ?>
											<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> <?php echo $product_info['product_serial_number']; ?>
											<?php echo $variation_content; ?>
										</td>
										<td style="padding:10px" class="text-center"><img src="<?php echo $photo_url; ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
										<td style="padding:10px" class="text-center"><?php echo number_format($product['refitem_refund_qty'], 0, '.', ','); ?></td>
										<td style="padding:10px" class="text-center"><?php echo $unit_name; ?></td>
										<td style="padding:10px" class="text-center text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($purchase_price, 0, '.', ','); ?> /-</td>
										<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($product['refitem_refund_subtotal'], 0, '.', ','); ?> /-</td>
										<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($product['refitem_refund_charge'], 0, '.', ','); ?> /-</td>
										<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($product['refitem_refund_amount'], 0, '.', ','); ?> /-</td>
									</tr>
						<?php
									$x++;
								}
							else: 
						?>
						<tr>
							<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="9">NO ITEMS FOUND</td>
						</tr>
						<?php endif; ?>
						<tr>
							<td style="padding:10px" colspan="6" class="text-right font-weight-bold">Total</td>
							<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($total_refund_subtotal, 0, '.', ','); ?> /-</td>
							<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($total_refund_charges, 0, '.', ','); ?> /-</td>
							<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong> <?php echo number_format($total_refund_amount, 0, '.', ','); ?> /-</td>
						</tr>
					</tbody>
				</table>
			</div>
			<!-- invoice subtotal -->
			<div class="card-body pt-0" style="padding: 0 5px 15px;">
				<table style="border:0;width:100%">
					<tr>
						<?php if($refund_info['refund_terms'] && $refund_info['refund_remarks']): ?>																
						<td style="border:0;width:30.33%">
							<div class="note-container">
								<p class="note-text-title"><strong>Terms</strong></p>
								<p><?php echo $refund_info['refund_terms']; ?></p>
							</div>
						</td>
						<td style="border:0;width:30.33%">
							<div class="note-container">
								<p class="note-text-title"><strong>Remarks</strong></p>
								<p><?php echo $refund_info['refund_remarks']; ?></p>
							</div>
						</td>
						<?php elseif($refund_info['refund_terms'] || $refund_info['refund_remarks']): ?>
						<td style="border:0;width:63.66%">
							<?php if($refund_info['refund_terms']): ?>
							<div class="note-container">
								<p class="note-text-title"><strong>Terms</strong></p>
								<p><?php echo $refund_info['refund_terms']; ?></p>
							</div>
							<?php elseif($refund_info['refund_remarks']): ?>
							<div class="note-container">
								<p class="note-text-title"><strong>Remarks</strong></p>
								<p><?php echo $refund_info['refund_remarks']; ?></p>
							</div>
							<?php endif; ?>
						</td>
						<?php else: ?>
						<td style="border:0;width:63.66%"></td>
						<?php endif; ?>
						
						<td style="border:0;width:36.33%">
							<table class="table table-bordered table-striped mb-0" style="width:100% !important;">
								<tbody>
									<tr style="background-color:#FAFBFB;">
										<td class="text-right" style="width:150px;">Refund Subtotal</td>
										<td class="text-right" style="width:150px;"><strong>TK</strong> <?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></td>
									</tr>
									<tr>
										<td class="text-right">Total Refund Charges</td>
										<td class="text-right" style="width:150px;"><strong>TK</strong> <?php echo number_format($refund_info['refund_charge_total'], 2, '.', ','); ?></td>
									</tr>
									<tr style="background-color:#FAFBFB;">
										<td class="text-primary text-right">Total Amount to be Refunded</td>
										<td class="text-primary text-right font-weight-bold" style="width:150px;"><strong>TK</strong> <?php echo number_format($refund_info['refund_amount_total'], 2, '.', ','); ?></td>
									</tr>
									<tr>
										<td class="text-right">Refund Net Total</td>
										<td class="text-right" style="width:150px;"><strong>TK</strong> <?php echo number_format($refund_info['refund_net_total'], 2, '.', ','); ?></td>
									</tr>
									<tr style="background-color:#FAFBFB;">
										<td class="text-right">Refund Net Profit</td>
										<td class="text-right" style="color:#0B0;width:150px;"><strong>TK</strong> <?php echo number_format($refund_info['refund_net_profit'], 2, '.', ','); ?></td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</table>
				<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($refund_info['refund_net_total']); ?>)</p>
				<div style="height:0;margin-top:1rem;margin-bottom:1rem;display:block; width:100%; border-top:1px solid #DFE3E7;border-style:dotted;"></div>
				<p class="text-center">Thanks for your business with us.</p>
			</div>
		</div>
	</div>
</body>
</html>