<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#">purchase order</a></li>
			<li class="breadcrumb-item active">view</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<section class="invoice-view-wrapper">
	<div class="row">
		<!-- invoice view page -->
		<div class="invoice-container">
			<div class="card invoice-print-area">
				<div class="card-content">
					<?php $company_info = get_company_info(); ?>
					<div class="card-body pb-0" style="padding:10px !important">
						<div class="text-right">
							<div class="invoice-action-btn">
								<a href="<?php echo base_url('purchase/payments/add?ref='.$purchase_info['supplier_formatted_id'].'&od='.$purchase_info['order_number'].'&oinv='.$purchase_info['invoice_number']); ?>" class="btn btn-dark"> <i class="bx bx-money"></i> <span>Add Payment</span> </a>
							</div>
							<div class="invoice-action-btn">
								<a href="<?php echo base_url('purchase/edit/'.$purchase_info['order_formatted_id']); ?>" class="btn btn-info"> <i class="bx bx-edit"></i> <span>Edit</span> </a>
							</div>
							<div class="invoice-action-btn">
								<button class="btn btn-primary invoice-send-btn" data-toggle="modal" data-target="#default"> <i class="bx bx-send"></i> <span>Send</span> </button>
							</div>
							<div class="invoice-action-btn">
								<a class="btn btn-success" href="<?php echo base_url('purchase/download/'.$purchase_info['order_formatted_id']); ?>"> <i class='bx bx-download'></i> <span>Download</span> </a>
							</div>
							<div class="invoice-action-btn">
								<button class="btn btn-info invoice-print" onclick="documentPrint()"><i class="bx bx-printer"></i> <span>print</span> </button>
							</div>
						</div>
						<!-- header section -->
						<div class="row">
							<div class="col-md-4">
								<div class="invoice-company-logo"><img src="<?php echo get_company_logo_url(); ?>" alt="Company Logo" /></div>
							</div>
							<div class="col-md-4">
								<span class="invoice-label-txt">INVOICE</span>
							</div>
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2><?php echo $company_info['company_name']; ?></h2>
									<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
									<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
									<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
									<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
								</div>
							</div>
						</div>
					</div>
					<div class="card-body pb-0" style="padding: 10px;margin-bottom: 25px;">
						<div class="row">
							<div class="col-md-6">
								<div class="invoice-company-info invoice-customer-info">
									<h2>INVOICE TO</h2>
									<p><strong><?php echo $purchase_info['supplier_name']; ?></strong></p>
									<p><strong>Cell No : </strong> <?php echo $purchase_info['supplier_telephone_number']; ?></p>
									<p><strong>Address : </strong> <?php echo $purchase_info['supplier_address']; ?></p>
								</div>
							</div>
							<div class="col-md-2"></div>
							<div class="col-md-4">
								<div class="invoice-company-info invoice-salesman-info">
									<p><strong>Invoice No : </strong> <?php echo $purchase_info['invoice_number']; ?></p>
									<p><strong>Invoice Date : </strong> <?php echo date("d F, Y", strtotime($purchase_info['invoice_date'])); ?></p>
									<p><strong>Due Date / Sales Date : </strong> <?php echo date("d F, Y", strtotime($purchase_info['order_date'])); ?></p>
									<p><strong>Sale Representitive : </strong> Erfan Khan</p>
									<p><strong>Prepared By : </strong> <?php echo $purchase_info['admin_full_name']; ?></p>
									<?php if($purchase_info['order_reference_type'] == 'ENQUIRY' && $purchase_info['order_reference_no']): ?>
									<p><strong>Enquiry No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
									<?php elseif($purchase_info['order_reference_type'] == 'REFERENCE' && $purchase_info['order_reference_no']): ?>
									<p><strong>Reference No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
									<?php elseif($purchase_info['order_reference_type'] == 'QUOTATION' && $purchase_info['order_reference_no']): ?>
									<p><strong>Quotation No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
									<?php else: ?>
									
									<?php endif; ?>
									<p><strong>Branch : </strong> <?php echo $purchase_info['branch_name']; ?></p>
								</div>
							</div>
						</div>
					</div>
					
					<!-- invoice address and contact -->
					<hr>
					<!-- product details table-->
					<div class="invoice-product-details table-responsive">
						<h3 class="invoice-items-title">INVOICE ITEM DETAILS</h3>
						<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
							<thead>
								<tr class="border-0">
									<th style="width:5%">S.No</th>
									<th style="width:30%">PRODUCT</th>
									<th class="text-center">PHOTO</th>
									<th class="text-center">QTY</th>
									<th class="text-center">UNIT</th>
									<th class="text-center">PURCHASE PRICE / QTY</th>
									<th class="text-center">SALE PRICE / QTY</th>
									<th class="text-center">PROFIT / QTY</th>
									<th class="text-right" style="width:100px;">AMOUNT</th>
								  </tr>
							</thead>
							<tbody>
								<?php 
									$content = '';
									$products = $this->Purchase_model->get_order_items($purchase_info['order_id']);
									if(is_array($products) && count($products) !== 0):
										$x = 1;
										foreach($products as $product)
										{
											$product_id = $product['oitem_product_id'];
											$product_info = $this->Purchase_model->get_product_info($product['oitem_product_id']);
											if($product_info['product_type'] == 'GENERAL'){
												$photo_url = get_product_photo_url($product_info['product_id']);
											}else{
												$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
											}
											$purchase_has_variations = $product_info['product_has_variations'];
											if($x < 10){
												$sl = '0'.$x;
											}else{
												$sl = $x;
											}
											if($purchase_has_variations == 'YES'){
												$provariation_id = $product['oitem_provariation_id'];
												$variation_option_id = $product['oitem_variation_option_id'];
												$variant_name   = $this->Purchase_model->get_variant_name($provariation_id);
												$option_name   = $this->Purchase_model->get_option_name($variation_option_id);
												$variation_content = '<br /> <strong>Description :</strong> '.$variant_name.' : '.$option_name;
											}else{
												$variation_content = '';
											}
											$quantity    = $product['oitem_quantity'];
											$unit_id     = $product['oitem_unit_id'];
											$unit_name   = $this->Purchase_model->get_unit_name($unit_id);
											$purchase_price = $product['oitem_purchase_per_qty'];
											$sale_price     = $product['oitem_sale_per_qty'];
											$profit_per_qty = $product['oitem_profit_per_qty'];
											$subtotal_amount = $product['oitem_subtotal'];
											if($product_info['product_type'] == 'GENERAL'){
												$product_title = $product_info['product_name']; 
											}else{
												$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
												$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
											}
											$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
															<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
															<td>
																'.$product_title.'
																<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
																'.$variation_content.'
															</td>
															<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
															<td class="text-center">
																'.$quantity.'
															</td>
															<td class="text-center">
																'.$unit_name.'
															</td>
															<td class="text-center"><strong>&#2547;</strong>
																'.number_format($purchase_price, 0, '.', ',').'
															</td>
															<td class="text-center"><strong>&#2547;</strong>
																'.number_format($sale_price, 0, '.', ',').'
															</td>
															<td class="text-center"><strong>&#2547;</strong>
																'.number_format($profit_per_qty, 0, '.', ',').'
															</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong>
																'.number_format($subtotal_amount, 0, '.', ',').'
															</td>
														</tr>';
											$x++;
										}
										echo $content;
									else: 
								?>
								<tr>
									<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="9">NO PRODUCT FOUND</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<!-- invoice subtotal -->
					<div class="card-body pt-0" style="padding: 0 10px 15px;">
						<div class="row">
							<?php if($purchase_info['order_terms'] && $purchase_info['order_remarks']): ?>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Terms</strong></p>
									<p><?php echo $purchase_info['order_terms']; ?></p>
								</div>
							</div>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Remarks</strong></p>
									<p><?php echo $purchase_info['order_remarks']; ?></p>
								</div>
							</div>
							<?php elseif($purchase_info['order_terms'] || $purchase_info['order_remarks']): ?>
								<div class="col-8 col-sm-8 mt-75">
									<?php if($purchase_info['order_terms']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Terms</strong></p>
										<p><?php echo $purchase_info['order_terms']; ?></p>
									</div>
									<?php elseif($purchase_info['order_remarks']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Remarks</strong></p>
										<p><?php echo $purchase_info['order_remarks']; ?></p>
									</div>
									<?php endif; ?>
								</div>
							<?php else: ?>
							<div class="col-8 col-sm-8 mt-75"></div>
							<?php endif; ?>
							<div class="col-4 col-sm-4 d-flex justify-content-end mt-75">
								<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
									<tbody>
										<tr>
											<td class="text-right">Subtotal</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_subtotal'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Shipping & Packaging Cost</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_shipping_cost'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Vat <span id="showVatPercent" style="font-size:10px;color:#a00"><?php echo ($purchase_info['osummery_vat_type'] == 'PERCENT' && $purchase_info['osummery_vat_value'])? '('.number_format($purchase_info['osummery_vat_value'], 0, '', ',').'% of Subtotal Amount)' : null; ?></span></td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_vat_amount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Tax <span id="showTaxPercent" style="font-size:10px;color:#a00"><?php echo ($purchase_info['osummery_tax_type'] == 'PERCENT' && $purchase_info['osummery_tax_value'])? '('.number_format($purchase_info['osummery_tax_value'], 0, '', ',').'% of Subtotal Amount)' : null; ?></span></td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_tax_amount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Total Amount</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_total_amount'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Discount</td>
											<td class="text-right" style="color:#F00;width:150px;"><strong>&#2547;</strong> - <?php echo number_format($purchase_info['osummery_discount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Net Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_net_total'], 2, '.', ','); ?></td>
										</tr>
										<tr style="color:#0a0">
											<td class="text-right">Paid Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format(floatval($purchase_info['due_paid_total']), 2, '.', ','); ?></td>
										</tr>
										<tr style="color:#b00">
											<td class="text-right">Due Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format(floatval($purchase_info['due_amount_total']), 2, '.', ','); ?></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($purchase_info['osummery_net_total']); ?>)</p>
						<hr />
						<p class="text-center">Thanks for your business with us.</p>
					</div>
				</div>
			</div>
		</div>
		
		<div class="invoice-container" id="printCopy" style="display:none">
			<div class="card invoice-print-area">
				<div class="card-content">
					<div class="card-body pb-0" style="padding:10px !important">
						<!-- header section -->
						<div class="row">
							<div class="col-md-4">
								<div class="invoice-company-logo"><img src="<?php echo get_company_logo_url(); ?>" alt="Company Logo" /></div>
							</div>
							<div class="col-md-4">
								<span class="invoice-label-txt">INVOICE</span>
							</div>
							<div class="col-md-4">
								<div class="invoice-company-info">
									<h2><?php echo $company_info['company_name']; ?></h2>
									<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
									<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
									<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
									<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
								</div>
							</div>
						</div>
					</div>
					<div class="card-body pb-0" style="padding: 10px;margin-bottom: 25px;">
						<div class="row">
							<div class="col-md-6">
								<div class="invoice-company-info invoice-customer-info">
									<h2>INVOICE TO</h2>
									<p><strong><?php echo $purchase_info['supplier_name']; ?></strong></p>
									<p><strong>Cell No : </strong> <?php echo $purchase_info['supplier_telephone_number']; ?></p>
									<p><strong>Address : </strong> <?php echo $purchase_info['supplier_address']; ?></p>
								</div>
							</div>
							<div class="col-md-2"></div>
							<div class="col-md-4">
								<div class="invoice-company-info invoice-salesman-info">
									<p><strong>Invoice No : </strong> <?php echo $purchase_info['invoice_number']; ?></p>
									<p><strong>Invoice Date : </strong> <?php echo date("d F, Y", strtotime($purchase_info['invoice_date'])); ?></p>
									<p><strong>Due Date / Sales Date : </strong> <?php echo date("d F, Y", strtotime($purchase_info['order_date'])); ?></p>
									<p><strong>Sale Representitive : </strong> Erfan Khan</p>
									<p><strong>Prepared By : </strong> <?php echo $purchase_info['admin_full_name']; ?></p>
									<?php if($purchase_info['order_reference_type'] == 'ENQUIRY' && $purchase_info['order_reference_no']): ?>
									<p><strong>Enquiry No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
									<?php elseif($purchase_info['order_reference_type'] == 'REFERENCE' && $purchase_info['order_reference_no']): ?>
									<p><strong>Reference No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
									<?php elseif($purchase_info['order_reference_type'] == 'QUOTATION' && $purchase_info['order_reference_no']): ?>
									<p><strong>Quotation No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
									<?php else: ?>
									<?php endif; ?>
									<p><strong>Branch : </strong> <?php echo $purchase_info['branch_name']; ?></p>
								</div>
							</div>
						</div>
					</div>
					
					<!-- invoice address and contact -->
					<hr>
					<!-- product details table-->
					<div class="invoice-product-details table-responsive">
						<h3 class="invoice-items-title">INVOICE ITEM DETAILS</h3>
						<table class="table table-bordered table-striped mb-0" style="width:98% !important;margin:0 auto;">
							<thead>
								<tr class="border-0">
									<th style="width:5%">S.No</th>
									<th style="width:30%">PRODUCT</th>
									<th class="text-center">PHOTO</th>
									<th class="text-center">QTY</th>
									<th class="text-center">UNIT</th>
									<th class="text-center">PURCHASE PRICE / QTY</th>
									<th class="text-center">SALE PRICE / QTY</th>
									<th class="text-center">PROFIT / QTY</th>
									<th class="text-right" style="width:100px;">AMOUNT</th>
								  </tr>
							</thead>
							<tbody>
								<?php 
									$content = '';
									$products = $this->Purchase_model->get_order_items($purchase_info['order_id']);
									if(is_array($products) && count($products) !== 0):
										$x = 1;
										foreach($products as $product)
										{
											$product_id = $product['oitem_product_id'];
											$product_info = $this->Purchase_model->get_product_info($product['oitem_product_id']);
											$photo_url = $this->Purchase_model->get_product_photo_url($product_info['product_id']);
											$purchase_has_variations = $product_info['product_has_variations'];
											if($x < 10){
												$sl = '0'.$x;
											}else{
												$sl = $x;
											}
											if($purchase_has_variations == 'YES'){
												$provariation_id = $product['oitem_provariation_id'];
												$variation_option_id = $product['oitem_variation_option_id'];
												$variant_name   = $this->Purchase_model->get_variant_name($provariation_id);
												$option_name   = $this->Purchase_model->get_option_name($variation_option_id);
												$variation_content = '<br /> <strong>Description :</strong> '.$variant_name.' : '.$option_name;
											}else{
												$variation_content = '';
											}
											$quantity    = $product['oitem_quantity'];
											$unit_id     = $product['oitem_unit_id'];
											$unit_name   = $this->Purchase_model->get_unit_name($unit_id);
											$purchase_price = $product['oitem_purchase_per_qty'];
											$sale_price     = $product['oitem_sale_per_qty'];
											$profit_per_qty = $product['oitem_profit_per_qty'];
											$subtotal_amount = $product['oitem_subtotal'];
											$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
															<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
															<td>
																'.$product_info['product_name'].'
																<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
																'.$variation_content.'
															</td>
															<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
															<td class="text-center">
																'.$quantity.'
															</td>
															<td class="text-center">
																'.$unit_name.'
															</td>
															<td class="text-center"><strong>&#2547;</strong>
																'.number_format($purchase_price, 0, '.', ',').'
															</td>
															<td class="text-center"><strong>&#2547;</strong>
																'.number_format($sale_price, 0, '.', ',').'
															</td>
															<td class="text-center"><strong>&#2547;</strong>
																'.number_format($profit_per_qty, 0, '.', ',').'
															</td>
															<td class="text-primary text-right font-weight-bold"><strong>&#2547;</strong>
																'.number_format($subtotal_amount, 0, '.', ',').'
															</td>
														</tr>';
											$x++;
										}
										echo $content;
									else: 
								?>
								<tr>
									<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="9">NO PRODUCT FOUND</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<!-- invoice subtotal -->
					<div class="card-body pt-0" style="padding: 0 10px 15px;">
						<div class="row">
							<?php if($purchase_info['order_terms'] && $purchase_info['order_remarks']): ?>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Terms</strong></p>
									<p><?php echo $purchase_info['order_terms']; ?></p>
								</div>
							</div>
							<div class="col-4 col-sm-4 mt-75">
								<div class="note-container">
									<p class="note-text-title"><strong>Remarks</strong></p>
									<p><?php echo $purchase_info['order_remarks']; ?></p>
								</div>
							</div>
							<?php elseif($purchase_info['order_terms'] || $purchase_info['order_remarks']): ?>
								<div class="col-8 col-sm-8 mt-75">
									<?php if($purchase_info['order_terms']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Terms</strong></p>
										<p><?php echo $purchase_info['order_terms']; ?></p>
									</div>
									<?php elseif($purchase_info['order_remarks']): ?>
									<div class="note-container">
										<p class="note-text-title"><strong>Remarks</strong></p>
										<p><?php echo $purchase_info['order_remarks']; ?></p>
									</div>
									<?php endif; ?>
								</div>
							<?php else: ?>
							<div class="col-8 col-sm-8 mt-75"></div>
							<?php endif; ?>
							<div class="col-4 col-sm-4 d-flex justify-content-end mt-75">
								<table class="table table-bordered table-striped mb-0" style="width:100% !important;margin:0 auto;">
									<tbody>
										<tr>
											<td class="text-right">Subtotal</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_subtotal'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Shipping & Packaging Cost</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_shipping_cost'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Vat <span id="showVatPercent" style="font-size:10px;color:#a00"><?php echo ($purchase_info['osummery_vat_type'] == 'PERCENT' && $purchase_info['osummery_vat_value'])? '('.number_format($purchase_info['osummery_vat_value'], 0, '', ',').'% of Subtotal Amount)' : null; ?></span></td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_vat_amount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Tax <span id="showTaxPercent" style="font-size:10px;color:#a00"><?php echo ($purchase_info['osummery_tax_type'] == 'PERCENT' && $purchase_info['osummery_tax_value'])? '('.number_format($purchase_info['osummery_tax_value'], 0, '', ',').'% of Subtotal Amount)' : null; ?></span></td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_tax_amount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Total Amount</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_total_amount'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Discount</td>
											<td class="text-right" style="color:#F00;width:150px;"><strong>&#2547;</strong> - <?php echo number_format($purchase_info['osummery_discount_total'], 2, '.', ','); ?></td>
										</tr>
										<tr>
											<td class="text-right">Net Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format($purchase_info['osummery_net_total'], 2, '.', ','); ?></td>
										</tr>
										<tr style="color:#0a0">
											<td class="text-right">Paid Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format(floatval($purchase_info['due_paid_total']), 2, '.', ','); ?></td>
										</tr>
										<tr style="color:#b00">
											<td class="text-right">Due Total</td>
											<td class="text-right" style="width:150px;"><strong>&#2547;</strong> <?php echo number_format(floatval($purchase_info['due_amount_total']), 2, '.', ','); ?></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($purchase_info['osummery_net_total']); ?>)</p>
						<hr />
						<p class="text-center">Thanks for your business with us.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="modal fade text-left" id="default" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
<?php  
	$attr = array('id' => 'sendInvoice', 'class' => '');
	echo form_open('', $attr);
?>
  <div class="modal-dialog modal-dialog-scrollable" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h3 class="modal-title" id="myModalLabel1">SEND INVOICE TO YOUR FRIENDS</h3>
	  </div>
	  <div class="modal-body">
		<input type="hidden" name="formatted_id" value="<?php echo $purchase_info['order_formatted_id']; ?>" />
		<div id="modalFormProccess" class="text-center" style="display:none;"><span>.....please wait.....</span></div>
		<div id="alert"></div>
		<fieldset class="form-group">
			<label>EMAIL ADDRESS <span class="mendatory">*</span></label>
			<input type="text" name="email" class="form-control" placeholder="Enter email address">
		</fieldset>
		<fieldset class="form-group">
			<label>SAY SOMETHING </label>
			<textarea name="note" class="form-control" cols="30" rows="5"></textarea>
		</fieldset>
	  </div>
	  <div class="modal-footer">
		<span style="cursor:pointer" class="btn btn-light-secondary" data-dismiss="modal">
		  <i class="bx bx-x d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Cancel</span>
		</span>
		<button type="submit" class="btn btn-primary ml-1">
		  <i class="bx bx-check d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Send</span>
		</button>
	  </div>
	</div>
  </div>
<?php echo form_close(); ?>
</div>
<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#sendInvoice").validate({
			rules:{
				email:{
					required: true,
					email:true,
				},
			},
			submitHandler : function () {
				$('#modalFormProccess').show();
				// your function if, validate is success
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/send",
					data : $('#sendInvoice').serialize(),
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							document.getElementById("sendInvoice").reset();
							$("#alert").html(data.alert);
							$('#modalFormProccess').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							return false;
						}else if(data.status == "error")
						{
							$('#modalFormProccess').hide();
							$("#alert").html(data.alert);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	function documentPrint() 
	{
	  var documentContent=document.getElementById('printCopy');
	  var newWin=window.open('','Print-Window');
	  var content = '<!DOCTYPE html>'+
					'<html class="loading" lang="en" data-textdirection="ltr">'+
					'<head>'+
						'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'+
						'<meta http-equiv="X-UA-Compatible" content="IE=edge">'+
						'<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">'+
						'<title>Print Copy</title>'+
						'<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('backend/app-assets/images/ico/favicon.ico'); ?>">'+
						'<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/pages/app-invoice.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap-extended.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/colors.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/components.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/dark-layout.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/semi-dark-layout.min.css'); ?>">'+
						'<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/assets/css/style.css'); ?>">'+
					'</head>'+
					'<body onload="window.print()">'+documentContent.innerHTML+'</body></html>';

	  newWin.document.open();
	  newWin.document.write(content);
	  newWin.document.close();
	  setTimeout(function(){newWin.close();},10);
	}
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>