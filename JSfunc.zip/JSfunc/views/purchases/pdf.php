<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>PURCHASE DETAILS</title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('backend/app-assets/images/ico/favicon.ico'); ?>">
	<link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/pages/app-invoice.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap.pdf.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/bootstrap-extended.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/colors.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/components.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/dark-layout.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/app-assets/css/themes/semi-dark-layout.min.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('backend/assets/css/style.css'); ?>">
	<style type="text/css">
		body {
			margin: 0;
			font-size: 12px;
			color: #727E8C;
			background-color: #F2F4F4;
			line-height:18px;
		}
		p{color: #555;}
		th{
			color:#475F7B !important;
			font-size:11px !important;
			letter-spacing:1px !important;
			padding:5px !important;
		}
		th, td{padding:5px !important;border:1px solid #d5d5d5;}
		.table td, .table th {
			/* padding: 1.15rem 2rem; */
			/* border-top: 1px solid #DFE3E7; */
			padding: 10px !important;
			border-top: 0 !important;
			font-size: 11px !important;
		}
		strong{color: #4A4A4A;font-weight:bold}
		.table-striped tbody tr:nth-of-type(odd) {
			background-color: #FAFBFB;
		}
	</style>
</head>

<body>
	<?php $company_info = get_company_info(); ?>
	<div class="">
		<div class="">
			<table class="table table-bordered table-striped" style="border:0;width:100%">
				<tr>
					<td style="border:0;width:33.33%"><div class="invoice-company-logo"><img src="<?php echo get_company_logo_url(true); ?>" alt="Company Logo" /></div></td>
					<td style="border:0;width:33.33%"><span class="invoice-label-txt">INVOICE</span></td>
					<td style="border:0;width:33.33%">
						<div class="invoice-company-info">
							<h2><?php echo $company_info['company_name']; ?></h2>
							<p class="address"><strong>Address : </strong><?php echo $company_info['company_address']; ?></p>
							<p><strong>Phone : </strong> <?php echo $company_info['company_telephone_number']; ?></p>
							<p><strong>Email Address : </strong> <?php echo $company_info['company_email_address']; ?></p>
							<p><strong>Website : </strong> <?php echo $company_info['company_website_address']; ?></p>
						</div>
					</td>
				</tr>
				<tr>
					<td style="border:0;width:50%">
						<div class="invoice-company-info invoice-customer-info">
							<h2>INVOICE TO</h2>
							<p><strong><?php echo $purchase_info['supplier_name']; ?></strong></p>
							<p><strong>Cell No : </strong> <?php echo $purchase_info['supplier_telephone_number']; ?></p>
							<p><strong>Address : </strong> <?php echo $purchase_info['supplier_address']; ?></p>
						</div>
					</td>
					<td style="border:0;width:16.66%"></td>
					<td style="border:0;width:33.33%">
						<div class="invoice-company-info invoice-salesman-info">
							<p><strong>Invoice No : </strong> <?php echo $purchase_info['invoice_number']; ?></p>
							<p><strong>Invoice Date : </strong> <?php echo date("d F, Y", strtotime($purchase_info['invoice_date'])); ?></p>
							<p><strong>Due Date / Sales Date : </strong> <?php echo date("d F, Y", strtotime($purchase_info['order_date'])); ?></p>
							<p><strong>Sale Representitive : </strong> Erfan Khan</p>
							<p><strong>Prepared By : </strong> <?php echo $purchase_info['admin_full_name']; ?></p>
							<?php if($purchase_info['order_reference_type'] == 'ENQUIRY' && $purchase_info['order_reference_no']): ?>
							<p><strong>Enquiry No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
							<?php elseif($purchase_info['order_reference_type'] == 'REFERENCE' && $purchase_info['order_reference_no']): ?>
							<p><strong>Reference No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
							<?php elseif($purchase_info['order_reference_type'] == 'QUOTATION' && $purchase_info['order_reference_no']): ?>
							<p><strong>Quotation No : </strong> <?php echo $purchase_info['order_reference_no']; ?></p>
							<?php else: ?>
							<?php endif; ?>
							<p><strong>Branch : </strong> <?php echo $purchase_info['branch_name']; ?></p>
						</div>
					</td>
				</tr>
			</table>
			
			<!-- invoice address and contact -->
			<div style="height:0;margin-top:1rem;margin-bottom:1rem;display:block; width:100%; border-top:1px solid #DFE3E7;border-style:dotted;"></div>
			<div class="card-body pt-0" style="padding: 0 10px 15px;">
				<h3 class="invoice-items-title">INVOICE ITEM DETAILS</h3>
				<table class="table table-bordered table-striped" style="border:0;width:100%">
					<thead class="items-thead">
						<tr>
							<th style="padding:5px;border-bottom:0px;" class="th-clss">S.No</th>
							<th style="padding:5px;border-bottom:0px;">PRODUCT</th>
							<th style="padding:5px;border-bottom:0px;" class="text-center">PHOTO</th>
							<th style="padding:5px;border-bottom:0px;" class="text-center">QTY</th>
							<th style="padding:5px;border-bottom:0px;" class="text-center">UNIT</th>
							<th style="padding:5px;border-bottom:0px;" class="text-center">PURCHASE PRICE / QTY</th>
							<th style="padding:5px;border-bottom:0px;" class="text-center">SALE PRICE / QTY</th>
							<th style="padding:5px;border-bottom:0px;" class="text-center">PROFIT / QTY</th>
							<th style="padding:5px;border-bottom:0px;width:100px;" class="text-right">AMOUNT</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$content = '';
							$products = $this->Purchase_model->get_order_items($purchase_info['order_id']);
							if(is_array($products) && count($products) !== 0):
								$x = 1;
								foreach($products as $product)
								{
									$product_id = $product['oitem_product_id'];
									$product_info = $this->Purchase_model->get_product_info($product['oitem_product_id']);
									if($product_info['product_type'] == 'GENERAL'){
										$photo_url = get_product_photo_dir($product_info['product_id']);
									}else{
										$photo_url = get_product_photo_dir($product_info['product_id'], 'DRUGS');
									}
									$purchase_has_variations = $product_info['product_has_variations'];
									if($x < 10){
										$sl = '0'.$x;
									}else{
										$sl = $x;
									}
									if($purchase_has_variations == 'YES'){
										$provariation_id = $product['oitem_provariation_id'];
										$variation_option_id = $product['oitem_variation_option_id'];
										$variant_name   = $this->Purchase_model->get_variant_name($provariation_id);
										$option_name   = $this->Purchase_model->get_option_name($variation_option_id);
										$variation_content = '<br /> <strong>Description :</strong> '.$variant_name.' : '.$option_name;
									}else{
										$variation_content = '';
									}
									$quantity    = $product['oitem_quantity'];
									$unit_id     = $product['oitem_unit_id'];
									$unit_name   = $this->Purchase_model->get_unit_name($unit_id);
									$purchase_price = $product['oitem_purchase_per_qty'];
									$sale_price     = $product['oitem_sale_per_qty'];
									$profit_per_qty = $product['oitem_profit_per_qty'];
									$subtotal_amount = $product['oitem_subtotal'];
									if($product_info['product_type'] == 'GENERAL'){
										$product_title = $product_info['product_name']; 
									}else{
										$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
										$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
									}
						?>
									<tr style="<?php echo ($x % 2 !== 0)? 'background-color:#FAFBFB;' : null; ?>">
										<td style="padding:10px"><?php echo $sl; ?></td>
										<td style="padding:10px">
											<p style="font-size:11px;line-height:18px;color:#555">
												<?php echo $product_title; ?>
												<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> <?php echo $product_info['product_serial_number']; ?>
												<?php echo $variation_content; ?>
											</p>
										</td>
										<td style="padding:10px" class="text-center"><img src="<?php echo $photo_url; ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
										<td style="padding:10px" class="text-center">
											<?php echo $quantity; ?>
										</td>
										<td style="padding:10px" class="text-center">
											<?php echo $unit_name; ?>
										</td>
										<td style="padding:10px" class="text-center"><strong>TK</strong>
											<?php echo number_format($purchase_price, 0, '.', ','); ?>
										</td>
										<td style="padding:10px" class="text-center"><strong>TK</strong>
											<?php echo number_format($sale_price, 0, '.', ','); ?>
										</td>
										<td style="padding:10px" class="text-center"><strong>TK</strong>
											<?php echo number_format($profit_per_qty, 0, '.', ','); ?>
										</td>
										<td style="padding:10px" class="text-primary text-right font-weight-bold"><strong>TK</strong>
											<?php echo number_format($subtotal_amount, 0, '.', ','); ?>
										</td>
									</tr>
								
						<?php							
								$x++;
								}
							else: 
						?>
						<tr>
							<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="9">NO PRODUCT FOUND</td>
						</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<!-- invoice subtotal -->
			<div class="card-body pt-0" style="padding: 0 5px 15px;">
				<table style="border:0;width:100%">
					<tr>
						<?php if($purchase_info['order_terms'] && $purchase_info['order_remarks']): ?>																
						<td style="border:0;width:30.33%">
							<div class="note-container">
								<p class="note-text-title"><strong>Terms</strong></p>
								<p><?php echo $purchase_info['order_terms']; ?></p>
							</div>
						</td>
						<td style="border:0;width:30.33%">
							<div class="note-container">
								<p class="note-text-title"><strong>Remarks</strong></p>
								<p><?php echo $purchase_info['order_remarks']; ?></p>
							</div>
						</td>
						<?php elseif($purchase_info['order_terms'] || $purchase_info['order_remarks']): ?>
						<td style="border:0;width:63.66%">
							<?php if($purchase_info['order_terms']): ?>
							<div class="note-container">
								<p class="note-text-title"><strong>Terms</strong></p>
								<p><?php echo $purchase_info['order_terms']; ?></p>
							</div>
							<?php elseif($purchase_info['order_remarks']): ?>
							<div class="note-container">
								<p class="note-text-title"><strong>Remarks</strong></p>
								<p><?php echo $purchase_info['order_remarks']; ?></p>
							</div>
							<?php endif; ?>
						</td>
						<?php else: ?>
						<td style="border:0;width:63.66%"></td>
						<?php endif; ?>
						
						<td style="border:0;width:36.33%">
							<table class="table table-bordered table-striped mb-0" style="width:100% !important;">
								<tbody>
									<tr style="background-color:#FAFBFB;">
										<td class="text-right" style="width:140px;">Subtotal</td>
										<td class="text-right" style="width:140px;"><strong>TK</strong> <?php echo number_format($purchase_info['osummery_subtotal'], 2, '.', ','); ?></td>
									</tr>
									<tr>
										<td class="text-right">Shipping & Packaging Cost</td>
										<td class="text-right" style="width:140px;"><strong>TK</strong> <?php echo number_format($purchase_info['osummery_shipping_cost'], 2, '.', ','); ?></td>
									</tr>
									<tr style="background-color:#FAFBFB;">
										<td class="text-right">Vat <span style="font-size:10px;color:#a00"><?php echo ($purchase_info['osummery_vat_type'] == 'PERCENT' && $purchase_info['osummery_vat_value'])? '('.number_format($purchase_info['osummery_vat_value'], 0, '', ',').'% of Subtotal Amount)' : null; ?></span></td>
										<td class="text-right" style="width:140px;"><strong>TK</strong> <?php echo number_format($purchase_info['osummery_vat_amount_total'], 2, '.', ','); ?></td>
									</tr>
									<tr>
										<td class="text-right">Tax <span style="font-size:10px;color:#a00"><?php echo ($purchase_info['osummery_tax_type'] == 'PERCENT' && $purchase_info['osummery_tax_value'])? '('.number_format($purchase_info['osummery_tax_value'], 0, '', ',').'% of Subtotal Amount)' : null; ?></span></td>
										<td class="text-right" style="width:140px;"><strong>TK</strong> <?php echo number_format($purchase_info['osummery_tax_amount_total'], 2, '.', ','); ?></td>
									</tr>
									<tr style="background-color:#FAFBFB;">
										<td class="text-right">Total Amount</td>
										<td class="text-right" style="width:140px;"><strong>TK</strong> <?php echo number_format($purchase_info['osummery_total_amount'], 2, '.', ','); ?></td>
									</tr>
									<tr>
										<td class="text-right">Discount</td>
										<td class="text-right" style="color:#F00;width:140px;"><strong>TK</strong> - <?php echo number_format($purchase_info['osummery_discount_total'], 2, '.', ','); ?></td>
									</tr>
									<tr style="background-color:#FAFBFB;">
										<td class="text-right">Net Total</td>
										<td class="text-right" style="width:140px;"><strong>TK</strong> <?php echo number_format($purchase_info['osummery_net_total'], 2, '.', ','); ?></td>
									</tr>
									<tr style="color:#0a0">
											<td class="text-right">Paid Total</td>
											<td class="text-right" style="width:150px;"><strong>TK</strong> <?php echo number_format(floatval($purchase_info['due_paid_total']), 2, '.', ','); ?></td>
										</tr>
										<tr style="color:#b00">
											<td class="text-right">Due Total</td>
											<td class="text-right" style="width:150px;"><strong>TK</strong> <?php echo number_format(floatval($purchase_info['due_amount_total']), 2, '.', ','); ?></td>
										</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</table>
				<p class="text-center in-word-amount"><strong>In Word : </strong>(<?php echo convertToBdCurrency($purchase_info['osummery_net_total']); ?>)</p>
				<div style="height:0;margin-top:1rem;margin-bottom:1rem;display:block; width:100%; border-top:1px solid #DFE3E7;border-style:dotted;"></div>
				<p class="text-center">Thanks for your business with us.</p>
			</div>
		</div>
	</div>
</body>
</html>