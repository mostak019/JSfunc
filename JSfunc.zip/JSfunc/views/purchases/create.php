<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="content-header row">
  <div class="content-header-left col-12 mb-2 mt-1">
	<div class="row breadcrumbs-top">
	  <div class="col-12">
		<div class="breadcrumb-wrapper col-12">
		  <ol class="breadcrumb p-0 mb-0">
			<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard'); ?>"><i class="bx bx-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#">purchase order</a></li>
			<li class="breadcrumb-item active">create</li>
		  </ol>
		</div>
	  </div>
	</div>
  </div>
</div>

<!-- Basic Inputs start -->
<section id="basic-input" class="set-position-relative">
  <div id="createProgressLoader"><span>.....PLEASE WAIT.....</span></div>
  <?php  
		$attr = array('id' => 'createForm', 'class' => '');
		echo form_open('', $attr);
  ?>
  <div class="row" style="padding: 0 3px;">
	<div class="col-md-15"></div>
	<div class="col-md-15 text-right" style="width:32%"><label style="padding-top: 9px;display: block;">BRANCH <span class="mendatory">*</span></label></div>
	<div class="col-md-15">
		<fieldset class="form-group">
			<select name="branch" class="custom-select" id="onChangeBranch">
				<option value="">Select Branch</option>
				<?php 
					$branchs = $this->Purchase_model->get_all_branchs();
					foreach($branchs as $branch):
				?>
				<option value="<?php echo $branch['branch_id']; ?>"><?php echo $branch['branch_name']; ?></option>
				<?php endforeach; ?>
			</select>
		</fieldset>
	</div>
	<div class="col-md-15 text-right" style="width:8%"><label style="padding-top: 9px;display: block;">WAREHOUSE <span class="mendatory">*</span></label></div>
	<div class="col-md-15">
		<fieldset class="form-group">
			<select name="warehouse" class="custom-select" id="warehouseContent">
				<option value="">Select Warehouse</option>
			</select>
		</fieldset>
	</div>
  </div>
  <div class="row">
    <div class="col-md-12">
		<div id="alert"></div>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Purchase Order Information</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <div class="row">
						<?php
							$invoice_ID = $this->Purchase_model->get_last_invoice_id();
							$order_ID = $this->Purchase_model->get_last_order_id();
							$padding_number = str_pad($invoice_ID, 6, '0', STR_PAD_LEFT);
							$invoice_no = date("ynj").$padding_number;
							$po_no      = date("ymd").$order_ID;
						?>
                        <div class="col-md-15">
                            <fieldset class="form-group">
                                <label>Invoice NO</label>
                                <input type="text" class="form-control" value="<?php echo $invoice_no; ?>" disabled />
                            </fieldset>
                        </div>
						<div class="col-md-15">
                            <fieldset class="form-group">
                                <label>P.O NO</label>
                                <input type="text" class="form-control" value="<?php echo $po_no; ?>" disabled />
                            </fieldset>
                        </div>
						<div class="col-md-15">
							<fieldset class="form-group position-relative has-icon-left">
								<label>Invoice Date <span class="mendatory">*</span></label>
								<input type="text" name="invoice_date" value="<?php echo date("d F, Y"); ?>" class="form-control pickadate-months-year" placeholder="Select Date">
								<div class="form-control-position dpicker-icon-position">
									<i class='bx bx-calendar'></i>
								</div>
							</fieldset>
                        </div>
						<div class="col-md-15">
							<fieldset class="form-group position-relative has-icon-left">
								<label>Due Date / Sales Date <span class="mendatory">*</span></label>
								<input type="text" name="order_date" value="<?php echo date("d F, Y"); ?>" class="form-control pickadate-months-year" placeholder="Select Date">
								<div class="form-control-position dpicker-icon-position">
									<i class='bx bx-calendar'></i>
								</div>
							</fieldset>
                        </div>
						<div class="col-md-15">
                            <fieldset class="form-group set-position-relative">
								<span class="btn btn-primary add-more-variation" data-toggle="modal" data-target="#quickSupplierCreate" data-repeater-create="" type="button" style="position: absolute;right: 0px;top: -10px;font-size: 12px;padding: 1px 8px;"><i class="bx bxs-add-to-queue"></i> NEW SUPPLIER</span>
                                <label>Supplier <span class="mendatory">*</span></label>
                                <input type="text" id="searchSupplier" class="form-control" placeholder="Enter supplier name" required />
								<input type="hidden" id="hiddenSupplierId" name="supplier_id" />
                            </fieldset>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  
  <div class="row">
	<div class="col-md-12">
		<div class="card set-position-relative">
			<span class="btn btn-primary refresh-modal-on-click" data-toggle="modal" data-target="#default" data-repeater-create="" type="button" style="position: absolute;right: 5px;top: 5px;padding: 2px 10px;font-size: 13px;"><i class="bx bxs-add-to-queue"></i> ADD PRODUCT</span>
            <div class="card-header">
                <h4 class="card-title">Particulars</h4>
            </div>
            <div class="card-content">
                <div class="card-body" style="padding:0">
                    <div class="row">
                        <div class="col-md-12">
							<!-- table striped -->
							<div class="table-responsive">
							  <table class="table table-striped mb-0">
								<thead>
								  <tr>
									<th style="width:5%">S.No</th>
									<th style="width:30%">PRODUCT</th>
									<th class="text-center">PHOTO</th>
									<th class="text-center">QTY</th>
									<th class="text-center">UNIT</th>
									<th class="text-center">PURCHASE PRICE / QTY</th>
									<th class="text-center">SALE PRICE / QTY</th>
									<th class="text-center">PROFIT / QTY</th>
									<th class="text-center">AMOUNT</th>
									<th class="text-center">ACTION</th>
								  </tr>
								</thead>
								<tbody id="productContents">
									<tr>
										<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="10">NO PRODUCT ADDED</td>
									</tr>
								</tbody>
							  </table>
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
  </div>
  
  <div class="row">
    <div class="col-md-8">
		<div id="alert"></div>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Summery</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
					<div class="row">
                        <div class="col-md-6">
                            <fieldset class="form-group">
                                <label>Shipping & Packaging Cost</label>
                                <input type="text" class="form-control" name="shipping_cost" id="inputShippingAndPackaging" autocomplete="off" />
                            </fieldset>
                        </div>
						<div class="col-md-6">
                            <fieldset class="form-group">
                                <label style="width: 100%;">Purchase Order Reference</label>
                                <select name="reference_type" class="form-control" style="width: 39.5%;float: left;margin-right: 10px;" readonly>
									<option value="ENQUIRY">Enquiry No</option>
									<option value="REFERENCE">Reference No</option>
									<option value="QUOTATION">Quotation No</option>
								</select>
								<input type="text" class="form-control" name="reference_no" style="width: 58%;float: left;" autocomplete="off" />
                            </fieldset>
                        </div>
                    </div>
					<div class="row">
						<div class="col-md-6">
                            <fieldset class="form-group">
                                <label style="width: 100%;">VAT</label>
                                <select id="vatType" name="vat_type" class="form-control" style="width: 39.5%;float: left;margin-right: 10px;" readonly>
									<option value="PERCENT">Percent</option>
									<option value="AMOUNT">Amount</option>
								</select>
								<input type="text" name="vat_value" id="vatValue" class="form-control" style="width: 58%;float: left;" autocomplete="off" />
                            </fieldset>
                        </div>
						<div class="col-md-6">
                            <fieldset class="form-group">
                                <label style="width: 100%;">TAX</label>
                                <select id="taxType" name="tax_type" class="form-control" style="width: 39.5%;float: left;margin-right: 10px;" readonly>
									<option value="PERCENT">Percent</option>
									<option value="AMOUNT">Amount</option>
								</select>
								<input type="text" name="tax_value" id="taxValue" class="form-control" style="width: 58%;float: left;" autocomplete="off" />
                            </fieldset>
                        </div>
					</div>
                    <div class="row">
                        <div class="col-md-6">
                            <fieldset class="form-group">
                                <label>Terms</label>
                                <textarea name="terms" class="form-control" cols="30" rows="2"></textarea>
                            </fieldset>
                        </div>
						<div class="col-md-6">
                            <fieldset class="form-group">
                                <label>Remarks</label>
                                <textarea name="remarks" class="form-control" cols="30" rows="2"></textarea>
                            </fieldset>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<div class="col-md-4">
      <div class="card">
        <div class="card-content">
          <div class="card-body" style="padding-bottom: 2px;">
              <div class="form-body">
                <div class="row">
				  <div class="col-12">
					<div class="invoice-subtotal">
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Subtotal</span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="subtotal" id="invoiceSubtotal" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Shipping & Packaging Cost</span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" id="invoiceShippingAndPackagingCost" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Vat <span id="showVatPercent" style="font-size:10px;color:#a00"></span></span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="vat_amount_total" id="invoiceVat" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Tax <span id="showTaxPercent" style="font-size:10px;color:#a00"></span></span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="tax_amount_total" id="invoiceTax" class="form-control text-right" value="0.00" readonly /></span>
					  </div>
					  <hr>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Total Amount</span>
						<span class="invoice-value" style="font-size: 13px;padding: 0 15px;font-size: 14px;font-weight: bold;"><strong>BDT</strong> <span id="showInvoiceTotal">0.00</span></span>
						<input type="hidden" name="total_amount" id="invoiceTotalAmount" />
					  </div>
					  <hr>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Discount</span>
						<span class="invoice-value" style="font-size: 13px;"><input type="text" name="discount" style="color:#F00 !important;" id="invoiceDiscount" class="form-control text-right" value="0.00" autocomplete="off"  /></span>
					  </div>
					  <hr>
					  <div class="invoice-calc d-flex justify-content-between">
						<span class="invoice-title">Net Total</span>
						<span class="invoice-value" style="font-size: 13px;padding: 0 15px;font-size: 14px;font-weight: bold;"><strong>BDT</strong> <span id="showInvoiceNetTotal">0.00</span></span>
						<input type="hidden" name="net_total" id="invoiceNetTotal" />
					  </div>
					</div>
				  </div>
				  
				  <div class="col-12 d-flex justify-content-end justify-content-custom">
					<!--<button type="reset" class="btn btn-custom-form btn-light-secondary mr-1 mb-1" style="margin-right:0px;"><i class="bx bx-reset"></i> Reset</button>-->
					<button type="submit" class="btn btn-custom-form btn-primary mr-1 mb-1"><i class="bx bxs-send"></i> Create Purchase Order</button>
				  </div>
				  
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php echo form_close(); ?>
</section>
<!-- Basic Inputs end -->

<!--Basic Create Modal -->
<?php  
	$attr = array('id' => 'addItems', 'class' => '');
	echo form_open('', $attr);
?>
<div class="modal fade text-left" id="default" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable set-position-relative" role="document" style="max-width:99%;">
	<div id="modalAddProductProgressLoader">
		<img class="app-process-loader" src="<?php echo base_url('backend/tools/process.gif') ?>" alt="Processing..." />
		<!--<span>Please wait...</span>-->
	</div>
	<div class="modal-content">
	  <div class="modal-header">
		<h3 class="modal-title" id="myModalLabel1">ADD PRODUCT</h3>
	  </div>
	  <div class="modal-body">
		<div class="col-12 text-center">
			<div class="form-group add-product-search-field" style="margin: 0 auto;width: 690px;">
				<label style="display: block;" for="first-name-vertical">SEARCH PRODUCT</label>
				<select name="product_type" class="custom-select" id="productsType" style="width: 26%;float: left;">
					<option value="GENERAL">Medicinal products</option>
					<option value="DRUGS">Drugs</option>
				</select>
				<input name="srcfield" type="text" id="searchProduct" class="form-control" style="width: 72%;float: left;margin-top: 0;margin-left: -6px;" placeholder="Search product by name, serial number etc ...." />
				<div style="clear: both;"></div>
			</div>
		</div>
		<div id="itemDescriptions" style="margin: 30px 0 30px;"></div>
	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-light-secondary" data-dismiss="modal">
		  <i class="bx bx-x d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Close</span>
		</button>
		<button type="submit" class="btn btn-primary ml-1">
		  <i class="bx bx-check d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Add Product</span>
		</button>
	  </div>
	</div>
  </div>
</div>
<?php echo form_close(); ?>

<?php  
	$attr = array('id' => 'editItems', 'class' => '');
	echo form_open('', $attr);
?>
<div class="modal fade text-left" id="defaultUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable set-position-relative" role="document" style="max-width:99%;">
	<div id="modalAddProductProgressLoader">
		<img class="app-process-loader" src="<?php echo base_url('backend/tools/process.gif') ?>" alt="Processing..." />
		<!--<span>Please wait...</span>-->
	</div>
	<div class="modal-content">
	  <div class="modal-header">
		<h3 class="modal-title">EDIT PRODUCT</h3>
	  </div>
	  <div class="modal-body">
		<div id="itemDescriptionsUpdate" style="margin: 30px 0 30px;"></div>
	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-light-secondary" data-dismiss="modal">
		  <i class="bx bx-x d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Close</span>
		</button>
		<button type="submit" class="btn btn-primary ml-1">
		  <i class="bx bx-check d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Update Product</span>
		</button>
	  </div>
	</div>
  </div>
</div>
<?php echo form_close(); ?>

<?php  
	$attr = array('id' => 'quickNewSupplier', 'class' => '');
	echo form_open('', $attr);
?>
<div class="modal fade text-left" id="quickSupplierCreate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document" style="max-width:75%;">
	<div id="modalProgressLoader">
		<img class="app-process-loader" src="<?php echo base_url('backend/tools/process.gif') ?>" alt="Processing..." />
	</div>
	<div class="modal-content">
	  <div class="modal-header">
		<h3 class="modal-title" id="myModalLabel1">NEW SUPPLIER</h3>
	  </div>
	  <div class="modal-body">
		<div class="row">
			<div class="col-md-6">
				<fieldset class="form-group">
					<label>NAME OF SUPPLIER / COMPANY <span class="mendatory">*</span></label>
					<input type="text" name="name" class="form-control" placeholder="Enter name of supplier / company">
				</fieldset>
				<fieldset class="form-group">
					<label>STATE <span class="mendatory">*</span></label>
					<select name="state_id" class="form-control" id="onChangeState">
						<option value="">Select State</option>
						<?php 
							$states = $this->Purchase_model->get_states_by_country(18);
							foreach($states as $state):
						?>
						<option value="<?php echo $state['state_id']; ?>"><?php echo $state['state_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</fieldset>
				<fieldset class="form-group">
					<label>ADDRESS <span class="mendatory">*</span></label>
					<input type="text" name="address" class="form-control" placeholder="Enter address">
				</fieldset>
				<fieldset class="form-group">
					<label>E-MAIL ADDRESS <span class="mendatory">*</span></label>
					<input type="text" name="email_address" class="form-control" placeholder="Enter e-mail address">
				</fieldset>
				<fieldset class="form-group position-relative has-icon-left">
					<label>DATE COMPANY WAS ESTABLISHED</label>
					<input type="text" name="company_established_date" class="form-control pickadate-months-year" placeholder="Enter established date">
					<div class="form-control-position dpicker-icon-position">
						<i class='bx bx-calendar'></i>
					</div>
				</fieldset>
				<fieldset class="form-group">
					<label>TYPE OF BUSINESS</label>
					<ul class="list-unstyled mb-0">
					<?php 
						$type_of_business = array(
											'Retailer',
											'Contractor',
											'Distribution / Dealer',
											'Manufacturer',
											'Wholesaler',
											'Other',
										);
						foreach($type_of_business as $key => $value):
					?>
					  <li class="d-inline-block mr-2 mb-1">
						<fieldset>
						  <div class="radio radio-primary">
							  <input type="radio" name="type_of_business" id="colorRadioTypeOfBusiness<?php echo $key; ?>" value="<?php echo $value; ?>" />
							  <label for="colorRadioTypeOfBusiness<?php echo $key; ?>"><?php echo $value; ?></label>
						  </div>
						</fieldset>
					  </li>
					<?php endforeach; ?>
					</ul>
				</fieldset>
				<fieldset class="form-group">
					<label>LEGAL STRUCTURE</label>
					<ul class="list-unstyled mb-0">
					<?php 
						$legal_structure = array(
											'Corporation',
											'Partnership',
											'Sole Propietorship',
											'Joint Venture',
											'Other',
										);
						foreach($legal_structure as $key => $value):
					?>
					  <li class="d-inline-block mr-2 mb-1">
						<fieldset>
						  <div class="radio radio-primary">
							  <input type="radio" name="company_legal_structure" id="colorRadioLegalStructure<?php echo $key; ?>" value="<?php echo $value; ?>" />
							  <label for="colorRadioLegalStructure<?php echo $key; ?>"><?php echo $value; ?></label>
						  </div>
						</fieldset>
					  </li>
					<?php endforeach; ?>
					</ul>
				</fieldset>
			</div>
			<div class="col-md-6">
				<fieldset class="form-group">
					<label>COUNTRY <span class="mendatory">*</span></label>
					<select name="country_id" class="form-control" id="onChangeCountry">
						<option value="">Select Country</option>
						<?php 
							$countries = $this->Purchase_model->get_all_countries();
							foreach($countries as $country):
						?>
						<option value="<?php echo $country['country_id']; ?>" <?php echo ($country['country_id'] == 18)? 'selected' : null; ?>><?php echo $country['country_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</fieldset>
				<fieldset class="form-group">
					<label>CITY <span class="mendatory">*</span></label>
					<select name="city_id" class="form-control" id="onChangeCityContent" disabled>
						<option value="">Select City</option>
					</select>
				</fieldset>
				<fieldset class="form-group">
					<label>TELEPHONE NUMBER</label>
					<input type="text" name="telephone_number" class="form-control" placeholder="Enter telephone number">
				</fieldset>
				<fieldset class="form-group">
					<label>FAX NUMBER</label>
					<input type="text" name="fax_number" class="form-control" placeholder="Enter fax number">
				</fieldset>
				<fieldset class="form-group">
					<label>WEBSITE ADDRESS</label>
					<input type="text" name="website_address" class="form-control" placeholder="Enter website address">
				</fieldset>
				<fieldset class="form-group">
					<label>SERVICE AREA</label>
					<ul class="list-unstyled mb-0">
					<?php 
						$service_area = array(
											'Local',
											'Regional',
											'National',
											'International',
										);
						foreach($service_area as $key => $value):
					?>
					  <li class="d-inline-block mr-2 mb-1">
						<fieldset>
						  <div class="radio radio-primary">
							  <input type="radio" name="service_area" id="colorRadio<?php echo $key; ?>" value="<?php echo $value; ?>" />
							  <label for="colorRadio<?php echo $key; ?>"><?php echo $value; ?></label>
						  </div>
						</fieldset>
					  </li>
					<?php endforeach; ?>
					</ul>
				</fieldset>
				<fieldset class="form-group">
					<label style="width:100%">COMPANY LOGO (If any)</label>
					<div style="margin-bottom:5px;"><img id="photoPreview" src="<?php echo base_url('backend/tools/no-image.png'); ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></div>
					<input type="file" id="onchangeFile" name="logo" />
				</fieldset>
			</div>
		</div>
	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-light-secondary" data-dismiss="modal">
		  <i class="bx bx-x d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Close</span>
		</button>
		<input type="hidden" name="is_active" value="YES" />
		<button type="submit" class="btn btn-primary ml-1">
		  <i class="bx bx-check d-block d-sm-none"></i>
		  <span class="d-none d-sm-block">Create New Supplier</span>
		</button>
	  </div>
	</div>
  </div>
</div>
<?php echo form_close(); ?>
<?php 
	$units = $this->Purchase_model->get_all_units();
	$units_js = '';
	foreach($units as $unit):
	$units_js .= '<option value="'.$unit['unit_id'].'">'.$unit['unit_name'].'</option>';
	endforeach; 
?>
<!--START INPAGE SCRIPTS-->
<script type="text/javascript">
	$(document).ready(function(){
		$("#createForm").validate({
			rules:{
				name:{
					required: true,
				},
				branch:{
					required: true,
				},
				warehouse:{
					required: true,
				},
				invoice_date:{
					required: true,
				},
				order_date:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#createProgressLoader').show();
				// your function if, validate is success
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/create",
					data : $('#createForm').serialize(),
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							document.getElementById("createForm").reset();
							$("#alert").html(data.alert);
							$('#createProgressLoader').hide();
							setTimeout(function() {
								$("#alert").html('');
							}, 4000);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							 var content = '<tr>'+
											'<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="10">NO PRODUCT ADDED</td>'+
										'</tr>';
							$("#productContents").html(content);
							showCalculation();
							window.setTimeout(function(){
								window.location.href = baseUrl + "purchase/view/"+data.formatted_id;
							}, 2000);
							return false;
						}else if(data.status == "error")
						{
							$('#createProgressLoader').hide();
							$("#alert").html(data.alert);
							$('html, body').animate({
								scrollTop: $("body").offset().top
							 }, 1000);
							 setTimeout(function() {
								$("#alert").html('');
							}, 5000);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
		
		$(document).on('change', '#onChangeBranch', function(){
			var branch_id = $(this).val();
			if(branch_id !== '')
			{
				$.ajax({
					type : "POST",
					url : baseUrl + "inventories/warehouse/get_warehouses",
					data : {branch_id:branch_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$('#warehouseContent').html(data.content);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#searchSupplier').autocomplete({
		  source: function( request, response ) {
			  if(request.term !== ''){
				  $.ajax({
					  type: "GET",
					  url: baseUrl + "purchase/suppliers/srcsuppliers",
					  dataType: "json",
					  data: {
						q: request.term,
					  },
					  success: function( data ) {
						response( data.content);
					  }
				 });
			  }else{
				  return false;
			  }
		  },
		  select: function (event, ui) {
					//var hiddenValue = $(this).attr('data-section');
					$(this).val(ui.item.label); // display the selected text
					$('#hiddenSupplierId').val(ui.item.value); // save selected id to hidden input
					return false;
		  },
		  minLength: 1,
		  open: function() {
			$( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
		  },
		  close: function() {
			$( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
		  }
		});
		
		$('#searchProduct').autocomplete({
		  source: function( request, response ) {
			  if(request.term !== ''){
				  var productsType = $('#productsType').val();
				  if(productsType == 'GENERAL'){
					  var ajaxUrl = baseUrl + "inventories/products/srcproducts";
				  }else{
					  var ajaxUrl = baseUrl + "inventories/drugs/srcproducts";
				  }
				  $.ajax({
					  type: "GET",
					  url: ajaxUrl,
					  dataType: "json",
					  data: {
						q: request.term,
					  },
					  success: function( data ) {
						response( data.content);
					  }
				 });
			  }else{
				  return false;
			  }
		  },
		  select: function (event, ui) {
					//var hiddenValue = $(this).attr('data-section');
					//$(this).val(ui.item.label); // display the selected text
					$(this).val(''); // display the selected text
					//$('#'+hiddenValue).val(ui.item.value); // save selected id to hidden input
					$.ajax({
						type : "POST",
						url : baseUrl + "purchase/getproductinfo",
						data : {id:ui.item.value},
						dataType : "json",
						cache: false,
						success : function (data) {
							if(data.status == "ok")
							{
								$("#itemDescriptions").html(data.content);
								$("input#searchProduct").attr('name', '');
								showItemCalculation(1);
								return false;
							}else
							{
								//have end check.
							}
							return false;
						}
					});
					return false;
		  },
		  open: function() {
			$( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
		  },
		  close: function() {
			$( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
		  }
		}).autocomplete( "instance" )._renderItem = function( ul, item ) {
		  return $( "<li>" )
			.append( '<div class="ui-item-list-wrapp"><img src="'+item.photo+'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /> '+item.label+'</div>' )
			.appendTo( ul );
		};
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('keyup', '#searchSupplier', function(){
			$('#hiddenSupplierId').val('');
		});
		$(document).on('blur', '#searchSupplier', function(){
			var supplierId = $('#hiddenSupplierId').val();
			if(supplierId == '')
			{
				$(this).val('');
				return false;
			}
		});
		
		$("#quickNewSupplier").validate({
			rules:{
				name:{
					required: true,
				},
				address:{
					required: true,
				},
				email_address:{
					required: true,
					email:true,
				},
				country_id:{
					required: true,
				},
				state_id:{
					required: true,
				},
				city_id:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#modalProgressLoader').show();
				// your function if, validate is success
				var getFrmData = new FormData(document.getElementById('quickNewSupplier'));
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/create",
					data : getFrmData,
					dataType : "json",
					cache: false,
					contentType: false,
					processData: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$('#quickSupplierCreate').modal('hide');
							$("#searchSupplier").val(data.supplier_name);
							$("#hiddenSupplierId").val(data.supplier_id);
							return false;
						}else if(data.status == "error")
						{
							$('#modalProgressLoader').hide();
							$("#alert").html(data.alert);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onChangeCountry', function(){
			var country_id = $(this).val();
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/suppliers/get_states_by_country",
				data : {country_id:country_id},
				dataType : "json",
				cache: false,
				success : function (data) {
					if(data.status == "ok")
					{
						$("#onChangeState").html(data.content);
						return false;
					}else
					{
						//have end check.
					}
					return false;
				}
			});
		});
		
		$(document).on('change', '#onChangeState', function(){
			var state_id = $(this).val();
			if(state_id != ''){
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/suppliers/get_cities_by_state",
					data : {state_id:state_id},
					dataType : "json",
					cache: false,
					success : function (data) {
						if(data.status == "ok")
						{
							$('#onChangeCityContent').prop("disabled", false);
							$("#onChangeCityContent").html(data.content);
							return false;
						}else
						{
							//have end check.
						}
						return false;
					}
				});
			}else{
				$('#onChangeCityContent').prop("disabled", true);
			}
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change', '#onchangeFile', function(){
			readFileUrl(this);
		});
	});
	function readFileUrl(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#photoPreview').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<script type="text/javascript">
	//Add product functions
	$(document).ready(function(){
		var units = '<?php echo $units_js; ?>';
		//var rowNo = document.querySelectorAll('.onchange-purchase-variation').length + 1;
		var rowNo = 2;
		$(document).on('click', '.add-more-item', function(){
			if(rowNo > 1)
			{
				var prevRow = rowNo - 1;
			}else{
				var prevRow = 1;
			}
			var activeVariationPrev = $('.product-variation-'+prevRow).val();
			var activeVariationOptionPrev = $('.variation-option-content-'+prevRow).val();
			var activeQtyPrev = $('.qty-'+prevRow).val();
			var activeUnitPrev = $('.unit-'+prevRow).val();
			var activePurchasePricePrev = $('.purchase-price-'+prevRow).val();
			var activeSalePricePrev = $('.sale-price-'+prevRow).val();
			if(activeVariationPrev !== "" && activeVariationOptionPrev !== "" && activeQtyPrev !== "" && activeUnitPrev !== "" && activePurchasePricePrev !== "" && activeSalePricePrev !== "")
			{
				var productId = $(this).attr('data-variation-product');
				var selectedVariations = [];
				$('.onchange-purchase-variation option:selected').each(function() {
					selectedVariations.push($(this).val());
				});
				var variations = function () {
					var variants = null;
					$.ajax({
						'async': false,
						'type': "POST",
						'global': false,
						'dataType': 'html',
						'url': baseUrl + "purchase/get_product_variations",
						data : {product_id:productId, selected_variations:selectedVariations},
						'success': function (data) {
							variants = data;
						}
					});
					
					return variants;
				}();
				if(rowNo < 10)
				{
					var row = '0'+rowNo;
				}else{
					var row = rowNo;
				}
				var content = '<tr>'+
									'<td class="item-variation-sl">'+row+'</td>'+
									'<td>'+
										'<select name="variation_id_'+rowNo+'" class="form-control onchange-purchase-variation product-variation-'+rowNo+'" data-variation-product="'+productId+'" data-row="'+rowNo+'" style="display: inline-block;width: 52%;margin-right: 2px;" required>'+
											'<option value="">Select Variation</option>'+variations+
										'</select>'+
										'<select name="variation_option_id_'+rowNo+'" data-row="'+rowNo+'" data-provariation="" data-selected-option="" data-variation-product="'+productId+'" class="form-control onchange-purchase-variation-option variation-option-content-'+rowNo+'" data-row="'+rowNo+'" style="display: inline-block;width: 46%;" required>'+
											'<option value="">Select Option</option>'+
										'</select>'+
									'</td>'+
									'<td><input type="text" name="qty_'+rowNo+'" class="form-control text-center onchange-qty qty-'+rowNo+'" data-row="'+rowNo+'" autocomplete="off" required /></td>'+
									'<td>'+
										'<select name="unit_id_'+rowNo+'" class="form-control unit-'+rowNo+'" required>'+
											'<option value="">Select Unit</option>'+units+
										'</select>'+
									'</td>'+
									'<td><input type="text" name="purchase_price_'+rowNo+'" class="form-control text-center onchange-purchase-price purchase-price-'+rowNo+'" data-row="'+rowNo+'" autocomplete="off" required /></td>'+
									'<td><input type="text" name="sale_price_'+rowNo+'" class="form-control text-center onchange-sale-price sale-price-'+rowNo+'" data-row="'+rowNo+'" autocomplete="off" required /></td>'+
									'<td>'+
										'<input type="text" class="form-control text-center show-profit-per-qty-'+rowNo+'" disabled />'+
										'<input type="hidden" name="profit_per_qty_'+rowNo+'" class="form-control profit-per-qty-'+rowNo+'"/>'+
									'</td>'+
									'<td>'+
										'<input type="text" class="form-control text-center show-subtotal-amount-'+rowNo+'" disabled />'+
										'<input type="hidden" name="subtotal_amount_'+rowNo+'" class="subtotal-amount-'+rowNo+'" />'+
									'</td>'+
									'<td class="text-center">'+
										'<span class="remove-item-icon remove-item"><i class="bx bx-x"></i></span>'+
									'</td>'+
									'<input type="hidden" name="purchase_variations[]" value="'+rowNo+'" />'+
								'</tr>';
				$('#itemsVariationsContainer').append(content);
				$('.product-variation-'+prevRow).removeClass('var-error');
				$('.variation-option-content-'+prevRow).removeClass('var-error');
				$('.qty-'+prevRow).removeClass('var-error');
				$('.unit-'+prevRow).removeClass('var-error');
				$('.purchase-price-'+prevRow).removeClass('var-error');
				$('.sale-price-'+prevRow).removeClass('var-error');
				
				setSl(".item-variation-sl");
			}else{
				var productVariation       = $('.product-variation-'+prevRow).val();
				var variationOptionContent = $('.variation-option-content-'+prevRow).val();
				var qty                    = $('.qty-'+prevRow).val();
				var unit                   = $('.unit-'+prevRow).val();
				var purchasePrice          = $('.purchase-price-'+prevRow).val();
				var salePrice              = $('.sale-price-'+prevRow).val();
				if(productVariation == "")
				{
					$('.product-variation-'+prevRow).addClass('var-error');
					return false;
				}else{
					$('.product-variation-'+prevRow).removeClass('var-error');
				}
				if(variationOptionContent == "")
				{
					$('.variation-option-content-'+prevRow).addClass('var-error');
					return false;
				}else{
					$('.variation-option-content-'+prevRow).removeClass('var-error');
				}
				if(qty == "")
				{
					$('.qty-'+prevRow).addClass('var-error');
					return false;
				}else{
					$('.qty-'+prevRow).removeClass('var-error');
				}
				if(unit == "")
				{
					$('.unit-'+prevRow).addClass('var-error');
					return false;
				}else{
					$('.unit-'+prevRow).removeClass('var-error');
				}
				if(purchasePrice == "")
				{
					$('.purchase-price-'+prevRow).addClass('var-error');
					return false;
				}else{
					$('.purchase-price-'+prevRow).removeClass('var-error');
				}
				if(salePrice == "")
				{
					$('.sale-price-'+prevRow).addClass('var-error');
					return false;
				}else{
					$('.sale-price-'+prevRow).removeClass('var-error');
				}
			}
			
			rowNo++;
		});
		
		$(document).on('click', '.remove-item', function(){
			if(confirm('Are you sure?', true))
			{
				$(this).parent().parent().remove();
				setSl(".item-variation-sl");
			}
		});
		
		$(document).on('change', '.onchange-purchase-variation', function(){
			var provariation_id = $(this).val();
			var rowNumber = $(this).attr('data-row');
			var variation_product_id = $(this).attr('data-variation-product');
			var selectedVariationOptions = [];
			if($('select.variant-'+provariation_id+'-option').length)
			{
				$('.variant-'+provariation_id+'-option option:selected').each(function() {
					selectedVariationOptions.push($(this).val());
				});
			}
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/get_product_variation_options",
				data : {variation_id:provariation_id, row_number:rowNumber, variation_product_id:variation_product_id, selected_variation_options:selectedVariationOptions},
				dataType : "json",
				success : function (data) {
					if(data.status == "ok")
					{
						$('.variation-option-content-'+data.row_number).html(data.content);
						$('.variation-option-content-'+data.row_number).addClass('variant-'+provariation_id+'-option');
						$('.variation-option-content-'+data.row_number).attr('data-provariation', provariation_id);
						return false;
					}else
					{
						//have end check.
					}
					return false;
				}
			});
		});
		
		$(document).on('change', '.onchange-purchase-variation-option', function(){
			var selectedValue = $(this).val();
			var selectedRow = $(this).attr('data-row');
			var selectedProvariationValue = $(this).attr('data-provariation');
			var selectedProductId = $(this).attr('data-variation-product');
			var selectedVariationOptions = [];
			$('.variant-'+selectedProvariationValue+'-option option:selected').each(function() {
				selectedVariationOptions.push($(this).val());
			});
			selectedVariationOptions.splice( selectedVariationOptions.indexOf(selectedValue), 1);
			if(selectedVariationOptions.includes(selectedValue))
			{
				alert("Your selected option is already exist!");
				var oldValue = $(this).attr('data-selected-option');
				$(this).attr('data-selected-option', oldValue);
				$(this).val(oldValue);
			}else{
				$(this).attr('data-selected-option', selectedValue);
			}
			
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/get_product_price_info",
				data : {provariation_id:selectedProvariationValue, variation_product_id:selectedProductId, option_id:selectedValue},
				dataType : "json",
				success : function (data) {
					if(data.status == "ok")
					{
						$('.purchase-price-'+selectedRow).val(data.purchase_price);
						$('.sale-price-'+selectedRow).val(data.sale_price);
						showItemCalculation(selectedRow);
						return false;
					}else
					{
						//have end check.
					}
					return false;
				}
			});
		});
	});
	$(document).ready(function(){
		$(document).on('keyup', '.onchange-qty', function(){
			var rowNumber = $(this).attr('data-row');
			showItemCalculation(rowNumber);
		});
		$(document).on('keyup', '.onchange-purchase-price', function(){
			var rowNumber = $(this).attr('data-row');
			showItemCalculation(rowNumber);
		});
		$(document).on('keyup', '.onchange-sale-price', function(){
			var rowNumber = $(this).attr('data-row');
			showItemCalculation(rowNumber);
		});
	});
	function add_product_profit_per_qty(purchasePrice, salePrice)
	{
		var profit = salePrice - purchasePrice;
		return profit;
	}
	
	function add_product_subtotal_amount(qty, purchasePrice)
	{
		var subtotal = purchasePrice * qty;
		return subtotal;
	}
	
	function showItemCalculation(rowNumber)
	{
		var qty = parseFloat(deFormatNumber($('.qty-'+rowNumber).val())) || 0;
		var purchasePrice = parseFloat(deFormatNumber($('.purchase-price-'+rowNumber).val())) || 0;
		var salePrice = parseFloat(deFormatNumber($('.sale-price-'+rowNumber).val())) || 0;
		var profitPerQty = add_product_profit_per_qty(purchasePrice, salePrice);
		var subtotal = add_product_subtotal_amount(qty, purchasePrice);
		
		$('.show-profit-per-qty-'+rowNumber).val(formatNumber(profitPerQty));
		$('.profit-per-qty-'+rowNumber).val(profitPerQty);
		
		$('.show-subtotal-amount-'+rowNumber).val(formatNumber(subtotal));
		$('.subtotal-amount-'+rowNumber).val(subtotal);
	}
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('click', '.refresh-modal-on-click', function(){
			$("input#searchProduct").attr('name', 'srcfield');
			$('#itemDescriptions').html('');
		});
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#addItems").validate({
			rules:{
				srcfield:{
					required: true,
				},
			},
			submitHandler : function () {
				$('#modalAddProductProgressLoader').show();
				var slNo = $('.particulars-item-row').length + 1;
				// your function if, validate is success
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/addparticulars",
					data : $('#addItems').serialize()+'&sl_number='+slNo,
					dataType : "json",
					success : function (data) {
						if(data.status == "ok")
						{
							$('#modalAddProductProgressLoader').hide();
							$('#default').modal('hide');
							if(slNo == 1)
							{
								$("#productContents").html(data.content);
								$("#itemDescriptions").html('');
								setSl(".particulars-itm-sl");
								showCalculation();
								return false;
							}else{
								$("#productContents").append(data.content);
								$("#itemDescriptions").html('');
								setSl(".particulars-itm-sl");
								showCalculation();
								return false;
							}
						}else
						{
							//have end check.
							return false;
						}
						return false;
					}
				});
			}
		});
		
		$("#editItems").validate({
			submitHandler : function () {
				$('#modalAddProductProgressLoader').show();
				var slNo = $('.particulars-item-row').length + 1;
				// your function if, validate is success
				$.ajax({
					type : "POST",
					url : baseUrl + "purchase/update_particulars",
					data : $('#editItems').serialize()+'&sl_number='+slNo,
					dataType : "json",
					success : function (data) {
						if(data.status == "ok")
						{
							$('#modalAddProductProgressLoader').hide();
							$('#defaultUpdate').modal('hide');
							$(".particulars-item-content-row-"+data.row_number).html(data.content);
							$("#itemDescriptionsUpdate").html('');
							setSl(".particulars-itm-sl");
							showCalculation();
							return false;
						}else
						{
							//have end check.
							return false;
						}
						return false;
					}
				});
			}
		});
		
		$(document).on('click', '.invoice-action-edit', function(){
			var rowNumber           = $(this).attr('data-row');
			var productId           = $(this).attr('data-product');
			var has_variations      = $(this).attr('data-has-variations');
			var variation_id        = $('.update-provariation-id-'+rowNumber).val();
			var variation_option_id = $('.update-variation-option-id-'+rowNumber).val();
			var unit_id             = $('.update-unit-id-'+rowNumber).val();
			var qty                 = $('.update-qty-'+rowNumber).val();
			var purchase_price      = $('.update-purchase-price-'+rowNumber).val();
			var sale_price          = $('.update-sale-price-'+rowNumber).val();
			var profit_per_qty      = $('.update-profit-per-qty-'+rowNumber).val();
			var subtotal_amount     = $('.update-subtotal-amounts-'+rowNumber).val();
			$.ajax({
				type : "POST",
				url : baseUrl + "purchase/get_product_update_info",
				data : {id:productId, 
						has_variations:has_variations, 
						unit_id:unit_id, 
						qty:qty, 
						purchase_price:purchase_price, 
						sale_price:sale_price,
						profit_per_qty:profit_per_qty,
						subtotal_amount:subtotal_amount,
						row_number:rowNumber,
						variation_id:variation_id,
						variation_option_id:variation_option_id
						},
				dataType : "json",
				success : function (data) {
					if(data.status == "ok")
					{
						$("#itemDescriptionsUpdate").html(data.content);
						return false;
					}else
					{
						//have end check.
					}
					return false;
				}
			});
		});
		
		$('#default').on('hidden.bs.modal', function () {
		   $("#itemDescriptions").html('');
		   $("#itemDescriptionsUpdate").html('');
		});
		$('#defaultUpdate').on('hidden.bs.modal', function () {
		   $("#itemDescriptions").html('');
		   $("#itemDescriptionsUpdate").html('');
		});
		
		$(document).on('click', '.remove-item-from-particulars', function(){	
			if(confirm('Are you sure?', true))
			{
				$(this).parent().parent().parent().remove();
				setSl(".particulars-itm-sl");
				var totalItems = $('.particulars-item-row').length;
				if(totalItems < 1)
				{
					var content = '<tr>'+
									'<td class="text-bold-500 text-center" style="padding:50px 0 !important;" colspan="10">NO PRODUCT ADDED</td>'+
								'</tr>';
					$("#productContents").html(content);
				}
				showCalculation();
				return false;
			}
		});
		
		$(document).on('keyup', '#inputShippingAndPackaging', function(){
			showCalculation();
			return false;
		});
		$(document).on('change', '#vatType', function(){
			showCalculation();
			return false;
		});
		$(document).on('keyup', '#vatValue', function(){
			showCalculation();
			return false;
		});
		$(document).on('change', '#taxType', function(){
			showCalculation();
			return false;
		});
		$(document).on('keyup', '#taxValue', function(){
			showCalculation();
			return false;
		});
		$(document).on('keyup', '#invoiceDiscount', function(){
			showCalculation();
			return false;
		});
	});
	
	function setSl(selector)
	{
		var particularsItmSl = $(selector);
		for(var i=0; i < particularsItmSl.length; i++){
			var element = particularsItmSl.eq(i);
			var x = i+1;
			if(x<10){
				var sl = '0'+x;
			}else{
				var sl = x;
			}
			$(element).text(sl);
		}
	}

/*********Calculation related functions started**************/
	function getSubtotalTotal(selector)
	{
		var particularsItmPrice = $(selector);
		var totalAmount = 0;
		for(var i=0; i < particularsItmPrice.length; i++){
			var value = parseFloat($(particularsItmPrice.eq(i)).val()) || 0;
			totalAmount += value;
		}
		
		return totalAmount;
	}
	
	function getVatClaculation()
	{
		var vatType = $('#vatType').val();
		var vatValue = parseFloat($('#vatValue').val()) || 0;
		if(vatType == "PERCENT")
		{
			var subtotal = getSubtotalTotal('.subtotal-amounts');
			var vatAmount = (subtotal / 100) * vatValue;
			return vatAmount;
		}else{
			return vatValue;
		}
	}
	
	function getTaxCalculation()
	{
		var taxType = $('#taxType').val();
		var taxValue = parseFloat(deFormatNumber($('#taxValue').val())) || 0;
		if(taxType == "PERCENT")
		{
			var subtotal = getSubtotalTotal('.subtotal-amounts');
			var taxAmount = (subtotal / 100) * taxValue;
			return taxAmount;
		}else{
			return taxValue;
		}
	}
	
	function showCalculation()
	{
		var subtotal = getSubtotalTotal('.subtotal-amounts');
		var shippingCost = parseFloat(deFormatNumber($('#inputShippingAndPackaging').val())) || 0;
		var vat = getVatClaculation();
		var tax = getTaxCalculation();
		var total = subtotal + shippingCost + vat + tax;
		
		var discount = parseFloat(deFormatNumber($('#invoiceDiscount').val())) || 0;
		var netTotal = total - discount;
		
		//Show amount in sub total
		$('#invoiceSubtotal').val(formatNumber(subtotal));
		
		//Show amount in shipping cost
		$('#invoiceShippingAndPackagingCost').val(formatNumber(shippingCost));
		
		//Show amount in vat
		var vatType = $('#vatType').val();
		var vatValue = $('#vatValue').val();
		if(vatType == "PERCENT" && vatValue !== "")
		{
			$('#showVatPercent').html('('+vatValue+'% of Subtotal Amount)');
		}else{
			$('#showVatPercent').html('');
		}
		$('#invoiceVat').val(formatNumber(vat));
		
		//Show amount in tax
		var taxType = $('#taxType').val();
		var taxValue = $('#taxValue').val();
		if(taxType == "PERCENT" && taxValue !== "")
		{
			$('#showTaxPercent').html('('+taxValue+'% of Subtotal Amount)');
		}else{
			$('#showTaxPercent').html('');
		}
		$('#invoiceTax').val(formatNumber(tax));
		
		//Show amount in total
		$('#showInvoiceTotal').html(formatNumber(total));
		$('#invoiceTotalAmount').val(total);
		
		//Show amount in net total
		$('#showInvoiceNetTotal').html(formatNumber(netTotal));
		$('#invoiceNetTotal').val(netTotal);
	}
	function formatNumber(number) {
		var formatTheNumber = numberWithCommas(number.toFixed(2));
		return formatTheNumber;
	}
	function deFormatNumber(number) {
		var a = number.replace(/\,/g,'');
		var result = parseFloat(a,10) || 0;
		return result;
	}
	function numberWithCommas(x) {
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	}
/*********Calculation related functions ended**************/
</script>	
<script type="text/javascript">
	$(document).ready(function(){
		/*********Format number on keyup started**************/
		$(document).on('keyup', '#inputShippingAndPackaging', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		$(document).on('keyup', '#vatValue', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		$(document).on('keyup', '#taxValue', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		$(document).on('keyup', '#invoiceDiscount', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		$(document).on('keyup', '.onchange-qty', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		
		$(document).on('keyup', '.onchange-purchase-price', function(event){
			  // skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		$(document).on('keyup', '.onchange-sale-price', function(event){
			// skip for arrow keys
			  if(event.which >= 37 && event.which <= 40){
			   event.preventDefault();
			  }

			  $(this).val(function(index, value) {
				  value = value.replace(/,/g,'');
				  return numberWithCommas(value);
			  });
		});
		/*********Format number on keyup ended**************/
	});
</script>
<!--END INPAGE SCRIPTS-->

<?php require_once APPPATH.'modules/common/footer.php'; ?>