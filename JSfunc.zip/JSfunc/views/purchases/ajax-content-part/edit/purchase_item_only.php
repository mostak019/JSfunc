<!-- table striped -->
<?php if($product_info['product_type'] == 'GENERAL'): ?>
<div class="set-position-relative">
	<table class="table table-striped mb-2" style="background: #F0F0F0;box-shadow:0 0 6px rgba(0,0,0,0.3);">
	<thead>
	  <tr>
		<th style="width: 10%;text-align: center;">PHOTO</th>
		<th style="width: 12%;text-align: center;">SERIAL NUMBER</th>
		<th style="">PRODUCT NAME</th>
		<th style="width: 25%;text-align: center;">CATEGORIES</th>
		<th style="width: 25%;text-align: center;">COMPANY / BRAND</th>
		<th style="width: 14%;text-align: center;">CREATED DATE</th>
	  </tr>
	</thead>
	<tbody>
		<?php 
			$photo_url = get_product_photo_url($product_info['product_id']);
			$product_categories = '';
			if($product_info['furthercategory_name'])
			{
				$product_categories .= $product_info['furthercategory_name'].', ';
			}
			if($product_info['subcategory_name'])
			{
				$product_categories .= $product_info['subcategory_name'].', ';
			}
			if($product_info['category_name'])
			{
				$product_categories .= $product_info['category_name'];
			}
		?>
		<tr>
			<td class="text-center"><img src="<?php echo $photo_url; ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;"></td>
			<td class="text-center"><?php echo $product_info['product_serial_number']; ?></td>
			<td><?php echo $product_info['product_name']; ?></td>
			<td class="text-center"><?php echo $product_categories; ?></td>
			<td class="text-center"><?php echo $product_info['brandcompany_name']; ?></td>
			<td class="text-center"><?php echo date("d F, Y", strtotime($product_info['product_created_date'])).' '.date("g:i A", strtotime($product_info['product_created_date'])); ?></td>
		</tr>
	</tbody>
  </table>
  <input type="hidden" name="product_id" value="<?php echo $product_info['product_id']; ?>" />
  <input type="hidden" name="row_number" value="<?php echo $product_info['row_number']; ?>" />
</div>
<?php else: ?>
<div class="set-position-relative">
	<table class="table table-striped mb-2" style="background: #F0F0F0;box-shadow:0 0 6px rgba(0,0,0,0.3);">
	<thead>
	  <tr>
		<th style="width: 10%;text-align: center;">PHOTO</th>
		<th style="width: 12%;text-align: center;">SERIAL NUMBER</th>
		<th style="">BRAND</th>
		<th style="width: 15%;text-align: center;">GENERIC</th>
		<th style="width: 15%;text-align: center;">STRENGTH</th>
		<th style="width: 10%;text-align: center;">DOSAGES</th>
		<th style="width: 10%;text-align: center;">COMPANY</th>
		<th style="width: 14%;text-align: center;">CREATED DATE</th>
	  </tr>
	</thead>
	<tbody>
		<?php 
			$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
		?>
		<tr>
			<td class="text-center"><img src="<?php echo $photo_url; ?>" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;"></td>
			<td class="text-center"><?php echo $product_info['product_serial_number']; ?></td>
			<td><?php echo $product_info['drug_brand']; ?></td>
			<td class="text-center"><?php echo $product_info['drug_generic']; ?></td>
			<td class="text-center"><?php echo $product_info['drug_strength']; ?></td>
			<td class="text-center"><?php echo $product_info['drug_dosages']; ?></td>
			<td class="text-center"><?php echo $product_info['company_name']; ?></td>
			<td class="text-center"><?php echo date("d F, Y", strtotime($product_info['product_created_date'])).' '.date("g:i A", strtotime($product_info['product_created_date'])); ?></td>
		</tr>
	</tbody>
  </table>
  <input type="hidden" name="product_id" value="<?php echo $product_info['product_id']; ?>" />
  <input type="hidden" name="row_number" value="<?php echo $product_info['row_number']; ?>" />
</div>
<?php endif; ?>
<div class="">
  <table class="table table-striped mb-0" style="background: #F0F0F0;box-shadow:0 0 3px rgba(0,0,0,0.2);">
	<thead>
	  <tr>
		<th style="width: 8%;" class="text-center">QTY</th>
		<th style="width: 8%;" class="text-center">UNIT</th>
		<th style="width: 8%;" class="text-center">PURCHASE PRICE / QTY</th>
		<th style="width: 8%;" class="text-center">SALE PRICE / QTY</th>
		<th style="width: 8%;" class="text-center">PROFIT / QTY</th>
		<th style="width: 8%;" class="text-center">AMOUNT</th>
	  </tr>
	</thead>
	<tbody id="itemsVariationsContainer">
		<tr>
			<td><input type="text" name="qty_1" value="<?php echo number_format(floatval($product_info['qty']), 0, '.', ','); ?>" data-row="1" class="form-control onchange-qty qty-1 text-center" autocomplete="off" required /></td>
			<td>
				<select name="unit_id_1" class="form-control onchange-unit" required>
					<option value="">Select Unit</option>
					<?php 
						$units = $this->Purchase_model->get_all_units();
						foreach($units as $unit):
					?>
					<option value="<?php echo $unit['unit_id']; ?>" <?php echo ($product_info['unit_id'] == $unit['unit_id'])? 'selected' : null; ?>><?php echo $unit['unit_name']; ?></option>
					<?php endforeach; ?>
				</select>
			</td>
			<td><input type="text" name="purchase_price_1" value="<?php echo number_format(floatval($product_info['purchase_price']), 0, '.', ','); ?>" data-row="1" class="form-control onchange-purchase-price purchase-price-1 text-center" autocomplete="off" required /></td>
			<td><input type="text" name="sale_price_1" value="<?php echo number_format(floatval($product_info['sale_price']), 0, '.', ','); ?>" data-row="1" class="form-control onchange-sale-price sale-price-1 text-center" autocomplete="off" required /></td>
			<td>
				<input type="text" class="form-control text-center show-profit-per-qty-1" value="<?php echo number_format(floatval($product_info['profit_per_qty']), 0, '.', ','); ?>" disabled />
				<input type="hidden" name="profit_per_qty_1" value="<?php echo $product_info['profit_per_qty']; ?>" class="form-control profit-per-qty-1"/>
			</td>
			<td>
				<input type="text" class="form-control text-center show-subtotal-amount-1" value="<?php echo number_format(floatval($product_info['subtotal_amount']), 0, '.', ','); ?>" disabled />
				<input type="hidden" name="subtotal_amount_1" value="<?php echo $product_info['subtotal_amount']; ?>" class="subtotal-amount-1" />
			</td>
			<input type="hidden" name="purchase_variations[]" value="1" />
		</tr>
	</tbody>
  </table>
  <input type="hidden" name="purchase_has_variations" value="NO" />
</div>