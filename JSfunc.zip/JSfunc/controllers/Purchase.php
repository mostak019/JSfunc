<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$active_user = $this->session->userdata('active_admin');
		$userLogin = $this->session->userdata('userLogin');
		if($active_user === NULL && $userLogin !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		
		$this->load->library('ajax_pagination');
		$this->load->library('emailapiv1');
		$this->perPage = 10;
		$this->load->model('Purchase_model');
	}
	
	public function index()
	{
		$data = array();
        
		//total rows count
		$totalRec = $this->Purchase_model->count_all_purchases();
		
		//pagination configuration
		$config['target']      = '#postList';
		$config['base_url']    = base_url().'apiv1/get_purchases';
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		$config['link_func']   = 'searchFilter';
		$this->ajax_pagination->initialize($config);
		
		//get the posts data
		$data['items'] = $this->Purchase_model->get_all_purchases(array('limit'=>$this->perPage));
		
		$this->load->view('purchases/index', $data);
	}
	
	public function add()
	{
		$this->load->view('purchases/create');
	}
	
	public function edit($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchase_model->get_purchase_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['purchase_info'] = $is_info_exist;
				$this->load->view('purchases/edit', $data);
			}else{
				redirect('purchase', 'refresh', true);
			}
		}else{
			redirect('purchase', 'refresh', true);
		}
	}
	
	public function view($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchase_model->get_purchase_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['purchase_info'] = $is_info_exist;
				$this->load->view('purchases/details', $data);
			}else{
				redirect('purchase', 'refresh', true);
			}
		}else{
			redirect('purchase', 'refresh', true);
		}
	}
	
	public function download($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchase_model->get_purchase_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['purchase_info'] = $is_info_exist;
				$content = $this->load->view('purchases/pdf', $data, true);
				$file_name = 'purchase_order_'.$is_info_exist['order_number'].'_'.date("d-m-Y_H_i_s_A").'.pdf';
				$params = array_merge($is_info_exist, array(
															'primary_field_id'      => $is_info_exist['order_id'], 
															'content'               => $content, 
															'pdf_serial_field_name' => 'order_pdf_serial', 
															'subject'               => 'PURCHASE_ORDER',
															'file_name'             => $file_name
														));
				$this->pdf->download($params);
			}else{
				redirect('purchase', 'refresh', true);
			}
		}else{
			redirect('purchase', 'refresh', true);
		}
	}
	
	public function mail()
	{
		$this->load->view('purchases/mail', $data=array());
	}
	
	public function send()
	{
		$id = $this->input->post('formatted_id');
		$to = $this->input->post('email');
		$is_info_exist = $this->Purchase_model->get_purchase_by_formatted_id(html_escape($id));
		if($is_info_exist == true)
		{
			$file_name = 'purchase_order_'.$is_info_exist['order_number'].'_'.date("d-m-Y_H_i_s_A").'.pdf';
			$data['purchase_info'] = $is_info_exist;
			$content = $this->load->view('purchases/pdf', $data, true);
			$content_body = $this->load->view('purchases/mail', $data, true);
			$params = array_merge($is_info_exist, array(
															'primary_field_id'      => $is_info_exist['order_id'], 
															'pdf_serial_field_name' => 'order_pdf_serial', 
															'subject'               => 'PURCHASE_ORDER',
															'content'               => $content, 
															'file_name'             => $file_name,
															'email_to'              => $to,
															'email_subject'         => 'PURCHASE ORDER DETAILS',
															'email_body'            => $content_body,
															'has_attachment'        => 'YES',
														));
			$this->pdf->send($params);
			
			$alert = '<div class="alert alert-success">The purchase order invoice has been sent to "'.$to.'"</div>';
			$result = array('status' => 'ok', 'alert' => $alert);
			echo json_encode($result);
			exit;
		}else{
			$alert = '<div class="alert alert-danger">An error occurred, please try again later.</div>';
			$result = array('status' => 'error', 'alert' => $alert);
			echo json_encode($result);
			exit;
		}
	}
	
	public function exportexcel()
	{
		$from_date = html_escape($this->input->post('from_date'));
		$to_date = html_escape($this->input->post('to_date'));
		$is_registered = $this->input->post('is_registered');
		
		$dates = array();
		if($from_date && $to_date)
		{
			$dates['from_date'] = $from_date;
			$dates['to_date'] = $to_date;
		}
		$dates['is_registered'] = $is_registered;
		
		$date = date('d-m-Y');
        $file = 'Patients_'.$date.'.xls';
        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=$file");
        $data['items'] = $this->Patient_model->get_excel_items($dates);      
        $this->load->view('export/report_export_to_excel', $data);
	}
	
	public function exportcsv(){
		
		$from_date = html_escape($this->input->post('from_date'));
		$to_date = html_escape($this->input->post('to_date'));
		$is_registered = $this->input->post('is_registered');
		
		$dates = array();
		if($from_date && $to_date)
		{
			$dates['from_date'] = $from_date;
			$dates['to_date'] = $to_date;
		}
		$dates['is_registered'] = $is_registered;
		
		// file name
		$filename = 'patients_'.date('Ymd').'.csv';
		
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$filename");
		header("Content-Type: application/csv; "); 

		// get data
		$items = $this->Patient_model->get_csv_items($dates);

		// file creation
		$file = fopen('php://output', 'w');

		$header = array("patient_entryid", "patient_guide_book", "patient_idby_center", "patient_name", "patient_gender", "patient_phone", "patient_blood_group", "patient_address");
		fputcsv($file, $header);

		foreach ($items as $key=>$line){
		 fputcsv($file,$line);
		}

		fclose($file);
		exit;
	}
	
	
	public function getproductinfo()
	{
		$product_id = $this->input->post('id');
		$product_info = $this->Purchase_model->get_product_info($product_id);
		$data['product_info'] = $product_info;
		if($product_info['product_has_variations'] == 'YES'){
			$content = $this->load->view('purchases/ajax-content-part/purchase_item_variations', $data, true);
		}else{
			$content = $this->load->view('purchases/ajax-content-part/purchase_item_only', $data, true);
		}
		
		$result = array('status' => 'ok', 'content' => $content);
		echo json_encode($result);
		exit;
	}
	
	public function get_product_update_info()
	{
		$product_id = $this->input->post('id');
		$product_has_variations = $this->input->post('has_variations');
		$product_info = $this->Purchase_model->get_product_info($product_id);
		$selected_fields = array(
								'unit_id'             => html_escape($this->input->post('unit_id')),
								'qty'                 => html_escape($this->input->post('qty')),
								'purchase_price'      => html_escape($this->input->post('purchase_price')),
								'sale_price'          => html_escape($this->input->post('sale_price')),
								'profit_per_qty'      => html_escape($this->input->post('profit_per_qty')),
								'subtotal_amount'     => html_escape($this->input->post('subtotal_amount')),
								'row_number'          => html_escape($this->input->post('row_number')),
							);
		if($product_has_variations == 'YES')
		{
			$selected_fields['variation_id']        = html_escape($this->input->post('variation_id'));
			$selected_fields['variation_option_id'] = html_escape($this->input->post('variation_option_id'));
		}
		$data['product_info'] = array_merge($selected_fields, $product_info);
		if($product_info['product_has_variations'] == 'YES'){
			$content = $this->load->view('purchases/ajax-content-part/edit/purchase_item_variations', $data, true);
		}else{
			$content = $this->load->view('purchases/ajax-content-part/edit/purchase_item_only', $data, true);
		}
		
		$result = array('status' => 'ok', 'content' => $content);
		echo json_encode($result);
		exit;
	}
	
	public function addparticulars()
	{
		$product_id = $this->input->post('product_id');
		$product_info = $this->Purchase_model->get_product_info($product_id);
		if($product_info['product_type'] == 'GENERAL'){
			$photo_url = get_product_photo_url($product_info['product_id']);
		}else{
			$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
		}
		$purchase_variations = $this->input->post('purchase_variations');
		$purchase_has_variations = $this->input->post('purchase_has_variations');
		$content = '';
		if(is_array($purchase_variations) && count($purchase_variations) !== 0)
		{
			$x = $this->input->post('sl_number');
			foreach($purchase_variations as $row)
			{
				if($x < 10){
					$sl = '0'.$x;
				}else{
					$sl = $x;
				}
				if($purchase_has_variations == 'YES'){
					$provariation_id = $this->input->post('variation_id_'.$row);
					$variation_option_id = $this->input->post('variation_option_id_'.$row);
					$variant_name   = $this->Purchase_model->get_variant_name($provariation_id);
					$option_name   = $this->Purchase_model->get_option_name($variation_option_id);
					$variation_content = '<br /> <strong>Description :</strong> '.$variant_name.' : '.$option_name
										 .'<input type="hidden" name="item_provariation_id_'.$x.'" class="update-provariation-id-'.$x.'" value="'.$provariation_id.'" />
											<input type="hidden" name="item_variation_option_id_'.$x.'" class="update-variation-option-id-'.$x.'" value="'.$variation_option_id.'" />';
				}else{
					$variation_content = '';
				}
				$quantity    = $this->input->post('qty_'.$row);
				$unit_id     = $this->input->post('unit_id_'.$row);
				$unit_name   = $this->Purchase_model->get_unit_name($unit_id);
				$purchase_price = str_replace(',', '', $this->input->post('purchase_price_'.$row));
				$sale_price     = str_replace(',', '', $this->input->post('sale_price_'.$row));
				$profit_per_qty = $this->input->post('profit_per_qty_'.$row);
				$subtotal_amount = $this->input->post('subtotal_amount_'.$row);
				if($product_info['product_type'] == 'GENERAL'){
					$product_title = $product_info['product_name']; 
				}else{
					$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
					$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
				}
				$content .= '<tr class="particulars-item-row particulars-item-content-row-'.$x.'">
								<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
								<td>
									'.$product_title.'
									<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
									'.$variation_content.'
									<input type="hidden" name="item_product_id_'.$x.'" value="'.$product_id.'" />
								</td>
								<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
								<td class="text-center">
									'.$quantity.'
									<input type="hidden" name="item_quantity_'.$x.'" class="update-qty-'.$x.'" value="'.$quantity.'" />
								</td>
								<td class="text-center">
									'.$unit_name.'
									<input type="hidden" name="item_unit_id_'.$x.'" class="update-unit-id-'.$x.'" value="'.$unit_id.'" />
								</td>
								<td class="text-center">
									'.number_format($purchase_price, 0, '.', ',').'
									<input type="hidden" name="item_purchase_per_qty_'.$x.'" class="update-purchase-price-'.$x.'" value="'.$purchase_price.'" />
								</td>
								<td class="text-center">
									'.number_format($sale_price, 0, '.', ',').'
									<input type="hidden" name="item_sale_per_qty_'.$x.'" class="update-sale-price-'.$x.'" value="'.$sale_price.'" />
								</td>
								<td class="text-center">
									'.number_format($profit_per_qty, 0, '.', ',').'
									<input type="hidden" name="item_profit_per_qty_'.$x.'" class="update-profit-per-qty-'.$x.'" value="'.$profit_per_qty.'" />
								</td>
								<td class="text-center">
									'.number_format($subtotal_amount, 0, '.', ',').'
									<input type="hidden" class="subtotal-amounts update-subtotal-amounts-'.$x.'" name="item_subtotal_'.$x.'" value="'.$subtotal_amount.'" />
								</td>
								<td class="text-center">
									<div class="invoice-action">
									  <span class="invoice-action-edit cursor-pointer mr-1" title="Edit" data-product="'.$product_id.'" data-has-variations="'.$purchase_has_variations.'" data-row="'.$x. '" data-toggle="modal" data-target="#defaultUpdate"><i class="bx bx-edit"></i></span>
									  <span class="invoice-action-view remove-item-from-particulars cursor-pointer" style="color:#ff0000" title="Remove"><i class="bx bxs-x-circle"></i></span>
									</div>
								</td>
								<input type="hidden" name="item_has_variations_' .$x.'" value="'.$purchase_has_variations.'" />
								<input type="hidden" name="particular_items[]" value="'.$x.'" />
							</tr>';
				$x++;
			}
		}
		
		$result = array('status' => 'ok', 'content' => $content);
		echo json_encode($result);
		exit;
	}
	
	public function update_particulars()
	{
		$row_number = $this->input->post('row_number');
		$product_id = $this->input->post('product_id');
		$product_info = $this->Purchase_model->get_product_info($product_id);
		if($product_info['product_type'] == 'GENERAL'){
			$photo_url = get_product_photo_url($product_info['product_id']);
		}else{
			$photo_url = get_product_photo_url($product_info['product_id'], 'DRUGS');
		}
		$purchase_variations = $this->input->post('purchase_variations');
		$purchase_has_variations = $this->input->post('purchase_has_variations');
		$content = '';
		if(is_array($purchase_variations) && count($purchase_variations) !== 0)
		{
			$x = $row_number;
			foreach($purchase_variations as $row)
			{
				
				$sl = $x;
				if($purchase_has_variations == 'YES'){
					$provariation_id = $this->input->post('variation_id_'.$row);
					$variation_option_id = $this->input->post('variation_option_id_'.$row);
					$variant_name   = $this->Purchase_model->get_variant_name($provariation_id);
					$option_name   = $this->Purchase_model->get_option_name($variation_option_id);
					$variation_content = '<br /> <strong>Description :</strong> '.$variant_name.' : '.$option_name
										 .'<input type="hidden" name="item_provariation_id_'.$x.'" class="update-provariation-id-'.$x.'" value="'.$provariation_id.'" />
											<input type="hidden" name="item_variation_option_id_'.$x.'" class="update-variation-option-id-'.$x.'" value="'.$variation_option_id.'" />';
				}else{
					$variation_content = '';
				}
				$quantity    = $this->input->post('qty_'.$row);
				$unit_id     = $this->input->post('unit_id_'.$row);
				$unit_name   = $this->Purchase_model->get_unit_name($unit_id);
				$purchase_price = str_replace(',', '', $this->input->post('purchase_price_'.$row));
				$sale_price     = str_replace(',', '', $this->input->post('sale_price_'.$row));
				$profit_per_qty = $this->input->post('profit_per_qty_'.$row);
				$subtotal_amount = $this->input->post('subtotal_amount_'.$row);
				if($product_info['product_type'] == 'GENERAL'){
					$product_title = $product_info['product_name']; 
				}else{
					$product_title = '<strong>Brand : </strong>'.$product_info['drug_brand'].'<br />'; 
					$product_title .= '<strong>Dosages : </strong>'.$product_info['drug_dosages']; 
				}
				$content .= '<td class="text-bold-500 particulars-itm-sl">'.$sl.'</td>
							<td>
								'.$product_title.'
								<br style="margin-bottom:5px;" /> <strong>Serial No :</strong> '.$product_info['product_serial_number'].'
								'.$variation_content.'
								<input type="hidden" name="item_product_id_'.$x.'" value="'.$product_id.'" />
							</td>
							<td class="text-center"><img src="'.$photo_url.'" alt="PHOTO" style="height: 60px;width: 80px;border: 1px solid #ccc;padding: 2px;border-radius: 3px;" /></td>
							<td class="text-center">
								'.$quantity.'
								<input type="hidden" name="item_quantity_'.$x.'" class="update-qty-'.$x.'" value="'.$quantity.'" />
							</td>
							<td class="text-center">
								'.$unit_name.'
								<input type="hidden" name="item_unit_id_'.$x.'" class="update-unit-id-'.$x.'" value="'.$unit_id.'" />
							</td>
							<td class="text-center">
								'.number_format($purchase_price, 0, '.', ',').'
								<input type="hidden" name="item_purchase_per_qty_'.$x.'" class="update-purchase-price-'.$x.'" value="'.$purchase_price.'" />
							</td>
							<td class="text-center">
								'.number_format($sale_price, 0, '.', ',').'
								<input type="hidden" name="item_sale_per_qty_'.$x.'" class="update-sale-price-'.$x.'" value="'.$sale_price.'" />
							</td>
							<td class="text-center">
								'.number_format($profit_per_qty, 0, '.', ',').'
								<input type="hidden" name="item_profit_per_qty_'.$x.'" class="update-profit-per-qty-'.$x.'" value="'.$profit_per_qty.'" />
							</td>
							<td class="text-center">
								'.number_format($subtotal_amount, 0, '.', ',').'
								<input type="hidden" class="subtotal-amounts update-subtotal-amounts-'.$x.'" name="item_subtotal_'.$x.'" value="'.$subtotal_amount.'" />
							</td>
							<td class="text-center">
								<div class="invoice-action">
								  <span class="invoice-action-edit cursor-pointer mr-1" title="Edit" data-product="'.$product_id.'" data-has-variations="'.$purchase_has_variations.'" data-row="'.$x.'" data-toggle="modal" data-target="#defaultUpdate"><i class="bx bx-edit"></i></span>
								  <span class="invoice-action-view remove-item-from-particulars cursor-pointer" style="color:#F00" title="Remove"><i class="bx bxs-x-circle"></i></span>
								</div>
							</td>
							<input type="hidden" name="item_has_variations_'.$x.'" value="'.$purchase_has_variations.'" />
							<input type="hidden" name="particular_items[]" value="'.$x.'" />';
				$x++;
			}
		}
		
		$result = array('status' => 'ok', 'content' => $content, 'row_number' => $row_number);
		echo json_encode($result);
		exit;
	}
	
	public function get_product_variations()
	{
		$product_id = $this->input->post('product_id');
		$get_selected_variations = $this->input->post('selected_variations');
		$selected_variations = array_count_values($get_selected_variations);
		$variations = $this->Purchase_model->get_all_product_variations($product_id);
		$content = '';
		if(is_array($variations) && count($variations) !== 0)
		{
			foreach($variations as $variation):
			$total_options = $this->Purchase_model->get_all_product_variation_options_count($variation['provariation_id'], $product_id);
			if(array_key_exists($variation['provariation_id'], $selected_variations) && $total_options == $selected_variations[$variation['provariation_id']])
			{
				continue;
			}
			$content .= '<option value="'.$variation['provariation_id'].'">'.$variation['variation_name'].'</option>';
		endforeach;
		}
		echo $content;
	}
	
	public function create()
	{
		$items = $this->input->post('particular_items');
		if(is_array($items) && count($items) == 0)
		{
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no product has been selected!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert);
			echo json_encode($result);
			exit;
		}else if(!isset($items)){
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no product has been selected!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert);
			echo json_encode($result);
			exit;
		}
		
		$invoice_ID = $this->Purchase_model->get_last_invoice_id();
		$order_ID = $this->Purchase_model->get_last_order_id();
		$padding_number = str_pad($invoice_ID, 6, '0', STR_PAD_LEFT);
		$invoice_no = date("ynj").$padding_number;
		$po_no      = date("ymd").$order_ID;
		
		//Formatted ID
		$padding_1 = str_pad(date("y"), 3, '0', STR_PAD_LEFT);
		$padding_2 = str_pad(date("m"), 3, '0', STR_PAD_LEFT);
		$padding_3 = str_pad(date("d"), 5, '0', STR_PAD_LEFT);
		
		$formatted_id = 'PO-'.$padding_1.'-'.$padding_2.'-'.$padding_3.'-'.$order_ID;
		$invoice_formatted_id = 'PI-'.$padding_1.'-'.$padding_2.'-'.$padding_3.'-'.$invoice_ID;
		
		//Purchase order informations
		$order_data = array(
							'order_branch_id'      => $this->input->post('branch'),
							'order_warehouse_id'   => $this->input->post('warehouse'),
							'order_formatted_id'   => $formatted_id,
							'order_number'         => $po_no,
							'order_date'           => date("Y-m-d", strtotime($this->input->post('order_date'))),
							'order_supplier_id'    => html_escape($this->input->post('supplier_id')),
							'order_reference_type' => html_escape($this->input->post('reference_type')),
							'order_reference_no'   => html_escape($this->input->post('reference_no')),
							'order_terms'          => html_escape($this->input->post('terms')),
							'order_remarks'        => html_escape($this->input->post('remarks')),
							'order_created_date'   => date("Y-m-d H:i:s"),
							'order_updated_date'   => date("Y-m-d H:i:s"),
							'order_created_by'     => $this->session->userdata('active_admin'),
							'order_updated_by'     => $this->session->userdata('active_admin'),
					  );
		$get_insert_id = $this->Purchase_model->save_purchase_order_data($order_data);
		$order_id = $this->db->insert_id($get_insert_id);
		
		//Purchase order summery information
		$order_summery_data = array(
									'osummery_order_id'         => $order_id,
									'osummery_supplier_id'      => html_escape($this->input->post('supplier_id')),
									'osummery_subtotal'         => number_format(floatval(str_replace(',', '', html_escape($this->input->post('subtotal')))), 0, '', ''),
									'osummery_shipping_cost'    => number_format(floatval(str_replace(',', '', html_escape($this->input->post('shipping_cost')))), 0, '', ''),
									'osummery_tax_type'         => html_escape($this->input->post('tax_type')),
									'osummery_tax_value'        => number_format(floatval(str_replace(',', '', html_escape($this->input->post('tax_value')))), 0, '', ''),
									'osummery_tax_amount_total' => number_format(floatval(str_replace(',', '', html_escape($this->input->post('tax_amount_total')))), 0, '', ''),
									'osummery_vat_type'         => html_escape($this->input->post('vat_type')),
									'osummery_vat_value'        => number_format(floatval(str_replace(',', '', html_escape($this->input->post('vat_value')))), 0, '', ''),
									'osummery_vat_amount_total' => number_format(floatval(str_replace(',', '', html_escape($this->input->post('vat_amount_total')))), 0, '', ''),
									'osummery_total_amount'     => html_escape($this->input->post('total_amount')),
									'osummery_discount_total'   => number_format(floatval(str_replace(',', '', html_escape($this->input->post('discount')))), 0, '', ''),
									'osummery_net_total'        => html_escape($this->input->post('net_total')),
							  );
		$get_summery_id = $this->Purchase_model->save_purchase_order_summery_data($order_summery_data);
		$osummery_id = $this->db->insert_id($get_summery_id);
		
		//Purchase order items information
		if(is_array($items) && count($items) !== 0)
		{
			foreach($items as $row)
			{
				$poitem_product_id          = html_escape($this->input->post('item_product_id_'.$row));
				$poitem_has_variations      = html_escape($this->input->post('item_has_variations_'.$row));
				$poitem_quantity            = html_escape($this->input->post('item_quantity_'.$row));
				$poitem_unit_id             = html_escape($this->input->post('item_unit_id_'.$row));
				$poitem_purchase_per_qty    = html_escape($this->input->post('item_purchase_per_qty_'.$row));
				$poitem_sale_per_qty     	= html_escape($this->input->post('item_sale_per_qty_'.$row));
				$poitem_profit_per_qty      = html_escape($this->input->post('item_profit_per_qty_'.$row));
				$poitem_subtotal            = html_escape($this->input->post('item_subtotal_'.$row));
				
				$order_items_data = array(
										  'oitem_order_id'            => $order_id,
										  'oitem_supplier_id'         => html_escape($this->input->post('supplier_id')),
										  'oitem_product_id'          => $poitem_product_id,
										  'oitem_quantity'            => $poitem_quantity,
										  'oitem_unit_id'             => $poitem_unit_id,
										  'oitem_purchase_per_qty'    => $poitem_purchase_per_qty,
										  'oitem_sale_per_qty'        => $poitem_sale_per_qty,
										  'oitem_profit_per_qty'      => $poitem_profit_per_qty,
										  'oitem_subtotal'            => $poitem_subtotal,
									);
				//Stock data
				$stock_data = array(
									'stock_order_id'   => $order_id,
									'stock_product_id' => $poitem_product_id,
									'stock_qty'        => $poitem_quantity,
									'stock_unit_id'    => $poitem_unit_id,
								);
				
				if($poitem_has_variations == 'YES')
				{
					$poitem_variation_id        = html_escape($this->input->post('item_provariation_id_'.$row));
					$poitem_variation_option_id = html_escape($this->input->post('item_variation_option_id_'.$row));
					$order_items_data['oitem_provariation_id']     = $poitem_variation_id;
					$order_items_data['oitem_variation_option_id'] = $poitem_variation_option_id;
					
					//Stock variations
					$variation_id = $this->Purchase_model->get_variation_id($poitem_variation_id, $poitem_product_id);
					$stock_data['stock_has_variations']      = 'YES';
					$stock_data['stock_variation_id']        = $variation_id;
					$stock_data['stock_variation_option_id'] = $poitem_variation_option_id;
				}else{
					$stock_data['stock_has_variations'] = 'NO';
				}
				$this->Purchase_model->save_purchase_order_items_data($order_items_data);
				$this->Purchase_model->save_stocks_data($stock_data);
			}
		}
		
		//Purchase order invoice information
		$order_invoice_data = array(
									'invoice_formatted_id' => $invoice_formatted_id,
									'invoice_order_id'     => $order_id,
									'invoice_number'       => $invoice_no,
									'invoice_type'         => 'PURCHASE',
									'invoice_date'         => date("Y-m-d", strtotime($this->input->post('invoice_date'))),
							  );
		$get_invoice_id = $this->Purchase_model->save_purchase_order_invoice_data($order_invoice_data);
		$invoice_id = $this->db->insert_id($get_invoice_id);
		
		//Save order due information
		$due_infos = array(
						'odueinfo_osummery_id'  => $osummery_id,
						'odueinfo_order_id'     => $order_id,
						'odueinfo_invoice_id'   => $invoice_id,
						'odueinfo_supplier_id'  => html_escape($this->input->post('supplier_id')),
						'odueinfo_due_total'    => html_escape($this->input->post('net_total')),
						'odueinfo_created_date' => date("Y-m-d H:i:s"),
						'odueinfo_updated_date' => date("Y-m-d H:i:s"),
					);
		$this->Purchase_model->save_order_due_infos($due_infos);
		
		//Save invoice history info
		$invoice_history = array(
								'invhistory_invoice_id'   => $invoice_id,
								'invhistory_status'       => 'CREATE',
								'invhistory_created_date' => date("Y-m-d H:i:s"),
								'invhistory_created_by'   => $this->session->userdata('active_admin'),
							);
		$this->Purchase_model->save_invoice_histories($invoice_history);
		
		//check supplier balance
		$balance_info = get_the_supplier_balance($this->input->post('supplier_id'));
		if($balance_info['balance_type'] == 'ADVANCE'){
			if($balance_info['balance_amount'] < $this->input->post('net_total'))
			{
				$due_paid_total = $balance_info['balance_amount'];
			}else{
				$due_paid_total = $this->input->post('net_total');
			}
		}else{
			$due_paid_total = 0;
		}
		
		//save payment invoices
		$payment_invoice_data = array(
									'pinvoice_paid_by'        => 'ADJUSTMENT',
									'pinvoice_invoice_id'     => $invoice_id,
									'pinvoice_order_id'       => $order_id,
									'pinvoice_payment_amount' => $due_paid_total,
								);
		pay_to_invoice_by_supplier_balance($payment_invoice_data);
		
		//Save supplier due payments info
		$due_payment_data = array(
								'due_supplier_id'       => $this->input->post('supplier_id'),
								'due_invoice_id'        => $invoice_id,
								'due_order_id'          => $order_id,
								'due_invoice_net_total' => $this->input->post('net_total'),
								'due_created_date'      => date("Y-m-d H:i:s"),
								'due_updated_date'      => date("Y-m-d H:i:s"),
								'due_created_by'        => $this->session->userdata('active_admin'),
								'due_updated_by'        => $this->session->userdata('active_admin'),
							);
		$this->transactions->save_suppliers_payments_dues($due_payment_data, $invoice_no);
		
		$due_status_data = array(
								'due_paid_total'        => invoice_paid_total($invoice_id),
								'due_amount_total'      => invoice_due_total($invoice_id),
								'due_status'            => invoice_payment_status($invoice_id),
							);
		update_invoice_due_status($invoice_id, $due_status_data);
				
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Purchase order information has been successfully saved.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, 'formatted_id' => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function update()
	{
		$order_id = $this->input->post('id');
		$formatted_id = $this->input->post('fid');
		$invoice_id = $this->input->post('invoice');
		$items = $this->input->post('particular_items');
		if(is_array($items) && count($items) == 0)
		{
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no product has been selected!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert);
			echo json_encode($result);
			exit;
		}else if(!isset($items)){
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no product has been selected!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert);
			echo json_encode($result);
			exit;
		}
		
		//Purchase order informations
		$order_data = array(
							'order_branch_id'      => $this->input->post('branch'),
							'order_warehouse_id'   => $this->input->post('warehouse'),
							'order_date'           => date("Y-m-d", strtotime($this->input->post('order_date'))),
							'order_supplier_id'    => html_escape($this->input->post('supplier_id')),
							'order_reference_type' => html_escape($this->input->post('reference_type')),
							'order_reference_no'   => html_escape($this->input->post('reference_no')),
							'order_terms'          => html_escape($this->input->post('terms')),
							'order_remarks'        => html_escape($this->input->post('remarks')),
							'order_updated_date'   => date("Y-m-d H:i:s"),
							'order_updated_by'     => $this->session->userdata('active_admin'),
					  );
		$this->Purchase_model->update_purchase_order_data($order_id, $order_data);
		
		//Purchase order summery information
		$order_summery_data = array(
									'osummery_subtotal'         => number_format(floatval(str_replace(',', '', html_escape($this->input->post('subtotal')))), 0, '', ''),
									'osummery_shipping_cost'    => number_format(floatval(str_replace(',', '', html_escape($this->input->post('shipping_cost')))), 0, '', ''),
									'osummery_tax_type'         => html_escape($this->input->post('tax_type')),
									'osummery_tax_value'        => number_format(floatval(str_replace(',', '', html_escape($this->input->post('tax_value')))), 0, '', ''),
									'osummery_tax_amount_total' => number_format(floatval(str_replace(',', '', html_escape($this->input->post('tax_amount_total')))), 0, '', ''),
									'osummery_vat_type'         => html_escape($this->input->post('vat_type')),
									'osummery_vat_value'        => number_format(floatval(str_replace(',', '', html_escape($this->input->post('vat_value')))), 0, '', ''),
									'osummery_vat_amount_total' => number_format(floatval(str_replace(',', '', html_escape($this->input->post('vat_amount_total')))), 0, '', ''),
									'osummery_total_amount'     => html_escape($this->input->post('total_amount')),
									'osummery_discount_total'   => number_format(floatval(str_replace(',', '', html_escape($this->input->post('discount')))), 0, '', ''),
									'osummery_net_total'        => html_escape($this->input->post('net_total')),
							  );
		$this->Purchase_model->update_purchase_order_summery_data($order_id, $order_summery_data);
		
		//Delete old order items
		$this->Purchase_model->delete_purchase_order_items_data($order_id);
		
		//Delete old data using purchase id
		$this->Purchase_model->delete_old_purchase_stock($order_id);
		
		//Purchase order items information
		if(is_array($items) && count($items) !== 0)
		{
			foreach($items as $row)
			{
				$poitem_product_id          = html_escape($this->input->post('item_product_id_'.$row));
				$poitem_has_variations      = html_escape($this->input->post('item_has_variations_'.$row));
				$poitem_quantity            = html_escape($this->input->post('item_quantity_'.$row));
				$poitem_unit_id             = html_escape($this->input->post('item_unit_id_'.$row));
				$poitem_purchase_per_qty    = html_escape($this->input->post('item_purchase_per_qty_'.$row));
				$poitem_sale_per_qty     	= html_escape($this->input->post('item_sale_per_qty_'.$row));
				$poitem_profit_per_qty      = html_escape($this->input->post('item_profit_per_qty_'.$row));
				$poitem_subtotal            = html_escape($this->input->post('item_subtotal_'.$row));
				
				$order_items_data = array(
										  'oitem_order_id'            => $order_id,
										  'oitem_supplier_id'         => html_escape($this->input->post('supplier_id')),
										  'oitem_product_id'          => $poitem_product_id,
										  'oitem_quantity'            => $poitem_quantity,
										  'oitem_unit_id'             => $poitem_unit_id,
										  'oitem_purchase_per_qty'    => $poitem_purchase_per_qty,
										  'oitem_sale_per_qty'        => $poitem_sale_per_qty,
										  'oitem_profit_per_qty'      => $poitem_profit_per_qty,
										  'oitem_subtotal'            => $poitem_subtotal,
									);
				
				//Stock data
				$stock_data = array(
									'stock_order_id'   => $order_id,
									'stock_product_id' => $poitem_product_id,
									'stock_qty'        => $poitem_quantity,
									'stock_unit_id'    => $poitem_unit_id,
								);
				
				if($poitem_has_variations == 'YES')
				{
					$poitem_variation_id        = html_escape($this->input->post('item_provariation_id_'.$row));
					$poitem_variation_option_id = html_escape($this->input->post('item_variation_option_id_'.$row));
					$order_items_data['oitem_provariation_id']     = $poitem_variation_id;
					$order_items_data['oitem_variation_option_id'] = $poitem_variation_option_id;
					
					//Stock variations
					$variation_id = $this->Purchase_model->get_variation_id($poitem_variation_id, $poitem_product_id);
					$stock_data['stock_has_variations']      = 'YES';
					$stock_data['stock_variation_id']        = $variation_id;
					$stock_data['stock_variation_option_id'] = $poitem_variation_option_id;
				}else{
					$stock_data['stock_has_variations'] = 'NO';
				}
				$this->Purchase_model->save_purchase_order_items_data($order_items_data);
				$this->Purchase_model->save_stocks_data($stock_data);
			}
		}
		
		//Purchase order invoice information
		$order_invoice_data = array(
									'invoice_date'         => date("Y-m-d", strtotime($this->input->post('invoice_date'))),
									);
		$this->Purchase_model->update_purchase_order_invoice_data($order_id, $order_invoice_data);
		
		//Save order due information
		$due_infos = array(
						'odueinfo_due_total'    => html_escape($this->input->post('net_total')),
						'odueinfo_updated_date' => date("Y-m-d H:i:s"),
					);
		$this->Purchase_model->update_order_due_infos($order_id, $due_infos);
		
		//Save invoice history info
		$invoice_history = array(
								'invhistory_invoice_id'   => $invoice_id,
								'invhistory_status'       => 'UPDATE',
								'invhistory_updated_date' => date("Y-m-d H:i:s"),
								'invhistory_updated_by'   => $this->session->userdata('active_admin'),
							);
		$this->Purchase_model->save_invoice_histories($invoice_history);
		
		
		//first update supplier payment dues
		$supplier_id = $this->input->post('supplier_id');
		$supplier_due_info = $this->Purchase_model->get_supplier_due_info($invoice_id, $order_id);
		
		//check supplier balance
		$balance_info = get_the_supplier_balance($this->input->post('supplier_id'));
		if($balance_info['balance_type'] == 'ADVANCE'){
			if($balance_info['balance_amount'] < $this->input->post('net_total'))
			{
				$due_paid_total = floatval($supplier_due_info['due_paid_total']) + floatval($balance_info['balance_amount']);
			}else{
				$due_paid_total = $this->input->post('net_total');
			}
			$due_amount_total = floatval($this->input->post('net_total')) - floatval($due_paid_total);
		}else{
			$due_paid_total = 0;
			$due_amount_total = $this->input->post('net_total');
		}
		
		//Save supplier due payments info
		$due_payment_data = array(
								'due_supplier_id'       => $supplier_due_info['due_supplier_id'],
								'due_transaction_id'    => $supplier_due_info['due_transaction_id'],
								'due_invoice_net_total' => $this->input->post('net_total'),
								'due_paid_total'        => $due_paid_total,
								'due_amount_total'      => $due_amount_total,
								'due_status'            => ($due_amount_total == 0)? 'PAID' : 'DUE',
								'due_updated_date'      => date("Y-m-d H:i:s"),
								'due_updated_by'        => $this->session->userdata('active_admin'),
							);
		$this->transactions->update_suppliers_payments_dues($invoice_id, $order_id, $due_payment_data);
				
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Purchase order information has been successfully updated.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, 'formatted_id' => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	private function update_payment_dues($due_id, $data)
	{
		$this->db->where('due_id', $due_id);
		$this->db->update('saams_suppliers_payments_dues', $data);
	}
	
	public function get_product_variation_options()
	{
		$selected_variation_options = $this->input->post('selected_variation_options');
		$variation_id = $this->input->post('variation_id');
		$row_number = $this->input->post('row_number');
		$variation_product_id = $this->input->post('variation_product_id');
		$options = $this->Purchase_model->get_all_product_variation_options($variation_id, $variation_product_id);
		$content = '<option value="">Select Option</option>';
		foreach($options as $option)
		{
			if(is_array($selected_variation_options) && count($selected_variation_options) !== 0 && in_array($option['option_id'], $selected_variation_options))
			{
				continue;
			}
			$content .= '<option value="'.$option['option_id'].'">'.$option['option_name'].'</option>';
		}
		$result = array("status" => "ok", "content" => $content, 'row_number' => $row_number);
		echo json_encode($result);
		exit;
	}
	
	public function get_product_price_info()
	{
		$provariation_id      = $this->input->post('provariation_id');
		$variation_product_id = $this->input->post('variation_product_id');
		$variation_id         = $this->Purchase_model->get_variation_id($provariation_id, $variation_product_id);
		$option_id            = $this->input->post('option_id');
		
		$product_price_info = $this->Purchase_model->get_product_price_info($provariation_id, $variation_product_id, $variation_id, $option_id);
		$result = array("status" => "ok", "purchase_price" => number_format(floatval($product_price_info['priceinfo_purchase_price']), 0, '.', ','), 'sale_price' => number_format(floatval($product_price_info['priceinfo_sale_price']), 0, '.', ','));
		echo json_encode($result);
		exit;
	}
	
	public function delete()
	{
		$order_id = $this->input->post('id');
		$invoice_id = $this->input->post('invoice');
		//Update order 
		$order_data = array(
							'order_has_deleted' => 'YES',
							'order_deleted_by'  => $this->session->userdata('active_admin'),
						);
		$this->Purchase_model->update_purchase_order_data($order_id, $order_data);
		
		//Update stock 
		$stock_data = array(
							'stock_has_deleted' => 'YES',
							'stock_deleted_by'  => $this->session->userdata('active_admin'),
						);
		$this->Purchase_model->update_stock_data($order_id, $stock_data);
		
		//Update invoice
		$order_invoice_data = array(
									'invoice_has_deleted' => 'YES',
									'invoice_deleted_by'  => $this->session->userdata('active_admin'),
									);
		$this->Purchase_model->update_purchase_order_invoice_data($order_id, $order_invoice_data);
		
		//Save invoice history info
		$invoice_history = array(
								'invhistory_invoice_id'   => $invoice_id,
								'invhistory_status'       => 'DELETE',
								'invhistory_delete_date'  => date("Y-m-d H:i:s"),
								'invhistory_deleted_by'   => $this->session->userdata('active_admin'),
							);
		$this->Purchase_model->save_invoice_histories($invoice_history);
		
		//Delete supplier due payments info
		$supplier_due_info = $this->Purchase_model->get_supplier_due_info($invoice_id, $order_id);
		$due_payment_data = array(
								'due_supplier_id'       => $supplier_due_info['due_supplier_id'],
								'due_transaction_id'    => $supplier_due_info['due_transaction_id'],
								'due_invoice_net_total' => $supplier_due_info['due_invoice_net_total'],
								'due_has_deleted'        => 'YES',
								'due_has_deleted_by'     => $this->session->userdata('active_admin')
							);
		$this->transactions->delete_suppliers_payments_dues($invoice_id, $order_id, $due_payment_data);
		
		$result = array("status" => "ok");
		echo json_encode($result);
		exit;
	}
	
}
