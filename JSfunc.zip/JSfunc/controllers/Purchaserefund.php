<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchaserefund extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$active_user = $this->session->userdata('active_admin');
		$userLogin = $this->session->userdata('userLogin');
		if($active_user === NULL && $userLogin !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		$this->load->library('ajax_pagination');
		$this->perPage = 10;
		$this->load->model('Purchaserefund_model');
	}
	
	public function index()
	{
		$data = array();
        
		//total rows count
		$totalRec = $this->Purchaserefund_model->count_all_refunds();
		
		//pagination configuration
		$config['target']      = '#postList';
		$config['base_url']    = base_url().'apiv1/get_purchases';
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		$config['link_func']   = 'searchFilter';
		$this->ajax_pagination->initialize($config);
		
		//get the posts data
		$data['items'] = $this->Purchaserefund_model->get_all_refunds(array('limit'=>$this->perPage));
		
		$this->load->view('purchases-refunds/index', $data);
	}
	
	public function add()
	{
		$this->load->view('purchases-refunds/create');
	}
	
	public function edit($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchaserefund_model->get_refund_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['refund_info'] = $is_info_exist;
				$this->load->view('purchases-refunds/edit', $data);
			}else{
				redirect('purchase/purchaserefund', 'refresh', true);
			}
		}else{
			redirect('purchase/purchaserefund', 'refresh', true);
		}
	}
	
	public function view($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchaserefund_model->get_refund_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['refund_info'] = $is_info_exist;
				$this->load->view('purchases-refunds/details', $data);
			}else{
				redirect('purchase/purchaserefund', 'refresh', true);
			}
		}else{
			redirect('purchase/purchaserefund', 'refresh', true);
		}
	}
	
	public function download($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchaserefund_model->get_refund_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$file_name = 'purchase_refund_'.$is_info_exist['refund_voucher_number'].'_'.date("d-m-Y_H_i_s_A").'.pdf';
				if(isset($_GET['TYPE']) && $_GET['TYPE'] == 'DETAILS'){
					$content = $this->load->view('purchases-refunds/details_pdf', $is_info_exist, true);
					$pdf_serial_field_name = 'refund_details_pdf_serial';
				}elseif(isset($_GET['TYPE']) && $_GET['TYPE'] == 'VOUCHAR'){
					$content = $this->load->view('purchases-refunds/vouchar_pdf', $is_info_exist, true);
					$pdf_serial_field_name = 'refund_vouchar_pdf_serial';
				}else{
					$content = $this->load->view('purchases-refunds/details_pdf', $is_info_exist, true);
					$pdf_serial_field_name = 'refund_details_pdf_serial';
				}
				$params = array_merge($is_info_exist, array(
															'primary_field_id'      => $is_info_exist['refund_id'], 
															'content'               => $content, 
															'pdf_serial_field_name' => $pdf_serial_field_name, 
															'subject'               => 'PURCHASE_REFUND',
															'file_name'             => $file_name
														));
				$this->pdf->download($params);
			}else{
				redirect('purchase/purchaserefund', 'refresh', true);
			}
		}else{
			redirect('purchase/purchaserefund', 'refresh', true);
		}
	}
	
	public function vouchar($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Purchaserefund_model->get_refund_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['refund_info'] = $is_info_exist;
				$this->load->view('purchases-refunds/vouchar', $data);
			}else{
				redirect('purchase/purchaserefund', 'refresh', true);
			}
		}else{
			redirect('purchase/purchaserefund', 'refresh', true);
		}
	}
	
	public function getinvoiceinfo()
	{
		$order_id = $this->input->post('id');
		$order_info = $this->Purchaserefund_model->get_order_info($order_id);
		$data['order_info'] = $order_info;
		$content = $this->load->view('purchases-refunds/ajax-content-part/invoice_items_details', $data, true);
		
		$result = array('status' => 'ok', 'content' => $content);
		echo json_encode($result);
		exit;
		
	}
	
	public function srcinvoices()
	{
		$keywords = html_escape($this->input->get('q'));
		$datas = $this->Purchaserefund_model->src_invoice_by_keywords($keywords);
		$content = array();
		foreach($datas as $data):
			$content[] = array("label" => $data['invoice_number'], "supplier" => $data['supplier_name'], "value" => intval($data['order_id']));
		endforeach;
		
		echo json_encode(array('content' => $content));
		exit;
	}
	
	public function create()
	{
		$supplier_id     = html_escape($this->input->post('supplier_id'));
		$order_id        = html_escape($this->input->post('order_id'));

		$items = $this->input->post('particular_items');
		if(is_array($items) && count($items) == 0)
		{
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no items found to refund!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert, 'posts' => $this->input->post());
			echo json_encode($result);
			exit;
		}elseif(!isset($items)){
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no items found to refund!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert, 'posts' => $this->input->post());
			echo json_encode($result);
			exit;
		}
		
		$refund_ID = $this->Purchaserefund_model->get_last_refund_id();
		//Formatted ID
		$padding_1 = str_pad(date("y"), 3, '0', STR_PAD_LEFT);
		$padding_2 = str_pad(date("m"), 3, '0', STR_PAD_LEFT);
		$padding_3 = str_pad(date("d"), 5, '0', STR_PAD_LEFT);
		
		$formatted_id = 'POR-'.$padding_1.'-'.$padding_2.'-'.$padding_3.'-'.$refund_ID;
		$voucher_no   = date("Ymd").$refund_ID;
		
		//Save refund informations
		$refund_informations = array(
									'refund_branch_id'      => $this->input->post('branch'),
									'refund_warehouse_id'   => $this->input->post('warehouse'),
									'refund_formatted_id'   => $formatted_id,
									'refund_voucher_number' => $voucher_no,
									'refund_supplier_id'    => $supplier_id,
									'refund_invoice_id'     => html_escape($this->input->post('invoice_id')),
									'refund_order_id'       => $order_id,
									'refund_date'           => date("Y-m-d", strtotime($this->input->post('refund_date'))),
									'refund_terms'          => html_escape($this->input->post('terms')),
									'refund_remarks'        => html_escape($this->input->post('remarks')),
									'refund_amount_total'   => number_format(str_replace(',', '', html_escape($this->input->post('refund_amount_total'))), 0, '', ''),
									'refund_charge_total'   => html_escape($this->input->post('refund_net_profit')),
									'refund_net_total'      => html_escape($this->input->post('refund_net_total')),
									'refund_net_profit'     => html_escape($this->input->post('refund_net_profit')),
									'refund_payment_type'   => $this->input->post('payment_refund_type'),
									'refund_created_date'   => date("Y-m-d H:i:s"),
									'refund_updated_date'   => date("Y-m-d H:i:s"),
									'refund_created_by'     => $this->session->userdata('active_admin'),
									'refund_updated_by'     => $this->session->userdata('active_admin'),
								);
		$get_refund_id = $this->Purchaserefund_model->save_refund_information($refund_informations);
		$refund_id = $this->db->insert_id($get_refund_id);
		
		//Save refund items informations
		if(is_array($items) && count($items) !== 0)
		{
			foreach($items as $row)
			{
				$refitem_product_id          = html_escape($this->input->post('item_product_id_'.$row));
				$poitem_has_variations       = html_escape($this->input->post('item_has_variations_'.$row));
				$refitem_quantity            = html_escape($this->input->post('item_quantity_'.$row));
				$refitem_unit_id             = html_escape($this->input->post('item_unit_id_'.$row));
				$refitem_purchase_per_qty    = html_escape($this->input->post('item_purchase_per_qty_'.$row));
				$refitem_refund_qty     	 = html_escape($this->input->post('item_refund_qty_'.$row));
				$refitem_refund_charge       = number_format(str_replace(',', '', html_escape($this->input->post('item_refund_charge_'.$row))), 0, '', '');
				$refitem_refund_amount       = html_escape($this->input->post('item_refund_amount_'.$row));
				$refitem_refund_profit       = $refitem_refund_charge;
				$refitem_refund_subtotal     = html_escape($this->input->post('item_refund_subtotal_'.$row));
				
				$order_items_data = array(
										  'refitem_refund_id'           => $refund_id,
										  'refitem_order_id'            => $order_id,
										  'refitem_supplier_id'         => $supplier_id,
										  'refitem_product_id'          => $refitem_product_id,
										  'refitem_quantity'            => $refitem_quantity,
										  'refitem_unit_id'             => $refitem_unit_id,
										  'refitem_purchase_per_qty'    => $refitem_purchase_per_qty,
										  'refitem_refund_qty'          => $refitem_refund_qty,
										  'refitem_refund_charge'       => $refitem_refund_charge,
										  'refitem_refund_amount'       => $refitem_refund_amount,
										  'refitem_refund_profit'       => $refitem_refund_profit,
										  'refitem_refund_subtotal'     => $refitem_refund_subtotal,
									);
				//Stock data
				$stock_data = array(
									'stock_return_order_id'   => $order_id,
									'stock_return_refund_id'  => $refund_id,
									'stock_return_product_id' => $refitem_product_id,
									'stock_return_qty'        => $refitem_refund_qty,
									'stock_return_unit_id'    => $refitem_unit_id,
								);
								
				if($poitem_has_variations == 'YES')
				{
					$poitem_variation_id        = html_escape($this->input->post('item_provariation_id_'.$row));
					$variation_id               = $this->Purchaserefund_model->get_variation_id($poitem_variation_id, $refitem_product_id);
					$poitem_variation_option_id = html_escape($this->input->post('item_variation_option_id_'.$row));
					$order_items_data['refitem_provariation_id']     = $poitem_variation_id;
					$order_items_data['refitem_variation_id']        = $variation_id;
					$order_items_data['refitem_variation_option_id'] = $poitem_variation_option_id;
					
					//Stock variations
					$stock_data['stock_return_has_variations']      = 'YES';
					$stock_data['stock_return_variation_id']        = $variation_id;
					$stock_data['stock_return_variation_option_id'] = $poitem_variation_option_id;
				}else{
					$stock_data['stock_return_has_variations'] = 'NO';
				}
				$this->Purchaserefund_model->save_purchase_refund_items_data($order_items_data);
				$this->Purchaserefund_model->save_stocks_data($stock_data);
			}
		}
		$refunds_params = array(
							'refund_id' => $refund_id,
							'order_invoice_id'  => html_escape($this->input->post('invoice_id')),
							'order_id'  => $order_id
						);
		$this->transactions->save_suppliers_payments_refunds($refunds_params, $voucher_no);

		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Refund voucher has been successfully created.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, 'formatted_id' => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function update()
	{
		$prefund_id = $this->input->post('prefund_id');
		$refund_id = $this->input->post('refund_id');
		$order_id = $this->input->post('order_id');
		$formatted_id = $this->input->post('refund_fid');
		$items = $this->input->post('particular_items');
		if(is_array($items) && count($items) == 0)
		{
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no items found to refund!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert);
			echo json_encode($result);
			exit;
		}else if(!isset($items)){
			$alert = '<div class="alert alert-danger alert-dismissible mb-2" role="alert">
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						  </button>
						  <div class="d-flex align-items-center">
							<i class="bx bx-like"></i>
							<span>
							  Ohh! no items found to refund!
							</span>
						  </div>
						</div>';
			$result = array("status" => "error", "alert" => $alert);
			echo json_encode($result);
			exit;
		}
		
		//Save refund informations
		$refund_informations = array(
									'refund_branch_id'      => $this->input->post('branch'),
									'refund_warehouse_id'   => $this->input->post('warehouse'),
									'refund_date'           => date("Y-m-d", strtotime($this->input->post('refund_date'))),
									'refund_terms'          => html_escape($this->input->post('terms')),
									'refund_remarks'        => html_escape($this->input->post('remarks')),
									'refund_amount_total'   => number_format(str_replace(',', '', html_escape($this->input->post('refund_amount_total'))), 0, '', ''),
									'refund_charge_total'   => html_escape($this->input->post('refund_net_profit')),
									'refund_net_total'      => html_escape($this->input->post('refund_net_total')),
									'refund_net_profit'     => html_escape($this->input->post('refund_net_profit')),
									'refund_payment_type'   => $this->input->post('payment_refund_type'),
									'refund_updated_date'   => date("Y-m-d H:i:s"),
									'refund_updated_by'     => $this->session->userdata('active_admin'),
								);
		$this->Purchaserefund_model->update_refund_information($refund_id, $refund_informations);
		
		//Delete old refund items
		$this->Purchaserefund_model->delete_purchase_refund_items_data($refund_id);
		
		//Delete old data using purchase id
		$this->Purchaserefund_model->delete_old_purchase_stock($refund_id);
		
		//Save refund items informations
		if(is_array($items) && count($items) !== 0)
		{
			foreach($items as $row)
			{
				$refitem_product_id          = html_escape($this->input->post('item_product_id_'.$row));
				$poitem_has_variations       = html_escape($this->input->post('item_has_variations_'.$row));
				$refitem_quantity            = html_escape($this->input->post('item_quantity_'.$row));
				$refitem_unit_id             = html_escape($this->input->post('item_unit_id_'.$row));
				$refitem_purchase_per_qty    = html_escape($this->input->post('item_purchase_per_qty_'.$row));
				$refitem_refund_qty     	 = html_escape($this->input->post('item_refund_qty_'.$row));
				$refitem_refund_charge       = number_format(str_replace(',', '', html_escape($this->input->post('item_refund_charge_'.$row))), 0, '', '');
				$refitem_refund_amount       = html_escape($this->input->post('item_refund_amount_'.$row));
				$refitem_refund_profit       = $refitem_refund_charge;
				$refitem_refund_subtotal     = html_escape($this->input->post('item_refund_subtotal_'.$row));
				
				$order_items_data = array(
										  'refitem_refund_id'           => $refund_id,
										  'refitem_order_id'            => $order_id,
										  'refitem_supplier_id'         => html_escape($this->input->post('supplier_id')),
										  'refitem_product_id'          => $refitem_product_id,
										  'refitem_quantity'            => $refitem_quantity,
										  'refitem_unit_id'             => $refitem_unit_id,
										  'refitem_purchase_per_qty'    => $refitem_purchase_per_qty,
										  'refitem_refund_qty'          => $refitem_refund_qty,
										  'refitem_refund_charge'       => $refitem_refund_charge,
										  'refitem_refund_amount'       => $refitem_refund_amount,
										  'refitem_refund_profit'       => $refitem_refund_profit,
										  'refitem_refund_subtotal'     => $refitem_refund_subtotal,
									);
				
				//Stock data
				$stock_data = array(
									'stock_return_order_id'   => $order_id,
									'stock_return_refund_id'  => $refund_id,
									'stock_return_product_id' => $refitem_product_id,
									'stock_return_qty'        => $refitem_refund_qty,
									'stock_return_unit_id'    => $refitem_unit_id,
								);
				
				if($poitem_has_variations == 'YES')
				{
					$poitem_variation_id        = html_escape($this->input->post('item_provariation_id_'.$row));
					$variation_id               = $this->Purchaserefund_model->get_variation_id($poitem_variation_id, $refitem_product_id);
					$poitem_variation_option_id = html_escape($this->input->post('item_variation_option_id_'.$row));
					$order_items_data['refitem_provariation_id']     = $poitem_variation_id;
					$order_items_data['refitem_variation_id']        = $variation_id;
					$order_items_data['refitem_variation_option_id'] = $poitem_variation_option_id;
					
					//Stock variations
					$stock_data['stock_return_has_variations']      = 'YES';
					$stock_data['stock_return_variation_id']        = $variation_id;
					$stock_data['stock_return_variation_option_id'] = $poitem_variation_option_id;
				}else{
					$stock_data['stock_return_has_variations'] = 'NO';
				}
				$this->Purchaserefund_model->save_purchase_refund_items_data($order_items_data);
				$this->Purchaserefund_model->save_stocks_data($stock_data);
			}
		}
		
		$refunds_params = array(
							'refund_id' => $refund_id,
							'order_id'  => $order_id
						);
		$this->transactions->update_suppliers_payments_refunds($prefund_id, $refunds_params);
		
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Refund voucher has been successfully updated.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, 'formatted_id' => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function delete()
	{
		$refund_id = $this->input->post('id');
		
		//Update stock 
		$stock_data = array(
							'stock_return_has_deleted' => 'YES',
							'stock_return_deleted_by'  => $this->session->userdata('active_admin'),
						);
		$this->Purchaserefund_model->update_stock_data($refund_id, $stock_data);
		
		//Update order 
		$refund_data = array(
							'refund_has_deleted' => 'YES',
							'refund_deleted_by'  => $this->session->userdata('active_admin'),
						);
		$this->Purchaserefund_model->update_refund_information($refund_id, $refund_data);
		
		//Delete supplier payment refund
		$this->transactions->delete_suppliers_payments_refunds($refund_id);
		
		$result = array("status" => "ok");
		echo json_encode($result);
		exit;
	}
	
	
}
