<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Suppliers extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$active_user = $this->session->userdata('active_admin');
		$userLogin = $this->session->userdata('userLogin');
		if($active_user === NULL && $userLogin !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		
		$this->load->library('ajax_pagination');
		$this->perPage = 10;
		$this->load->model('Suppliers_model');
	}
	
	public function index()
	{
		$data = array();
        
		//total rows count
		$totalRec = $this->Suppliers_model->count_all_suppliers();
		
		//pagination configuration
		$config['target']      = '#postList';
		$config['base_url']    = base_url().'apiv1/get_products';
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		$config['link_func']   = 'searchFilter';
		$this->ajax_pagination->initialize($config);
		
		//get the posts data
		$data['items'] = $this->Suppliers_model->get_all_suppliers(array('limit'=>$this->perPage));
		
		$this->load->view('suppliers/index', $data);
	}
	
	public function add()
	{
		$this->load->view('suppliers/create');
	}
	
	public function create()
	{
		//General Information
		$general_information = array(
									'supplier_name'                     => html_escape($this->input->post('name')),
									'supplier_country_id'               => html_escape($this->input->post('country_id')),
									'supplier_state_id'                 => html_escape($this->input->post('state_id')),
									'supplier_city_id'                  => html_escape($this->input->post('city_id')),
									'supplier_address'                  => html_escape($this->input->post('address')),
									'supplier_telephone_number'         => html_escape($this->input->post('telephone_number')),
									'supplier_fax_number'               => html_escape($this->input->post('fax_number')),
									'supplier_email_address'            => html_escape($this->input->post('email_address')),
									'supplier_website_address'          => html_escape($this->input->post('website_address')),
									'supplier_company_established_date' => html_escape($this->input->post('company_established_date')),
									'supplier_service_area'             => html_escape($this->input->post('service_area')),
									'supplier_type_of_business'         => html_escape($this->input->post('type_of_business')),
									'supplier_company_legal_structure'  => html_escape($this->input->post('company_legal_structure')),
									'supplier_created_date'             => date("Y-m-d H:i:s"),
									'supplier_update_date'              => date("Y-m-d H:i:s"),
									'supplier_created_by'               => $this->session->userdata('active_admin'),
									'supplier_updated_by'               => $this->session->userdata('active_admin'),
									'supplier_is_active'                => html_escape($this->input->post('is_active')),
								);
		
		$get_insert_id = $this->Suppliers_model->save($general_information);
		$supplier_id = $this->db->insert_id($get_insert_id);
		
		//Formatted ID
		$padding_1 = str_pad(date("y"), 3, '0', STR_PAD_LEFT);
		$padding_2 = str_pad(date("m"), 3, '0', STR_PAD_LEFT);
		$padding_3 = str_pad(date("d"), 5, '0', STR_PAD_LEFT);
		
		$formatted_id = 'SUP-'.$padding_1.'-'.$padding_2.'-'.$padding_3.'-'.$supplier_id;
		$this->Suppliers_model->update($supplier_id, array('supplier_formatted_id' => html_escape($formatted_id)));
		
		$this->load->library('upload');
	    $this->load->library('image_lib');
		$path = attachment_dir('suppliers/'.$formatted_id.'/');
		if(file_exists($path))
		{
			echo null;
		}else
		{
			mkdir($path);
		}
	    $config['upload_path']          = $path;
	    $config['allowed_types']        = 'gif|jpg|png|jpeg';
	    $config['detect_mime']          = TRUE;
	    $config['remove_spaces']        = TRUE;
	    $config['encrypt_name']         = TRUE;
	    $config['max_size']             = '0';
	    $this->upload->initialize($config);
		if (!$this->upload->do_upload('logo')){
		  $upload_error = $this->upload->display_errors();
	    }else{
			$fileData = $this->upload->data();
			$supplier_company_logo = $fileData['file_name'];
			$configer =  array(
			  'image_library'   => 'gd2',
			  'source_image'    =>  $config['upload_path'].$fileData['file_name'],
			  'create_thumb'    =>  FALSE,
			  'maintain_ratio'  =>  true,
			  'width'           =>  250,
			  'height'          =>  250,
			);
			$this->image_lib->clear();
			$this->image_lib->initialize($configer);
			$this->image_lib->resize();
			
			$this->Suppliers_model->update($supplier_id, array('supplier_company_logo' => $supplier_company_logo));
		}
		
		//Login Details
		$password = "0123456789";
		$hashed_password = password_hash($password, PASSWORD_DEFAULT);
		$login_data = array(
							'login_supplier_id' => $supplier_id,
							'login_email'       => html_escape($this->input->post('email_address')),
							'login_password'    => $hashed_password,
						);
		$this->Suppliers_model->save_supplier_login_info($login_data);
		
		//Contact Information
		$contact_rows = $this->input->post('contact_details');
		if(is_array($contact_rows) && count($contact_rows) !== 0)
		{
			foreach($contact_rows as $row)
			{
				$contact_full_name = html_escape($this->input->post('contact_full_name_'.$row));
				$contact_designation = html_escape($this->input->post('contact_designation_'.$row));
				$contact_email_address = html_escape($this->input->post('contact_email_address_'.$row));
				$contact_telephone_number = html_escape($this->input->post('contact_telephone_number_'.$row));
				$contact_mobile_number = html_escape($this->input->post('contact_mobile_number_'.$row));
				$contact_whatsapp_number = html_escape($this->input->post('contact_whatsapp_number_'.$row));
				if($contact_full_name && $contact_designation && $contact_mobile_number)
				{
					$contact_information = array(
												'contact_supplier_id'      => $supplier_id,
												'contact_full_name'        => $contact_full_name,
												'contact_designation'      => $contact_designation,
												'contact_email_address'    => $contact_email_address,
												'contact_telephone_number' => $contact_telephone_number,
												'contact_mobile_number'    => $contact_mobile_number,
												'contact_whatsapp_number'  => $contact_whatsapp_number,
											);
					$this->Suppliers_model->save_saams_suppliers_contacts($contact_information);
				}
			}
		}
		
		//Banking Information
		$bank_rows = $this->input->post('bank_details');
		if(is_array($bank_rows) && count($bank_rows) !== 0)
		{
			foreach($bank_rows as $row)
			{
				$spmethod_bank_name = html_escape($this->input->post('bank_name_'.$row));
				$spmethod_branch_name = html_escape($this->input->post('branch_name_'.$row));
				$spmethod_account_name = html_escape($this->input->post('account_name_'.$row));
				$spmethod_account_number = html_escape($this->input->post('account_number_'.$row));
				if($spmethod_bank_name && $spmethod_account_name && $spmethod_account_number)
				{
					$bank_information = array(
												'spmethod_supplier_id'    => $supplier_id,
												'spmethod_bank_name'      => $spmethod_bank_name,
												'spmethod_branch_name'    => $spmethod_branch_name,
												'spmethod_account_name'   => $spmethod_account_name,
												'spmethod_account_number' => $spmethod_account_number,
											);
					$this->Suppliers_model->save_saams_suppliers_banking_informations($bank_information);
				}
			}
		}
		
		//Opening Balance Information
		$opbalance_type = html_escape($this->input->post('opbalance_type'));
		if($opbalance_type == 'NA'){
			$opbalance_amount = NULL;
		}else{
			$opbalance_amount = html_escape($this->input->post('opbalance_amount'));
		}
		$opening_balance = array(
								'opbalance_supplier_id'   => $supplier_id,
								'opbalance_type'   => $opbalance_type,
								'opbalance_amount' => str_replace(',', '', $opbalance_amount),
							);
		$this->transactions->save_suppliers_opening_balances($opening_balance);
		
				
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Supplier information has been successfully saved.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, 'supplier_name' => html_escape($this->input->post('name')), 'supplier_id' => $supplier_id, 'formatted_id' => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function edit($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Suppliers_model->get_supplier_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['supplier_info'] = $is_info_exist;
				$this->load->view('suppliers/edit', $data);
			}else{
				redirect('purchase/suppliers', 'refresh', true);
			}
		}else{
			redirect('purchase/suppliers', 'refresh', true);
		}
	}
	
	public function view($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Suppliers_model->get_supplier_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$supplier_id = $is_info_exist['supplier_id'];
				if(isset($_GET['TAB']) && $_GET['TAB'] == 'PURCHASE-INVOICE'){
					$data = array();
        
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_purchases($supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_purchases';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_purchases(array('supplier_id' => $supplier_id, 'limit'=>$this->perPage));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/purchase_invoices', $data);
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'REFUND-HISTORY'){
					$data = array();
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_refunds($supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_refund_histories';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_refunds(array('supplier_id' => $supplier_id, 'limit'=>$this->perPage));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/refund_histories', $data);
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'TRANSACTION-HISTORY'){
					$data = array();
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_transactions($supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_transaction_histories';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_transactions(array('supplier_id' => $supplier_id, 'limit'=>$this->perPage));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/transaction_histories', $data);
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'PAYMENT-HISTORY'){
					$data = array();
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_payments($supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_transaction_histories';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_payments(array('supplier_id' => $supplier_id, 'limit'=>$this->perPage));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/payment_histories', $data);
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'CHEQUES'){
					if(isset($_GET['TYPE']) && $_GET['TYPE'] == 'PAYMENT'){
						$type = 'SUPPLIER_PAYMENT';
					}elseif(isset($_GET['TYPE']) && $_GET['TYPE'] == 'REFUND'){
						$type = 'PURCHASE_REFUND';
					}else{
						$type = 'SUPPLIER_PAYMENT';
					}
					
					$data = array();
        
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_cheques($type, $supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_payment_cheques';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_cheques(array('limit'=>$this->perPage, 'type' => $type, 'supplier_id' => $supplier_id));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					if($type == 'SUPPLIER_PAYMENT'){
						$this->load->view('suppliers/details/cheques-management/cheques', $data);
					}elseif($type == 'PURCHASE_REFUND'){
						$this->load->view('suppliers/details/cheques-management/refund/cheques', $data);
					}else{
						$this->load->view('suppliers/details/cheques-management/cheques', $data);
					}
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'FUND-TRANSFER'){
					if(isset($_GET['TYPE']) && $_GET['TYPE'] == 'PAYMENT'){
						$type = 'SUPPLIER_PAYMENT';
					}elseif(isset($_GET['TYPE']) && $_GET['TYPE'] == 'REFUND'){
						$type = 'PURCHASE_REFUND';
					}else{
						$type = 'SUPPLIER_PAYMENT';
					}
					
					$data = array();
        
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_receipts($type, $supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_payment_transfer_receipts';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_receipts(array('limit'=>$this->perPage, 'type' => $type, 'supplier_id' => $supplier_id));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					if($type == 'SUPPLIER_PAYMENT'){
						$this->load->view('suppliers/details/fund-transfers/receipts', $data);
					}elseif($type == 'PURCHASE_REFUND'){
						$this->load->view('suppliers/details/fund-transfers/refund/receipts', $data);
					}else{
						$this->load->view('suppliers/details/fund-transfers/receipts', $data);
					}
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'CR-NOTE'){
					$data = array();
					//total rows count
					$totalRec = $this->Suppliers_model->count_all_crnotes($supplier_id);
					
					//pagination configuration
					$config['target']      = '#postList';
					$config['base_url']    = base_url().'apiv1/get_supplier_crnotes';
					$config['total_rows']  = $totalRec;
					$config['per_page']    = $this->perPage;
					$config['link_func']   = 'searchFilter';
					$this->ajax_pagination->initialize($config);
					
					//get the posts data
					$data['items'] = $this->Suppliers_model->get_all_crnotes(array('supplier_id' => $supplier_id, 'limit'=>$this->perPage));
					
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/credit_notes', $data);
				}elseif(isset($_GET['TAB']) && $_GET['TAB'] == 'LEDGER'){
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/ledger', $data);
				}else{
					$data['supplier_info'] = $is_info_exist;
					$data['supplier_ID'] = $id;
					$this->load->view('suppliers/details/details', $data);
				}
			}else{
				redirect('purchase/suppliers', 'refresh', true);
			}
		}else{
			redirect('purchase/suppliers', 'refresh', true);
		}
	}
	
	public function update()
	{
		$supplier_id = html_escape($this->input->post('id'));
		$formatted_id = html_escape($this->input->post('formatted_id'));
		//General Information
		$general_information = array(
									'supplier_name'                     => html_escape($this->input->post('name')),
									'supplier_country_id'               => html_escape($this->input->post('country_id')),
									'supplier_state_id'                 => html_escape($this->input->post('state_id')),
									'supplier_city_id'                  => html_escape($this->input->post('city_id')),
									'supplier_address'                  => html_escape($this->input->post('address')),
									'supplier_telephone_number'         => html_escape($this->input->post('telephone_number')),
									'supplier_fax_number'               => html_escape($this->input->post('fax_number')),
									'supplier_email_address'            => html_escape($this->input->post('email_address')),
									'supplier_website_address'          => html_escape($this->input->post('website_address')),
									'supplier_company_established_date' => html_escape($this->input->post('company_established_date')),
									'supplier_service_area'             => html_escape($this->input->post('service_area')),
									'supplier_type_of_business'         => html_escape($this->input->post('type_of_business')),
									'supplier_company_legal_structure'  => html_escape($this->input->post('company_legal_structure')),
									'supplier_update_date'              => date("Y-m-d H:i:s"),
									'supplier_updated_by'               => $this->session->userdata('active_admin'),
									'supplier_is_active'                => html_escape($this->input->post('is_active')),
								);
		$this->Suppliers_model->update($supplier_id, $general_information);
		
		$supplier_info = $this->Suppliers_model->get_supplier_by_id($supplier_id);
		
		$this->load->library('upload');
	    $this->load->library('image_lib');
		$path = attachment_dir('suppliers/'.$supplier_info['supplier_formatted_id'].'/');
	    $config['upload_path']          = $path;
	    $config['allowed_types']        = 'gif|jpg|png|jpeg';
	    $config['detect_mime']          = TRUE;
	    $config['remove_spaces']        = TRUE;
	    $config['encrypt_name']         = TRUE;
	    $config['max_size']             = '0';
	    $this->upload->initialize($config);
		if (!$this->upload->do_upload('logo')){
		  $upload_error = $this->upload->display_errors();
	    }else{
			if(!empty($supplier_info['supplier_company_logo']) && $supplier_info['supplier_company_logo'] !== NULL){
				//Delete original photo
				$file_name = $path.$supplier_info['supplier_company_logo'];
				if(file_exists($file_name)){
					unlink($file_name);
				}else{
					echo null;
				}
			}else{
				echo null;
			}
			
			$fileData = $this->upload->data();
			$supplier_company_logo = $fileData['file_name'];
			$configer =  array(
			  'image_library'   => 'gd2',
			  'source_image'    =>  $config['upload_path'].$fileData['file_name'],
			  'create_thumb'    =>  FALSE,
			  'maintain_ratio'  =>  true,
			  'width'           =>  200,
			  'height'          =>  200,
			);
			$this->image_lib->clear();
			$this->image_lib->initialize($configer);
			$this->image_lib->resize();
			
			$this->Suppliers_model->update($supplier_id, array('supplier_company_logo' => $supplier_company_logo));
		}
		
		//Login Details
		$login_data = array(
							'login_email'       => html_escape($this->input->post('email_address')),
						);
		$this->Suppliers_model->update_supplier_login_info($supplier_id, $login_data);
		
		//Delete old contact & bank information
		$this->Suppliers_model->delete_old_contact_and_bank_info($supplier_id);
		
		//Contact Information
		$contact_rows = $this->input->post('contact_details');
		if(is_array($contact_rows) && count($contact_rows) !== 0)
		{
			foreach($contact_rows as $row)
			{
				$contact_full_name = html_escape($this->input->post('contact_full_name_'.$row));
				$contact_designation = html_escape($this->input->post('contact_designation_'.$row));
				$contact_email_address = html_escape($this->input->post('contact_email_address_'.$row));
				$contact_telephone_number = html_escape($this->input->post('contact_telephone_number_'.$row));
				$contact_mobile_number = html_escape($this->input->post('contact_mobile_number_'.$row));
				$contact_whatsapp_number = html_escape($this->input->post('contact_whatsapp_number_'.$row));
				if($contact_full_name && $contact_designation && $contact_mobile_number)
				{
					$contact_information = array(
												'contact_supplier_id'      => $supplier_id,
												'contact_full_name'        => $contact_full_name,
												'contact_designation'      => $contact_designation,
												'contact_email_address'    => $contact_email_address,
												'contact_telephone_number' => $contact_telephone_number,
												'contact_mobile_number'    => $contact_mobile_number,
												'contact_whatsapp_number'  => $contact_whatsapp_number,
											);
					$this->Suppliers_model->save_saams_suppliers_contacts($contact_information);
				}
			}
		}
		
		//Banking Information
		$bank_rows = $this->input->post('bank_details');
		if(is_array($bank_rows) && count($bank_rows) !== 0)
		{
			foreach($bank_rows as $row)
			{
				$spmethod_bank_name = html_escape($this->input->post('bank_name_'.$row));
				$spmethod_branch_name = html_escape($this->input->post('branch_name_'.$row));
				$spmethod_account_name = html_escape($this->input->post('account_name_'.$row));
				$spmethod_account_number = html_escape($this->input->post('account_number_'.$row));
				if($spmethod_bank_name && $spmethod_account_name && $spmethod_account_number)
				{
					$bank_information = array(
												'spmethod_supplier_id'    => $supplier_id,
												'spmethod_bank_name'      => $spmethod_bank_name,
												'spmethod_branch_name'    => $spmethod_branch_name,
												'spmethod_account_name'   => $spmethod_account_name,
												'spmethod_account_number' => $spmethod_account_number,
											);
					$this->Suppliers_model->save_saams_suppliers_banking_informations($bank_information);
				}
			}
		}
		
		//Opening Balance Information
		$opbalance_type = html_escape($this->input->post('opbalance_type'));
		$opbalance_amount = floatval(str_replace(',', '', html_escape($this->input->post('opbalance_amount'))));
		$opbalance_info = $this->Suppliers_model->get_opbalance_info($supplier_id);
		if($opbalance_info == true)
		{
			if($opbalance_info['opbalance_type'] == $opbalance_type && $opbalance_info['opbalance_amount'] == $opbalance_amount)
			{
				//nothing to do
			}else{
				if($opbalance_type == 'NA'){
					$opbalance_amount = NULL;
				}
				$opening_balance = array(
										'opbalance_supplier_id'   => $supplier_id,
										'opbalance_type'          => $opbalance_type,
										'opbalance_amount'        => $opbalance_amount,
									);
				$this->transactions->update_suppliers_opening_balances($supplier_id, $opening_balance);
			}
		}
		
				
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Supplier information has been successfully updated.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, "formatted_id" => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function delete()
	{
		$supplier_id = $this->input->post('id');
		
		$supplier_info = $this->Suppliers_model->get_supplier_by_id($supplier_id);
		$path = attachment_dir('suppliers/'.$supplier_info['supplier_formatted_id'].'/');
		if(!empty($supplier_info['supplier_company_logo']) && $supplier_info['supplier_company_logo'] !== NULL){
			//Delete original photo
			$file_name = $path.$supplier_info['supplier_company_logo'];
			if(file_exists($file_name)){
				unlink($file_name);
			}else{
				echo null;
			}
		}else{
			echo null;
		}
		
		//Perform Delete
		$this->Suppliers_model->delete($supplier_id);
		$result = array("status" => "ok");
		echo json_encode($result);
		exit;
	}
	
	public function get_states_by_country()
	{
		$country_id = $this->input->post('country_id');
		$states = $this->Suppliers_model->get_states_by_country($country_id);
		$state_list = '<option value="">Select State</option>';
		foreach($states as $state)
		{
			$state_list .= '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
		}
		
		$result = array("status" => "ok", "content" => $state_list);
		echo json_encode($result);
		exit;
	}
	
	public function get_cities_by_state()
	{
		$state_id = $this->input->post('state_id');
		$cities = $this->Suppliers_model->get_cities_by_state($state_id);
		$city_list = '<option value="">Select City</option>';
		foreach($cities as $city)
		{
			$city_list .= '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
		}
		
		$result = array("status" => "ok", "content" => $city_list);
		echo json_encode($result);
		exit;
	}
	
	public function srcsuppliers()
	{
		$keywords = html_escape($this->input->get('q'));
		$datas = $this->Suppliers_model->src_supplier_by_keywords($keywords);
		$content = array();
		foreach($datas as $data):
			$content[] = array("label" => $data['supplier_name'], "value" => intval($data['supplier_id']));
		endforeach;
		
		echo json_encode(array('content' => $content));
		exit;
	}

	public function srcsupplier_with_photos()
	{
		$keywords = html_escape($this->input->get('q'));
		$datas = $this->Suppliers_model->src_supplier_by_keywords($keywords);
		$content = array();
		foreach($datas as $data):
			$logo_url = $this->Suppliers_model->get_company_logo_url($data['supplier_id']);
			$content[] = array("label" => $data['supplier_name'], "photo" => $logo_url, "value" => intval($data['supplier_id']));
		endforeach;
		
		echo json_encode(array('content' => $content));
		exit;
	}

	public function get_supplier_info()
	{
		$supplier_id = $this->input->post('id');
		$supplier_info = $this->Suppliers_model->get_supplier_by_id($supplier_id);
		$data['supplier_info'] = $supplier_info;
		$content = $this->load->view('supplier-payments/ajax-part/payment-options', $data, true);
		
		$result = array('status' => 'ok', 'content' => $content);
		echo json_encode($result);
		exit;
	}
}
