<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cheques extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$active_user = $this->session->userdata('active_admin');
		$userLogin = $this->session->userdata('userLogin');
		if($active_user === NULL && $userLogin !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		
		$this->load->library('ajax_pagination');
		$this->perPage = 10;
		$this->load->model('Cheques_model');
	}
	
	public function index()
	{
		if(isset($_GET['TYPE']) && $_GET['TYPE'] == 'PAYMENT'){
			$type = 'SUPPLIER_PAYMENT';
		}elseif(isset($_GET['TYPE']) && $_GET['TYPE'] == 'REFUND'){
			$type = 'PURCHASE_REFUND';
		}else{
			$type = 'SUPPLIER_PAYMENT';
		}
		
		$data = array();
        
		//total rows count
		$totalRec = $this->Cheques_model->count_all_cheques($type);
		
		//pagination configuration
		$config['target']      = '#postList';
		$config['base_url']    = base_url().'apiv1/get_supplier_payment_cheques';
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		$config['link_func']   = 'searchFilter';
		$this->ajax_pagination->initialize($config);
		
		//get the posts data
		$data['items'] = $this->Cheques_model->get_all_cheques(array('limit'=>$this->perPage, 'type' => $type));
		
		if($type == 'SUPPLIER_PAYMENTS'){
			$this->load->view('cheques-management/cheques', $data);
		}elseif($type == 'PURCHASE_REFUND'){
			$this->load->view('cheques-management/refund/cheques', $data);
		}else{
			$this->load->view('cheques-management/cheques', $data);
		}
	}
	
	public function deposit()
	{
		$type = $this->input->post('chequeType');
		
		if($type == 'PAYMENT')
		{
			$cheque_id  = $this->input->post('chequeId');
			$payment_id = $this->input->post('paymentId');
			$this->transactions->deposit_cheque('SUPPLIER_PAYMENTS', $cheque_id, $payment_id);
		}elseif($type == 'REFUND'){
			$cheque_id  = $this->input->post('chequeId');
			$refund_id  = $this->input->post('refundId');
			$this->transactions->deposit_cheque('PURCHASE_REFUND', $cheque_id, $refund_id);
		}
		
		$content = '<span class="status-active-item" style="color:#0A0;text-transform:uppercase">DEPOSIT</span>';
		$result = array("status" => "ok", "content" => $content);
		echo json_encode($result);
		exit;
	}
	
	public function bounch()
	{
		$type = $this->input->post('chequeType');
		
		if($type == 'PAYMENT')
		{
			$cheque_id  = $this->input->post('chequeId');
			$payment_id = $this->input->post('paymentId');
			$this->transactions->bounch_cheque('SUPPLIER_PAYMENTS', $cheque_id, $payment_id);
		}elseif($type == 'REFUND'){
			$cheque_id  = $this->input->post('chequeId');
			$refund_id  = $this->input->post('refundId');
			$this->transactions->bounch_cheque('PURCHASE_REFUND', $cheque_id, $refund_id);
		}
		
		$content = '<span class="status-inactive-item" style="color:#FDAC41;text-transform:uppercase">BOUNCH</span>';
		$result = array("status" => "ok", "content" => $content);
		echo json_encode($result);
		exit;
	}
	
	public function delete()
	{
		$supplier_id = $this->input->post('id');
		
		$supplier_info = $this->Cheques_model->get_supplier_by_id($supplier_id);
		$path = attachment_dir('supplier-payments/'.$supplier_info['supplier_formatted_id'].'/');
		if(!empty($supplier_info['supplier_company_logo']) && $supplier_info['supplier_company_logo'] !== NULL){
			//Delete original photo
			$file_name = $path.$supplier_info['supplier_company_logo'];
			if(file_exists($file_name)){
				unlink($file_name);
			}else{
				echo null;
			}
		}else{
			echo null;
		}
		
		//Perform Delete
		$this->Payments_model->delete($supplier_id);
		$result = array("status" => "ok");
		echo json_encode($result);
		exit;
	}
}
