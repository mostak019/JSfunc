<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fundtransfers extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$active_user = $this->session->userdata('active_admin');
		$userLogin = $this->session->userdata('userLogin');
		if($active_user === NULL && $userLogin !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		
		$this->load->library('ajax_pagination');
		$this->perPage = 10;
		$this->load->model('Fundtransfers_model');
	}
	
	public function index()
	{
		if(isset($_GET['TYPE']) && $_GET['TYPE'] == 'PAYMENT'){
			$type = 'SUPPLIER_PAYMENT';
		}elseif(isset($_GET['TYPE']) && $_GET['TYPE'] == 'REFUND'){
			$type = 'PURCHASE_REFUND';
		}else{
			$type = 'SUPPLIER_PAYMENT';
		}
		
		$data = array();
        
		//total rows count
		$totalRec = $this->Fundtransfers_model->count_all_receipts($type);
		
		//pagination configuration
		$config['target']      = '#postList';
		$config['base_url']    = base_url().'apiv1/get_supplier_payment_transfer_receipts';
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		$config['link_func']   = 'searchFilter';
		$this->ajax_pagination->initialize($config);
		
		//get the posts data
		$data['items'] = $this->Fundtransfers_model->get_all_receipts(array('limit'=>$this->perPage, 'type' => $type));
		
		if($type == 'SUPPLIER_PAYMENT'){
			$this->load->view('fund-transfers/receipts', $data);
		}elseif($type == 'PURCHASE_REFUND'){
			$this->load->view('fund-transfers/refund/receipts', $data);
		}else{
			$this->load->view('fund-transfers/receipts', $data);
		}
		
	}
	
	public function delete()
	{
		$supplier_id = $this->input->post('id');
		
		$supplier_info = $this->Fundtransfers_model->get_supplier_by_id($supplier_id);
		$path = attachment_dir('supplier-payments/'.$supplier_info['supplier_formatted_id'].'/');
		if(!empty($supplier_info['supplier_company_logo']) && $supplier_info['supplier_company_logo'] !== NULL){
			//Delete original photo
			$file_name = $path.$supplier_info['supplier_company_logo'];
			if(file_exists($file_name)){
				unlink($file_name);
			}else{
				echo null;
			}
		}else{
			echo null;
		}
		
		//Perform Delete
		$this->Payments_model->delete($supplier_id);
		$result = array("status" => "ok");
		echo json_encode($result);
		exit;
	}
}
