<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payments extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$active_user = $this->session->userdata('active_admin');
		$userLogin = $this->session->userdata('userLogin');
		if($active_user === NULL && $userLogin !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		
		$this->load->library('ajax_pagination');
		$this->perPage = 10;
		$this->load->model('Payments_model');
	}
	
	public function index()
	{
		$data = array();
        
		//total rows count
		$totalRec = $this->Payments_model->count_all_payments();
		
		//pagination configuration
		$config['target']      = '#postList';
		$config['base_url']    = base_url().'apiv1/get_supplier_payments';
		$config['total_rows']  = $totalRec;
		$config['per_page']    = $this->perPage;
		$config['link_func']   = 'searchFilter';
		$this->ajax_pagination->initialize($config);
		
		//get the posts data
		$data['items'] = $this->Payments_model->get_all_payments(array('limit'=>$this->perPage));
		
		$this->load->view('supplier-payments/index', $data);
	}
	
	public function add()
	{
		$this->load->view('supplier-payments/create');
	}
	
	public function create()
	{
		$formatted_id = $this->transactions->save_suppliers_payments();
		
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Supplier payment has been successfully added.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, "formatted_id" => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function edit($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Payments_model->get_payment_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['supplier_info'] = $is_info_exist;
				$this->load->view('supplier-payments/edit', $data);
			}else{
				redirect('purchase/payments', 'refresh', true);
			}
		}else{
			redirect('purchase/payments', 'refresh', true);
		}
	}
	
	public function update()
	{
		$formatted_id = $this->transactions->update_suppliers_payments();
		
		$alert = '<div class="alert alert-success alert-dismissible mb-2" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					  </button>
					  <div class="d-flex align-items-center">
						<i class="bx bx-like"></i>
						<span>
						  Great! Supplier payment has been successfully updated.
						</span>
					  </div>
					</div>';
		$result = array("status" => "ok", "alert" => $alert, "formatted_id" => $formatted_id);
		echo json_encode($result);
		exit;
	}
	
	public function vouchar($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Payments_model->get_payment_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['payment_info'] = $is_info_exist;
				$this->load->view('supplier-payments/payment_receipt', $data);
			}else{
				redirect('purchase/payments', 'refresh', true);
			}
		}else{
			redirect('purchase/payments', 'refresh', true);
		}
	}
	
	public function download($id)
	{
		if(isset($id))
		{
			$is_info_exist = $this->Payments_model->get_payment_by_formatted_id(html_escape($id));
			if($is_info_exist == true)
			{
				$data['payment_info'] = $is_info_exist;
				$content = $this->load->view('supplier-payments/pdf', $data, true);
				$file_name = 'payment_receipt_'.$is_info_exist['payment_receipt_number'].'_'.date("d-m-Y_H_i_s_A").'.pdf';
				$params = array_merge($is_info_exist, array(
															'primary_field_id'      => $is_info_exist['payment_id'], 
															'content'               => $content, 
															'pdf_serial_field_name' => 'payment_vouchar_pdf_serial', 
															'subject'               => 'SUPPLIER_PAYMENT',
															'file_name'             => $file_name
														));
				$this->pdf->download($params);
			}else{
				redirect('purchase/payments', 'refresh', true);
			}
		}else{
			redirect('purchase/payments', 'refresh', true);
		}
	}
	
	public function send()
	{
		$id = $this->input->post('formatted_id');
		$to = $this->input->post('email');
		$is_info_exist = $this->Payments_model->get_payment_by_formatted_id(html_escape($id));
		if($is_info_exist == true)
		{
			$file_name = 'payment_receipt_'.$is_info_exist['payment_receipt_number'].'_'.date("d-m-Y_H_i_s_A").'.pdf';
			$data['payment_info'] = $is_info_exist;
			$content = $this->load->view('supplier-payments/pdf', $data, true);
			$content_body = $this->load->view('supplier-payments/mail', $data, true);
			$params = array_merge($is_info_exist, array(
															'primary_field_id'      => $is_info_exist['payment_id'], 
															'pdf_serial_field_name' => 'payment_vouchar_pdf_serial', 
															'subject'               => 'SUPPLIER_PAYMENT',
															'content'               => $content, 
															'file_name'             => $file_name,
															'email_to'              => $to,
															'email_subject'         => 'SUPPLIER PAYMENT RECEIPT',
															'email_body'            => $content_body,
															'has_attachment'        => 'YES',
														));
			$this->pdf->send($params);
			
			$alert = '<div class="alert alert-success">The payment receipt has been sent to "'.$to.'"</div>';
			$result = array('status' => 'ok', 'alert' => $alert);
			echo json_encode($result);
			exit;
		}else{
			$alert = '<div class="alert alert-danger">An error occurred, please try again later.</div>';
			$result = array('status' => 'error', 'alert' => $alert);
			echo json_encode($result);
			exit;
		}
	}
	
	public function delete()
	{
		$payment_id = $this->input->post('id');
		
		//Delete supplier payment
		$this->transactions->delete_suppliers_payments($payment_id);
		
		$result = array("status" => "ok");
		echo json_encode($result);
		exit;
	}
	
	public function get_states_by_country()
	{
		$country_id = $this->input->post('country_id');
		$states = $this->Payments_model->get_states_by_country($country_id);
		$state_list = '<option value="">Select State</option>';
		foreach($states as $state)
		{
			$state_list .= '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
		}
		
		$result = array("status" => "ok", "content" => $state_list);
		echo json_encode($result);
		exit;
	}
	
	public function get_cities_by_state()
	{
		$state_id = $this->input->post('state_id');
		$cities = $this->Payments_model->get_cities_by_state($state_id);
		$city_list = '<option value="">Select City</option>';
		foreach($cities as $city)
		{
			$city_list .= '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
		}
		
		$result = array("status" => "ok", "content" => $city_list);
		echo json_encode($result);
		exit;
	}
	
	public function srcsuppliers()
	{
		$keywords = html_escape($this->input->get('q'));
		$datas = $this->Payments_model->src_supplier_by_keywords($keywords);
		$content = array();
		foreach($datas as $data):
			$content[] = array("label" => $data['supplier_name'], "value" => intval($data['supplier_id']));
		endforeach;
		
		echo json_encode(array('content' => $content));
		exit;
	}
	
	public function get_account_balance()
	{
		$account_id = $this->input->post('id');
		$account_balance = get_account_balance($account_id);
		$content = '<span style="margin-left:60px;font-size: 13px;background: #F0F0F0;padding: 3px 10px;border-radius: 4px;text-align: center;display: block;line-height: 22px;"><strong style="color:#0A0;display: block;">Available Balance </strong> <span>'.number_format(floatval($account_balance), 2, '.', ',').'</span> <strong> (BDT)</strong></span>';
		echo json_encode(array('status' => 'ok', 'content' => $content, 'available_balance' => $account_balance));
		exit;
	}
	
	public function accounts_by_type()
	{
		$type_array = array('CASH' => 'PETTY_CASH', 'CHEQUE' => 'BANK', 'BANK_FUND_TRANSFER' => 'BANK', 'MOBILE_BANKING' => 'MOBILE_BANKING');
		$type = $this->input->post('type');
		$accounts = get_accounts_by_type($type_array[$type]);
		$content = '<option value="">Select Account</option>';
		foreach($accounts as $account)
		{
			if($type == 'CASH')
			{
				$content .= '<option value="'.$account['account_id'].'">'.$account['account_title'].'</option>';
			}else{
				$content .= '<option value="'.$account['account_id'].'">'.$account['account_title'].' - A/C :'.$account['account_number'].'</option>';
			}
 		}
		echo json_encode(array('status' => 'ok', 'content' => $content));
		exit;
	}
}
